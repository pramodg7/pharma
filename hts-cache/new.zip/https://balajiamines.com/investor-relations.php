<!DOCTYPE html>
<html lang="en-US" class="no-js">
<head>
    <meta charset="UTF-8" />
		<meta name="author" content="Balaji Amines" />
	<meta name="keywords" content=" balaji , balaji amines, balaji amines solapur, Chemical Manufacturers in India, Chemical Manufacturers India, Industrial Chemicals Manufacturers, Industrial Chemicals Manufacturers in India Chemical manufacturing company in india, Chemical manufacturing company in Solapur, Chemical manufacturing company, methyl, Chemical Manufacturer,hydrochloride derivatives, industrial chemicals manufacturers, industrial chemicals suppliers, industrial chemicals india, industrial chemicals exporters, industrial chemicals manufacturer, industrial chemicals supplier, industrial chemicals exporter, industrial chemicals from india, industrial chemicals wholesale, industrial chemicals in india">
	<meta name="description"  content="Manufacturer of methyl and ethyl amines and their amide and hydrochloride derivatives, located in India.  Chemical manufacturing company in india">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Balaji &ndash; Investors Information</title>
    <link rel="shortcut icon" href="wp-content/themes/toolset-bootstrap/favicon.ico">
    <script type="text/javascript">
        window._wpemojiSettings = {
            "baseUrl": "https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/72x72\/",
            "ext": ".png",
            "svgUrl": "https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/svg\/",
            "svgExt": ".svg",
            "source": {
                "concatemoji": "http:\/\/www.balajiamines.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.7.3"
            }
        };
        ! function(a, b, c) {
            function d(a) {
                var b, c, d, e, f = String.fromCharCode;
                if (!k || !k.fillText) return !1;
                switch (k.clearRect(0, 0, j.width, j.height), k.textBaseline = "top", k.font = "600 32px Arial", a) {
                    case "flag":
                        return k.fillText(f(55356, 56826, 55356, 56819), 0, 0), !(j.toDataURL().length < 3e3) && (k.clearRect(0, 0, j.width, j.height), k.fillText(f(55356, 57331, 65039, 8205, 55356, 57096), 0, 0), b = j.toDataURL(), k.clearRect(0, 0, j.width, j.height), k.fillText(f(55356, 57331, 55356, 57096), 0, 0), c = j.toDataURL(), b !== c);
                    case "emoji4":
                        return k.fillText(f(55357, 56425, 55356, 57341, 8205, 55357, 56507), 0, 0), d = j.toDataURL(), k.clearRect(0, 0, j.width, j.height), k.fillText(f(55357, 56425, 55356, 57341, 55357, 56507), 0, 0), e = j.toDataURL(), d !== e
                }
                return !1
            }

            function e(a) {
                var c = b.createElement("script");
                c.src = a, c.defer = c.type = "text/javascript", b.getElementsByTagName("head")[0].appendChild(c)
            }
            var f, g, h, i, j = b.createElement("canvas"),
                k = j.getContext && j.getContext("2d");
            for (i = Array("flag", "emoji4"), c.supports = {
                    everything: !0,
                    everythingExceptFlag: !0
                }, h = 0; h < i.length; h++) c.supports[i[h]] = d(i[h]), c.supports.everything = c.supports.everything && c.supports[i[h]], "flag" !== i[h] && (c.supports.everythingExceptFlag = c.supports.everythingExceptFlag && c.supports[i[h]]);
            c.supports.everythingExceptFlag = c.supports.everythingExceptFlag && !c.supports.flag, c.DOMReady = !1, c.readyCallback = function() {
                c.DOMReady = !0
            }, c.supports.everything || (g = function() {
                c.readyCallback()
            }, b.addEventListener ? (b.addEventListener("DOMContentLoaded", g, !1), a.addEventListener("load", g, !1)) : (a.attachEvent("onload", g), b.attachEvent("onreadystatechange", function() {
                "complete" === b.readyState && c.readyCallback()
            })), f = c.source || {}, f.concatemoji ? e(f.concatemoji) : f.wpemoji && f.twemoji && (e(f.twemoji), e(f.wpemoji)))
        }(window, document, window._wpemojiSettings);
    </script>
    <style type="text/css">
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 .07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
		table {
  border-collapse: separate;
  border-spacing: 0;
}
th,
td {
  padding: 5px 5px !important;
}
thead {
  background: #13237a;
  color: #fff;
}
th {
  font-weight: bold;
}
tbody tr:nth-child(even) {
  background: #f0f0f2;
}
td {
  border-bottom: 1px solid #cecfd5;
  border-right: 1px solid #cecfd5;
}
td:first-child {
  border-left: 1px solid #cecfd5;
}
.btn {
    display: inline-block;
    padding: 0px 5px !important;
    margin-bottom: 0;
    font-size: 14px;
    font-weight: 400;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 4px;
}
.btn-success {
    background-color: #046a0d;
    border-color: #046a0d;
    color: #FFFFFF;
}
    </style>
	<style>
* {
    margin: 0;
    padding: 0;
}

body {
    
    background: #929292;
    font-size: 100%;
    font-family: "Arial";
}

input {
    font-size: 1em;
}

ol.tree {
    padding-left: 30px;
    background: #13237a;
}

li{
    list-style-type: none;
    color: #ffffff;
    position: relative;
    margin-left: 10px;
}

li label {
    padding-left: 25px;
    cursor: pointer;
    padding-bottom: 5px;
    padding-top: 3px;
    display: block;
	border-bottom: 1px solid #2e6da4;
}

li input {
    width: 1em;
    height: 1em;
    position: absolute;
    left: -0.5em;
    top: 0;
    opacity: 0;
    cursor: pointer;
}

li input + ol {
    height: 1em;
    margin: -28px 0 0 -36px;
    background: url(img/plus.png) no-repeat 31px 0;
    padding: 15px;
}

li input + ol > li {
    display: none;
    margin-left: -14px !important;
    padding-left: 1px
}

li.file {
    margin-left: -1px !important;
}

li.file a {
    display: inline-block;
    padding-left: 21px;
    color: #fff;
    text-decoration: none;
    background: url("img/pdf.png") no-repeat 0 0;
    padding-bottom: 5px;
	border-bottom: 1px solid #2e6da4;
}

li input:checked + ol {
    height: auto;
    margin: -24px 0 0 -17px;
    padding: 25px 0 0 88px;
    background: url(img/min.png) no-repeat 14px -3px;
}

li input:checked + ol > li {
    display: block;
    margin: 0 0 0.063em;
}

li input:checked + ol > li:first-child {
    margin: 0 0 0.125em;
}
	 </style>
    <link rel='stylesheet' id='formidable-css' href='wp-content/uploads/formidable/css/formidablepro.css?ver=2.03.03' type='text/css' media='all' />
    <link rel='stylesheet' id='wp_ddl_layout_fe_css-css' href='wp-content/uploads/ddl-layouts-tmp/d41d8cd98f00b204e9800998ecf8427e.css?ver=1.3.2' type='text/css' media='screen' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3/css/bootstrap.min.css?ver=3.3.4' type='text/css' media='all' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_theme_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3/css/bootstrap-theme.min.css' type='text/css' media='all' />
    <link rel='stylesheet' id='toolset-bootstrap-theme-style-css' href='wp-content/themes/toolset-bootstrap/style.css?ver=1.8' type='text/css' media='all' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_adjustment_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3_adjustment.css' type='text/css' media='all' />
    <link rel='stylesheet' id='menu-cells-front-end-css' href='wp-content/plugins/layouts/resources/css/cell-menu-css.css?ver=4.7.3' type='text/css' media='screen' />
    <link rel='stylesheet' id='ddl-front-end-css' href='wp-content/plugins/layouts/resources/css/ddl-front-end.css?ver=4.7.3' type='text/css' media='screen' />
    <link rel='stylesheet' id='toolset-common-css' href='wp-content/plugins/layouts/toolset/toolset-common/res/css/toolset-common.css?ver=4.7.3' type='text/css' media='screen' />
    <link rel='stylesheet' id='wptoolset-field-datepicker-css' href='wp-content/plugins/wp-views/embedded/common/toolset-forms/css/wpt-jquery-ui/datepicker.css?ver=1.10' type='text/css' media='all' />
    <link rel='stylesheet' id='mediaelement-css' href='wp-includes/js/mediaelement/mediaelementplayer.min.css?ver=2.22.0' type='text/css' media='all' />
    <link rel='stylesheet' id='wp-mediaelement-css' href='wp-includes/js/mediaelement/wp-mediaelement.min.css?ver=4.7.3' type='text/css' media='all' />
    <link rel='stylesheet' id='views-pagination-style-css' href='wp-content/plugins/wp-views/embedded/res/css/wpv-pagination.css?ver=1.10' type='text/css' media='all' />
    <script type='text/javascript' src='wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
    <script type='text/javascript' src='wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var DDLayout_fe_settings = {
            "DDL_JS": {
                "css_framework": "bootstrap-3",
                "DEBUG": false
            }
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='wp-content/plugins/layouts/resources/js/ddl-layouts-frontend.js?ver=1.3.2'></script>
 <style type="text/css">
        .recentcomments a {
            display: inline !important;
            padding: 0 !important;
            margin: 0 !important;
        }
    </style>
	<link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/owl.carousel.css">
	<link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/owl.theme.css">
	<script src="wp-content/themes/toolset-bootstrap/js/owl.carousel.js"></script>
	<script type="text/javascript" src="wp-content/themes/toolset-bootstrap/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/fancybox/jquery.fancybox-1.3.4.css" type="text/css" media="screen" />
	<link href='https://fonts.googleapis.com/css?family=Khand:400,300,500,600,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,100italic,100,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link rel='stylesheet' href="wp-content/themes/toolset-bootstrap/css/mediatree.css">
    <link rel='stylesheet' media="print" href="wp-content/themes/toolset-bootstrap/css/custom-print.css">
    <link rel='stylesheet' href="wp-content/themes/toolset-bootstrap/css/zara.css">
    <link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>
    <link href="wp-content/themes/toolset-bootstrap/css/jasny-bootstrap.min.css" rel="stylesheet" media="screen">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.matchHeight.js"></script>
    <script src="wp-content/themes/toolset-bootstrap/js/jasny-bootstrap.min.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/flexslider.css" type="text/css">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.flexslider.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.matchHeight-min.js" type="text/javascript"></script>
    <script type="text/javascript" src="wp-content/themes/toolset-bootstrap/lazyyt/lazyYT.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/lazyyt/lazyYT.css">
    <script type='text/javascript' src='//cdn.jsdelivr.net/jquery.marquee/1.3.1/jquery.marquee.min.js'></script>
</head>
<body class="page-template page-template-page-layouts page-template-page-layouts-php page page-id-480">
    <div class="navmenu navmenu-default navmenu-fixed-right">
        <ul id="menu-menu-1" class="nav navmenu-nav">
            <li id="menu-item-20" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-2 current_page_item menu-item-20 active"><a href="index.php">Homepage</a></li>
            <li id="menu-item-656" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-656"><a href="#">About us</a>
                <ul class="sub-menu">
                    <li id="menu-item-267" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-267"><a href="company-profile.php">Company Profile</a></li>
                    <li id="menu-item-261" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-261"><a href="mission-values.php">Mission &#038; Values</a></li>
                    <li id="menu-item-280" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-280"><a href="certificate-awards.php">Certificate &#038; Awards</a></li>
                    <li id="menu-item-348" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-348"><a href="balaji-management-team.php">Management Team</a></li>
                    <li id="menu-item-339" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-339"><a href="balaji-amines-history.php">History</a></li>
                    <li id="menu-item-710" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-710"><a href="bal-presence.php">BAL&#8217;s Presence</a></li>
                </ul>
            </li>
            <li id="menu-item-400" class="menu-item menu-item-type-post_type_archive menu-item-object-product menu-item-has-children menu-item-400"><a href="category.php">Products</a>
                <ul class="sub-menu">
                    <li id="menu-item-658" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-658"><a href="amines.php">Amines</a></li>
                    <li id="menu-item-657" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-657"><a href="derivatives.php">Derivatives</a></li>
                    <li id="menu-item-659" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-659"><a href="speciality-chemicals.php">Speciality Chemicals</a></li>
                    <li id="menu-item-678" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-678"><a href="excipients.php">Pharma Excipients</a></li>
                </ul>
            </li>
            <li id="menu-item-534" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-534"><a href="investor-relations.php">Investor Relations</a></li>
            <li id="menu-item-290" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-290"><a href="careers.php">Careers</a></li>
            <li id="menu-item-299" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-299"><a href="corporate-social-responsibility.php">Corporate Social Responsibility</a></li>
            <li id="menu-item-282" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-282"><a href="contact-us.php">Contact Us</a></li>
            <li id="menu-item-307" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-307"><a href="balaji-media.php">Media</a></li>
            <li id="menu-item-711" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-711"><a href="e-brochures.php">E-Brochure</a></li>
        </ul>
    </div><div class="canvas">
 <header class="full-bg black-bg" id="homepage-header">
<div class="container">
                <div class="row">
                    <div class="col-sm-1" id="off-canvas-button">
                        <div class="navbar navbar-default">
                            <button type="button" class="navbar-toggle" data-toggle="offcanvas" data-recalc="false" data-target=".navmenu" data-canvas=".canvas">
                                <br />
                                <span class="icon-bar"></span>
                                <br />
                                <span class="icon-bar"></span>
                                <br />
                                <span class="icon-bar"></span>
                                <br />
                            </button>
                        </div>
                    </div>
                    <div class="col-sm-4 col-sm-offset-3" id="homepage-logo">
                        <p>
                            <a href=""><img src="wp-content/uploads/2015/10/balaji_logo.png" alt="Balaji Almines" class="aligncenter size-full img-responsive"></a>
                        </p>
                    </div>
                </div>
            </div>
        </header>
        <div class="container-fluid">
            <div class="ddl-full-width-row row">
                <div class="col-sm-12 featured-thumbnail">
                    <div class="thumbnail">
                        <img src="wp-content/uploads/2015/10/financials-banner.jpg">
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-sm-4 page-title-div text-center col-sm-offset-4">
                    <h1>Investor Relations</h1>
                </div>
            </div>
        </div>
        <div class="container">
		<div class="row">
                <div class="col-sm-4 heading-color ">
				<h2>REGISTERED OFFICE</h2>
                        <h3>Balaji Amines Limited </h3>
                        <p>Balaji Towers,
                            <br> No. 9/1A/1, Hotgi Road,
                            <br> Asara Chowk, Solapur - 413 224,
                            <br> Maharashtra , INDIA.
                            <br> CIN No : L24132MH1988PLC049387
                            <br> Phones:&nbsp;
                            <br> Tel : + 91 217 2310 824 / 2451 500
                            <br> Fax : + 91 217 2451 521</p>
                    </div>
					<div class="col-sm-4 heading-color ">
                        <h2>ADMINISTRATIVE OFFICE</h2>
                        <h3>Balaji Amines Limited</h3>
                        <p>Balaji Bhawan
<br>Plot No. 47, Kavuri Hills,
<br>Behind Jubilee Ridge Hotel,
<br>Madhapur, Hyderabad
<br>Telangana, India - 500 033
<br>Phone No. 040-49871200</p>
                    </div>
					<div class="col-sm-4 heading-color ">
                        <h2>HOTEL DIVISION</h2>
                        <h3>BALAJI SAROVAR PREMIERE</h3>
                        <p> Survey no.9/1A/1,
                            <br> Aasra Chowk, Hotgi Road,
                            <br> Solapur-413 224 Maharashtra, INDIA.
                            </p>
                    </div>
            </div>
                <div class="row contact-us-page">
                    <div class="col-sm-4 heading-color">
                        <h3>UNIT I:</h3>
                        <p>Tamalwadi Village<br>
TuljapurTaluk, <br>
Osmanabad District<br>
Maharashtra - 413 623<br>
                        </p>
                    </div>
                    <div class="col-sm-4 heading-color">
                        <h3>UNIT II:</h3>
                        <p>Plot No 4 & 5<br>
Beside Sub-Station 2<br>
IDA Bollaram,<br>
Sangareddy District,<br>
Telangana - 502 325<br>
                        </p>
                    </div>
                    <div class="col-sm-4 heading-color">
                        <h3>UNIT III:</h3>
                        <p>Plot No E-7 & E-8<br>
MIDC, Chincholi Solapur<br>
Maharashtra- 413 255<br></p>
                    </div>
                    <div class="col-sm-4 heading-color">
                        <h3>UNIT IV:</h3>
                        <p>F-104, MIDC, Chincholi Solapur<br>
Maharashtra- 413 255<br></p>
                    </div>
                </div>
				<div class="row">
                <div class="col-sm-4 heading-color ">
				<h2>GRIEVANCE REDRESSAL</h2>
                        <h3></h3>
                        <p> Email : cs@balajiamines.com
                           
                    </div>
					<div class="col-sm-4 heading-color ">
                        <h2>SHARE TRANSFER AGENTS</h2>
                        <h3>Venture Capital and Corporate Investments PVT LTD.</h3>
<p>(CATEGORY-I REGISTRARS)</p>
<p>“Aurum”, Door No.4-50/P-II/57/4F & 5F, Plot No.57,
4th & 5th Floors, Jayabheri Enclave Phase – II,
Gachibowli, Hyderabad – 500 032, Telangana.</p>
<h3>Phone Nos. 040 - 23818475, 23868257, 35164940</h3>
<h3>Email Id: investor.relations@vccipl.com</h3>
<p>Website: www.vccipl.com</p>
                    </div>
					<div class="col-sm-4 heading-color ">
                        <h2>COMPLIANCE OFFICER AND NODAL OFFICER (IEPF)</h2>
                        <h3>Mr. Abhijeet Kothadiya</h3>
                        <h3>Company Secretary & Compliance Officer </h3>
							Email : cs@balajiamines.com
							<br>Tel.: + 91 217 2310 824 / 2451 500, 
 
							<br>Tel : + 91 217 2451 543 (Direct)
							<br>Fax: + 91 217 2451 521<br>
                            </p>
                    </div>
            </div>
			<div class="row">
                <div class="col-sm-4 heading-color ">
				<h2>AUDITORS </h2>
                        <h3>M. Anandam & Co., Chartered Accountants,</h3>
                        <p>7’A’, Surya Towers, 
						<br> Sardar Patel Road,
						<br>Secunderabad – 500003.Telangana.
                        </p>
                    </div>
					<div class="col-sm-4 heading-color ">
                        <h2>SECRETARIAL AUDITORS</h2>
                        <h3>M/s. P. S. Rao & Associates</h3>
							<h3>Company Secretaries, </h3>
                            <p>Flat No. 10, 4th Floor,
							<br># 6-3-347/22/2, Ishwarya Nilayam,
							<br>Opp: Sai Baba Temple
							<br>Dwarakapuri Colony, Panjagutta,
							<br>Hyderabad – 500 082, Telangana</p>
                    </div>
					<div class="col-sm-4 heading-color ">
                        <h2>COST ACCOUNTANT </h2>
                        <h3>Mr. Narayan D. Dontul</h3>
                        <h3>Practising Cost Accountant.</h3>
						 <p>235/12, Telangi Pacha Peth,
<br>Solapur – 413005.
<br>Maharashtra<br></p>
                    </div>
					<div class="col-sm-4 heading-color">
					 <h2>Stock Exchanges  </h2>
					  <h3>BSE Limited,</h3> 
						<p> Mumbai 
						<br> Scrip Code : 530999</p>
					<h3>National Stock Exchanges of India Limited,</h3> 
						<p> Mumbai 
						<br>Scrip Code :BALAMINES</p>
                    </div>
                    <div class="col-sm-4 heading-color">
                        
                    </div>
                    <div class="col-sm-4 heading-color">
					
                    </div>
            </div>
            <div class="row report-row-wrapper">
<div class="col-sm-12 report-download heading-color">

                    <h2> Annual Reports</h2>
                    <div class="panel-group balaji-accordian" id="accordion" role="tablist" aria-multiselectable="false">
                        <!-- wpv-loop-start -->
                        <div class="panel panel-default">
                            <!-- Job Heading Pane Starts -->
                            <div style="    background-color: #046a0d !important;
    padding: 10px;
    text-align: center;
    color: white;"  role="tab" id="job-35">
                                <h4 class="panel-title">
        <a role="button" target="_blank" href="ar2022/"  class="collapsed">
         Click Here For Balaji Amines Ltd. 34th Annual Report 2021-22</a>
      </h4>
                            </div>
                            <!-- Job Heading Pane Ends -->
                            <!-- Job Content Pane Starts  -->
                            <!-- Job Content Pane Ends -->

                        </div>
                    </div>
                </div>
                <div class="col-sm-12 report-download heading-color">

                    <h2>Investor Relations</h2>
<ol class="tree">
  <li>
    <label for="menu-1">Board of Directors & Committees</label>
    <input type="checkbox" id="menu-1" />
    <ol>
	      <li>
        <label for="menu-1-18"> Board of Directors  </label>
        <input type="checkbox" id="menu-1-18" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1688892428Board of Directors.pdf">Board of Directors</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-1-41"> Board Committees </label>
        <input type="checkbox" id="menu-1-41" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1686130582Committees.pdf">Board Committees</a></li>
	        </ol> 
      </li>
     	    </ol>
  </li>
	  <li>
    <label for="menu-2"> Financials</label>
    <input type="checkbox" id="menu-2" />
    <ol>
	      <li>
        <label for="menu-2-37"> Half yearly & Quarterly Results </label>
        <input type="checkbox" id="menu-2-37" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1762782817Financial Results .pdf">Results for the Quarter and Half Year ended 30-09-2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1754145017BM - Outcome_compressed --222.pdf">Results for the quarter ended 30-06-2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1748500735Q4-2024-25-Results.pdf">Results for the quarter and year ended March 31, 2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1739369912Financial Results.pdf">Results for the quarter ended 31-12-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/17320168871731586949Outcome.pdf">Results for the quarter ended 30-09-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1723031626Results.pdf">Results for the quarter ended 30-06-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1715157426BM Financials.pdf">Results for the quarter and year ended March 31, 2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1706702271BMOutcome.pdf">Results for the quarter and nine months ended 31.12.2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1699442780Q-2 Results.pdf">RESULTS FOR HALF YEAR AND QUARTER ENDED 30-09-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1693482688Result.pdf">Results for the quarter ended 30-06-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1684573586OU.pdf">Results for the quarter and year ended March 31, 2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1675686352RR.pdf">Results for the quarter and nine months ended 31.12.2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1666856925FR.pdf">RESULTS FOR HALF YEAR AND QUARTER ENDED 30-09-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1660286559Results.pdf">Results for the quarter ended 30-06-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1652280103BM Outcome.pdf">Results for the quarter and year ended March 31, 2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1643804383Outcome.pdf">Results for the quarter and nine months ended 31.12.2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1635339055Outcome Final27102021.pdf">RESULTS FOR HALF YEAR AND QUARTER ENDED 30-09-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1627909854Outcome.pdf">Results for the quarter ended 30-06-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1622090631Financials.pdf">Results for the quarter and year ended March 31, 2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1612786884RESULTS.pdf">Results for the quarter and nine months ended 31.12.2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1603886769RESULTS Q22020.pdf">RESULTS FOR HALF YEAR AND QUARTER ENDED 30-09-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1597237119Financials.pdf">Results for the quarter ended 30-06-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1592832734Results19-20.pdf">Results for the Quarter and Year Ended March 31, 2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1580388664BM Outcome.pdf">Results for Quarter & Nine Months ended 31-12-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1572439872BM OUTCOME-2-17.pdf">RESULTS FOR HALF YEAR AND QUARTER ENDED 30-09-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1564207697Outcome final.pdf">Results for the quarter ended 30-06-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1557928223Q4_31032019.PDF">Results for the year ended and quarter ended 31/03/2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1548678999OUTCOME.pdf">Results for Quarter & Nine Months ended 31-12-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1540986847outcome 30092018.pdf">RESULTS FOR HALF YEAR AND QUARTER ENDED 30-09-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1532354616Results.pdf">Results for the quarter ended 30-06-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1527944247Financial Year Results(1).pdf">Results for the year ended: 31-03-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1526304771outcome of Board Meeting.pdf">Results for the year ended: 31-03-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1517230806Results_17-18_Q3.pdf">Results for the Quarter & Nine Months ended December 31, 2017</a></li>
			<li class="file"><a target="_blank" href="pdf/15126736911509818632Results300917.pdf">RESULTS FOR THE HALF YEAR AND QUARTER ENDED 30-09-2017</a></li>
			<li class="file"><a target="_blank" href="pdf/15126736461507487831Results for the quarter ended 30-06-2017.pdf">Results for the quarter ended 30-06-2017</a></li>
			<li class="file"><a target="_blank" href="pdf/15126736121507487797Results for the year ended 31_03_2017.pdf">Results for the quarter ended: 31-03-2017</a></li>
			<li class="file"><a target="_blank" href="pdf/15126735751507487759FY2016-17Q3.pdf">Results for the quarter ended: 31-12-2016</a></li>
			<li class="file"><a target="_blank" href="pdf/15126735191507487628FY2016-17Q2.pdf">Results for the quarter ended: 30-09-2016</a></li>
			<li class="file"><a target="_blank" href="pdf/15126734771507487605FY16-17Q1.pdf">Results for the quarter ended: 30-06-2016</a></li>
			<li class="file"><a target="_blank" href="pdf/15126734061507487515FY15-16.pdf">Results for the year ended: 31-03-2016</a></li>
			<li class="file"><a target="_blank" href="pdf/1512673325150748748831_12_2015.pdf">Results for the quarter & Nine months ended: 31-12-2015</a></li>
			<li class="file"><a target="_blank" href="pdf/15126732421507487422FY15-16Q2.pdf">Results for the quarter ended: 30-09-2015</a></li>
			<li class="file"><a target="_blank" href="pdf/15126731761507487359FY15-16Q1.pdf">Results for the quarter ended: 30-06-2015</a></li>
			<li class="file"><a target="_blank" href="pdf/15126731221507487328FY14-15.pdf">Results for the year ended: 31-03-2015</a></li>
			<li class="file"><a target="_blank" href="pdf/1512673084150748725330_09_2014.pdf">Results for the quarter & half year ended: 30-09-2014</a></li>
			<li class="file"><a target="_blank" href="pdf/151267301315074870721507454524BAlaji Blank.pdf">Results for the quarter ended: 30-06-2014</a></li>
			<li class="file"><a target="_blank" href="pdf/151267297715074870721507454524BAlaji Blank.pdf">Results for the year ended: 31-03-2014</a></li>
			<li class="file"><a target="_blank" href="pdf/151267292615074870381507454524BAlaji Blank.pdf">Results for the quarter & Nine months ended: 31-12-2013</a></li>
			<li class="file"><a target="_blank" href="pdf/151267286115074869881507454524BAlaji Blank.pdf">Results for the quarter & half year ended: 30-09-2013</a></li>
			<li class="file"><a target="_blank" href="pdf/151267280615074869641507454524BAlaji Blank.pdf">Results for the quarter ended: 30-06-2013</a></li>
			<li class="file"><a target="_blank" href="pdf/151267268615074869351507454524BAlaji Blank.pdf">Results for the year ended: 31-03-2013</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-2-52"> Subsidiary Company Accounts </label>
        <input type="checkbox" id="menu-2-52" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1722666023BSCL.pdf">Results for the year ended 31-03-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1688890548BSCL financial results.pdf">Results for the year ended 31-03-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1652280243BSCL Results for the year ended 31-03-2022.pdf">Results for the year ended 31-03-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1628165860BSCPL Audit Report & Financial Statements.pdf">Results for the year ended 31-03-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1594809030BSCPL Financials 2019-20.pdf">Results for the year ended 31-03-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1559641391BSCPL AUDIT REPORT & FINANCIALS 2018-19.pdf">Results for the year ended 31-03-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1559641259BSCPL-MARCH-2018.pdf">Results for the year ended 31-03-2018</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-2-109"> Integrated Filing (Financials) </label>
        <input type="checkbox" id="menu-2-109" />
        <ol>
		        </ol> 
      </li>
     	    </ol>
  </li>
	  <li>
    <label for="menu-3">Annual Reports</label>
    <input type="checkbox" id="menu-3" />
    <ol>
	      <li>
        <label for="menu-3-40"> Annual Reports Balaji Amines Limited </label>
        <input type="checkbox" id="menu-3-40" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1753859362Balaji Amines Annual Report 2024-25 (Spread Page).pdf">Balaji Amines Ltd. 37th Annual Report 2024-25</a></li>
			<li class="file"><a target="_blank" href="pdf/1718692294BalajiAminesLimitedAnnualReport2023-24.pdf">Balaji Amines Ltd. 36th Annual Report 2023-24</a></li>
			<li class="file"><a target="_blank" href="pdf/1687063252Annual Report 2022-23.pdf">Balaji Amines Ltd. 35th Annual Report 2022-23</a></li>
			<li class="file"><a target="_blank" href="pdf/1654777806Corrigendum file.pdf">Corrigendum Letter to 34th Annual Report</a></li>
			<li class="file"><a target="_blank" href="pdf/1654777702AR2022.pdf">Balaji Amines Ltd. 34th Annual Report 2021-22 Revised</a></li>
			<li class="file"><a target="_blank" href="pdf/1654319553Balaji Amines Ltd AR.pdf">Balaji Amines Ltd. 34th Annual Report 2021-22</a></li>
			<li class="file"><a target="_blank" href="pdf/1626348421Annual_Report_2020-21.pdf">Balaji Amines Ltd. 33rd Annual Report 2020-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1594640113AnnualReport2019-20.pdf">Balaji Amines Ltd. 32nd Annual Report 2019-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1561710432AnnualReport2018-19.pdf">Balaji Amines Ltd. 31st Annual Report 2018-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/AnnualReport2017-18.pdf">Balaji Amines Ltd. 30th Annual Report 2017-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/15126747911507488809AR2016-17.pdf">Balaji Amines Ltd. 29th Annual Report 2016-2017</a></li>
			<li class="file"><a target="_blank" href="pdf/15126747601507488772AR_2015-16.pdf">Balaji Amines Ltd. 28th Annual Report 2015-2016</a></li>
			<li class="file"><a target="_blank" href="pdf/15126747411507488728AR_2014-15.pdf">Balaji Amines Ltd. 27th Annual Report 2014-2015</a></li>
			<li class="file"><a target="_blank" href="pdf/15126747161507488694AR_2013-14.pdf">Balaji Amines Ltd. 26th Annual Report 2013-2014</a></li>
			<li class="file"><a target="_blank" href="pdf/15126746911507488425Balaji Amines AR_2013.pdf">Balaji Amines Ltd. 25th Annual Report 2012-2013</a></li>
			<li class="file"><a target="_blank" href="pdf/15126746551507488346Balaji Amines AR 2011-12.pdf">Balaji Amines Ltd. 24th Annual Report 2011-2012</a></li>
			<li class="file"><a target="_blank" href="pdf/15126746271507488278Balaji Amines Ltd_AR 2010-11.pdf">Balaji Amines Ltd. 23th Annual Report 2010-2011</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-3-49"> Annual Reports Balaji Speciality Chemicals Pvt. Ltd. </label>
        <input type="checkbox" id="menu-3-49" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1752571647BSCL Annual Report 2025.pdf">BSCL Annual Report 2024-25</a></li>
			<li class="file"><a target="_blank" href="pdf/1718721395BSCL Annual Report 2023-24.pdf">BSCL Annual Report 2023-24</a></li>
			<li class="file"><a target="_blank" href="pdf/1686654764BSCL Annual Report 2022-23.pdf">BSCL Annual Report 2022-23</a></li>
			<li class="file"><a target="_blank" href="pdf/1665120664BSCL Annual Report 2021-22.pdf">BSCL Annual Report 2021-22</a></li>
			<li class="file"><a target="_blank" href="pdf/1628227679BSCPL.pdf">BSCPL Annual Report 2020-21</a></li>
			<li class="file"><a target="_blank" href="pdf/1596777287BSCPL Annual Report 2019-20.pdf">BSCPL Annual Report 2019-20</a></li>
			<li class="file"><a target="_blank" href="pdf/1596776501BSCPL Annual Report 2018-19.pdf">BSCPL Annual Report 2018-19</a></li>
			<li class="file"><a target="_blank" href="pdf/1596775841BSCPL AR -2017-18.pdf">BSCPL Annual Report 2017-18</a></li>
	        </ol> 
      </li>
     	    </ol>
  </li>
	  <li>
    <label for="menu-4">Announcements</label>
    <input type="checkbox" id="menu-4" />
    <ol>
	      <li>
        <label for="menu-4-19"> Stock Exchnages intimation - Announcements  </label>
        <input type="checkbox" id="menu-4-19" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1763993462Disclosure_ Signed.pdf">24.11.2025_Disclosure under Regulation 30</a></li>
			<li class="file"><a target="_blank" href="pdf/1760461132Clarification_Signed.pdf">Clarification to the Article published in Economic TImes ‘e paper’ dated 14th October, 2025 </a></li>
			<li class="file"><a target="_blank" href="pdf/1757683611Intimation to shareholders SE_Signed.pdf">Intimation to Shareholders 12.09.25</a></li>
			<li class="file"><a target="_blank" href="pdf/1751287374Intimation_Signed.pdf">30.06.2025_Intimation of Commencement of Commercial Production</a></li>
			<li class="file"><a target="_blank" href="pdf/1750847262INTIMATION_Signed.pdf">25.06.2025 Consent to Operate the Manufacture of ISOPROPYLAMINE (MIPA/ DIPA)</a></li>
			<li class="file"><a target="_blank" href="pdf/1743684973Intimatiion.pdf">03.04.2025 Commissioning of Solar Power Plant</a></li>
			<li class="file"><a target="_blank" href="pdf/1740148352Intimation.pdf">21-01-2025 Postal Ballot Notice</a></li>
			<li class="file"><a target="_blank" href="pdf/1732509600Outcome.pdf">14-11-2024 Resignation and Appointment of Company Secretary</a></li>
			<li class="file"><a target="_blank" href="pdf/1731241370Intimation.pdf">10-11-2024 Intimation of commencement of commercial production of new Methylamines plant </a></li>
			<li class="file"><a target="_blank" href="pdf/1723626510SEIntimation.pdf">14-08-2024 Intimation regarding Grant of Environmental Clearance (EC) to the proposed Greenfield Project of Balaji Speciality Chemicals Limited, Material Subsidiary Company</a></li>
			<li class="file"><a target="_blank" href="pdf/1710397557CreditRating.pdf">14-03-2024 Credit Rating</a></li>
			<li class="file"><a target="_blank" href="pdf/1706721147Regulation30.pdf">31-01-2024 Intimation of Expansion Projects</a></li>
			<li class="file"><a target="_blank" href="pdf/1705497923IntimationSE.pdf">17-01-2024 Intimation of BIS Certification for the Product “Morpholine” as per IS 12084:2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1705396578IntimationSE.pdf">16-01-2024 Intimation of commencement of commercial production of N-butylamines </a></li>
			<li class="file"><a target="_blank" href="pdf/1703665323BSE Clarification.pdf">27-12-2023 Clarification on Movement in Price</a></li>
			<li class="file"><a target="_blank" href="pdf/1701939550Reply to BSE.pdf">07-12-2023 Clarification on Movement in Price</a></li>
			<li class="file"><a target="_blank" href="pdf/16995131428e0c55aa-465e-4aa2-9e1d-0c17f22ad8b1.pdf">04-11-2023 Resignation Of Senior Management Personnel</a></li>
			<li class="file"><a target="_blank" href="pdf/1694167658Intimation.pdf">08-09-2023 Intimation regarding withdrawal of the Draft Red Herring Prospectus dated August 10, 2022 ("DRHP") filed with the Securities and Exchange Board of India (“SEBI”) by Balaji Speciality Chemicals Limited (“BSCL”)</a></li>
			<li class="file"><a target="_blank" href="pdf/1692170924ClarificationLetter.pdf">16-08-2023 Clarification Letter </a></li>
			<li class="file"><a target="_blank" href="pdf/1692033338Intimation.pdf">14-08-2023  Results-Delay in Financial Results</a></li>
			<li class="file"><a target="_blank" href="pdf/1684663455IntimationResignation.pdf">20-05-2023 Resignation of Whole-Time Director and Chief Financial Officer</a></li>
			<li class="file"><a target="_blank" href="pdf/1684663324IntimationChangeIndesignation.pdf">20-05-2023 Change in Designation of Directors</a></li>
			<li class="file"><a target="_blank" href="pdf/1684663271IntimationAppointment.pdf">20-05-2023 Appointment of Independent Directors</a></li>
			<li class="file"><a target="_blank" href="pdf/1684663209IntimationResignation.pdf">20-05-2023 Resignation of Directors</a></li>
			<li class="file"><a target="_blank" href="pdf/1682847122RTA.pdf">30-04-2023 Intimation regarding change in address of Registrar and Share Transfer Agent (RTA) of the Company</a></li>
			<li class="file"><a target="_blank" href="pdf/16818779688fb19b9c-a507-450f-8922-1a2f37e999de.pdf">18-04-2023 Issue of Duplicate Share Certificate of Mr. Haresh M Changlani</a></li>
			<li class="file"><a target="_blank" href="pdf/1680522288Duplicate.pdf">03-04-2023 Intimation of Loss of Share Certificate of Mr. Haresh M Changlani</a></li>
			<li class="file"><a target="_blank" href="pdf/1675687011Intimation.pdf">05-02-2023 Grant of Environmental Clearance (EC) to the proposed expansion project at Solapur</a></li>
			<li class="file"><a target="_blank" href="pdf/1673881130CreditRating.pdf">12-01-2023 Credit Rating</a></li>
			<li class="file"><a target="_blank" href="pdf/16648004711664169760DMC SE.pdf">26-09-2022 Intimation of commencement of commercial production of DMC at MIDC, Chincholi, Solapur</a></li>
			<li class="file"><a target="_blank" href="pdf/1664800378intimation.pdf">05-09-2022 Issue of Duplicate Share Certificate of Mr. Himanshu, Mr. Virendra & Mr. Madan</a></li>
			<li class="file"><a target="_blank" href="pdf/1664800174madan.pdf">29-08-2022 Intimation of Loss of Share Certificate of Mr. Madan Lal Kaplish</a></li>
			<li class="file"><a target="_blank" href="pdf/1660969284Letter.pdf">19-08-2022 Intimation of Loss of Share Certificate of Mr. Himanshu J. Patel & Mr. Virendra Kumar Singh</a></li>
			<li class="file"><a target="_blank" href="pdf/1654169496IPO.pdf">01-06-2022 Proposed Initial Public offering of Equity Shares of Face Value of Rs. 2 Each ('Equity Shares') by the Company's Material Subsidiary, Balaji Speciality Chemicals Limited</a></li>
			<li class="file"><a target="_blank" href="pdf/163826524924.pdf">24-11-2021 Issue of Duplicate Share Certificate of Ms. Sunita Deva, Ms. Sharada Deva & Mr. Sadasivarao Deva</a></li>
			<li class="file"><a target="_blank" href="pdf/1637728367INTIMATION OF COMMENCEMENT OF DMF PLANT.pdf">23-11-2021 Intimation of Commencement of DMF Plant</a></li>
			<li class="file"><a target="_blank" href="pdf/1636802927issueofduplicate.pdf">13-11-2021 Issue of Duplicate Share Certificate of Mr. Divakar Reddy Bendram, Mr. Ramesh Reddy Y & Mrs. sunita Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1636529364Intimationlossofsharecertificate.pdf">09-11-2021 Intimation of Loss of Share Certificate of Mr. Deva Family</a></li>
			<li class="file"><a target="_blank" href="pdf/1635426521Lossofduplicate.pdf">25-10-2021 Intimation of Loss of Share Certificate of Mr. Ramesh Reddy Y & Mrs. Suneetha Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1635327502Credit Ratings.pdf">27-10-2021 Credit Rating India Ratings & Research</a></li>
			<li class="file"><a target="_blank" href="pdf/1635166107Loss of Share Certificate.pdf">25-10-2021 Intimation of Loss of Share Certificate of Mr. Divakar Reddy Bendram</a></li>
			<li class="file"><a target="_blank" href="pdf/1633668494Intimationof Breakdown ofPlant.pdf">06-10-2021 Intimation of Breakdown of Plant</a></li>
			<li class="file"><a target="_blank" href="pdf/1631793382Duplicate.pdf">16-09-2021 Issue of Duplicate Share Certificate of Shah Nandkishore Motital Shah Priti Nandkishore</a></li>
			<li class="file"><a target="_blank" href="pdf/1631086498Loss of Share Certificate_Intimation.pdf">07-09-2021 Intimation of Loss of Share Certificate of Mr. SHAH NANDKISHOR MOTITAL </a></li>
			<li class="file"><a target="_blank" href="pdf/1627986554IntimationtoSEAcetonitirle.pdf">03-08-2021 Setting up of new plant for manufacture of Acetonitirle</a></li>
			<li class="file"><a target="_blank" href="pdf/1625060703CSAppointment.pdf">30-06-2021 Appointment of Company Secretary & Compliance Officer</a></li>
			<li class="file"><a target="_blank" href="pdf/1621591256intimation.pdf">21-05-2021 Commissioning of first phase of green field project of the company at Unit - IV</a></li>
			<li class="file"><a target="_blank" href="pdf/1618486820CreditRating.pdf">15-04-2021 Credit Rating India Ratings & Research</a></li>
			<li class="file"><a target="_blank" href="pdf/1611298313CSDemise.pdf">22-01-2021 Intimation of Sad Demise of Ms Jimisha Parth Dawda, Company Secretary and Compliance Officer of the Company</a></li>
			<li class="file"><a target="_blank" href="pdf/1604311776Clarificationletter.pdf">Clarification on Outcome of Board Meeting held on 28th October, 2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1603427652MURUGA VELLAICHAMYduplicateshrecertificate22102020.pdf">22-10-2020 Issue of Duplicate Share Certificate of muruga vellaichamy r</a></li>
			<li class="file"><a target="_blank" href="pdf/1602228313SubmissionofinfolossofSC.pdf">09-10-2020 Intimation of Loss of Share Certificate of Mr. MURUGA VELLAICHEMY R </a></li>
			<li class="file"><a target="_blank" href="pdf/1585812027ilovepdf_merged.pdf">01-04-2020 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1585115450Intimation.pdf">24-03-2020 Intimation for temporary Disruption of Company 's Business Operations due to COVID-19</a></li>
			<li class="file"><a target="_blank" href="pdf/1582714020final.pdf">26-02-2020 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1580985401PIT Disclosure ASR.pdf">06-02-2020 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1580885475PIT.pdf">05-02-2020 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1580361348Credit Rating.pdf">29-01-2020 Credit Rating India Ratings & Research</a></li>
			<li class="file"><a target="_blank" href="pdf/1576233456PIT ASD.pdf">13-12-2019 Disclosure under PIT Regulations Mrs. A. Shakuntala Devi</a></li>
			<li class="file"><a target="_blank" href="pdf/1576142372PIT.pdf">12-12-2019 Disclosure under PIT Regulations Mrs. A. Shakuntala Devi</a></li>
			<li class="file"><a target="_blank" href="pdf/1575455709PIT ASR.pdf">04-12-2019 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1575098076PIT.pdf">30-11-2019  Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1575012950PIT.pdf">29-11-2019 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1574935187Environmental Clearance.pdf">27-11-2019 Ministry of Environment Clearance for Unit-IV</a></li>
			<li class="file"><a target="_blank" href="pdf/1572612410RTA Letter.pdf">01-11-2019 Intimation of RTA Reappointment</a></li>
			<li class="file"><a target="_blank" href="pdf/1569324248PIT.pdf">24-09-2019 Disclosure under PIT Regulations Mr. A. Srinivas Reddy </a></li>
			<li class="file"><a target="_blank" href="pdf/1568712759ilovepdf_merged (7).pdf">17-09-2019 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1568696781final965.pdf">14-09-2019 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1568696245final1015.pdf">13-09-2019 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1568695864final1070.pdf">11-09-2019 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1568189215FORM C ASR.pdf">11-09-2019 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1566475581PIT Eeshan.pdf">22-08-2019 Disclosure under PIT Regulations Mr. N. Eeshan Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1566300857Eeshan.pdf">20-08-2019 Disclosure under PIT Regulations Mr. N. Eeshan Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1565786999ASR.pdf">14-08-2019 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1565244367Intimation.pdf">08-08-2019 Disclosure under PIT Regulations Mr. G. Hemanth Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1565156988Intimation.pdf">07-08-2019 Disclosure under PIT Regulations Mr. G. Hemanth Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1565075958Intimation.pdf">06-08-2019 Disclosure under PIT Regulations Mr. G. Hemanth Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1564988882GHR.pdf">03-08-2019 Disclosure under PIT Regulations Mr. G. Hemanth Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1564983133eeshan.pdf">01-08-2019 Disclosure under PIT Regulations Mr. N. Eeshan Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1564642986PITVandana.pdf">31-07-2019 Disclosure under PIT Regulations Mrs. D. Vandana Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1561185703GHR.pdf">21-06-2019 Disclosure under PIT Regulations Mr. G. Hemanth Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1560405245DRR sir 2.pdf">13-06-2019 Disclosure under PIT Regulations Mr. D. Ram Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1560257266DRR-rotated.pdf">11-06-2019 Disclosure under PIT Regulations Mr. D. Ram Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1560241481Consent.pdf">11-06-2019 Consent from MPCB - BSCPL</a></li>
			<li class="file"><a target="_blank" href="pdf/1559981214APR.pdf">08-06-2019 Disclosure under PIT Regulations Mr. A. Prathap Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1559909642APR sir.pdf">07-06-2019 Disclosure under PIT Regulations Mr. A. Prathap Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1558787033Besker.pdf">25-05-2019 Issue of Duplicate Share Certificate</a></li>
			<li class="file"><a target="_blank" href="pdf/1558012672Updates.PDF">15-05-2019 Consent from MPCB</a></li>
			<li class="file"><a target="_blank" href="pdf/1556627209Large Entities.pdf">30-04-2019 Large Corporate Disclosure-Non applicability</a></li>
			<li class="file"><a target="_blank" href="pdf/1555054537Besker Intimation.pdf">12-04-2019 Intimation of Loss of Share Certificate Besker</a></li>
			<li class="file"><a target="_blank" href="pdf/1553492427IntimationtoSE2532019.pdf">25-03-2019 Announcement under Regulation 30 SEBI PIT Code </a></li>
			<li class="file"><a target="_blank" href="pdf/1549369590APR SIR.pdf">05.02.2019 Disclosure under PIT Regulations Mr. A. Prathap Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1549084490issue of duplicate share certificate.pdf">02-02-2019 Issue of Duplicate Share Certificate </a></li>
			<li class="file"><a target="_blank" href="pdf/1546952567Submission of Loss of Share Certificate.pdf">08-01-2019 Intimation of Loss of Share Certificate Astakala Vidyacharan</a></li>
			<li class="file"><a target="_blank" href="pdf/1545397588CREDIT RATING 21122018.pdf">21-12-18 Credit Rating India Ratings & Research</a></li>
			<li class="file"><a target="_blank" href="pdf/1538205550Intimation to Stock Exchange of Manik Gund .pdf">29.09.2018 Intimation of regarding Issue of Duplicate Share Certificate </a></li>
			<li class="file"><a target="_blank" href="pdf/1536229780APRDISCLOSURE.pdf">06.09.2018 Disclosure under PIT Regulations A. Prathap Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1528527412A Prathap Reddy Sir.pdf">07.06.2018 Disclosure under PIT Regulations A. Prathap Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1526357317Appointment of Managing Director.pdf">14-05-2018 Appointment of Mr. D. Ram Reddy as Managing Director</a></li>
			<li class="file"><a target="_blank" href="pdf/1522231189Stock Exchange Intimation Letter.pdf">28-03-2018 Investment in Balaji Speciality Chemicals Private Limited</a></li>
			<li class="file"><a target="_blank" href="pdf/1519303391ANTIDUMPING.pdf">22-2-2018 Anti-dumping duty concerning imports of ‘Dimethylacetamide’ </a></li>
			<li class="file"><a target="_blank" href="pdf/1519123465FINALMERGERLETTERSE.pdf">20-02-2018 Order of Scheme of Amalgamation   </a></li>
			<li class="file"><a target="_blank" href="pdf/151267550001 05-12-17 Credit Rating India Ratings & Research.pdf"> 05-12-17 Credit Rating India Ratings & Research</a></li>
			<li class="file"><a target="_blank" href="pdf/151267548902 04-12-17 Allotment of land to company.pdf"> 04-12-17 Allotment of land to company</a></li>
			<li class="file"><a target="_blank" href="pdf/151267547003 04-12-17 Mega Project.pdf"> 04-12-17 Mega Project</a></li>
			<li class="file"><a target="_blank" href="pdf/151267545304 20-11-17 Clarification on Increase in Volume -BSE.pdf">20-11-17 Clarification on Increase in Volume -BSE</a></li>
			<li class="file"><a target="_blank" href="pdf/151267542305 08-11-17 Clarification on Financial Results -Q2 2017.pdf"> 08-11-17 Clarification on Financial Results -Q2 2017</a></li>
			<li class="file"><a target="_blank" href="pdf/151267539506 30-10-17 Appointment of Company Secretary & Compliance Officer.pdf">30-10-17 Appointment of Company Secretary & Compliance Officer</a></li>
			<li class="file"><a target="_blank" href="pdf/151267537107 30-10-17 Approval of Investment in Balaji Speciality Chemicals Pvt Ltd.pdf">30-10-17 Approval of Investment in Balaji Speciality Chemicals Pvt Ltd</a></li>
			<li class="file"><a target="_blank" href="pdf/151267533208.pdf">10-17 Request from Mr. G. Raja Reddy - Reclassification</a></li>
			<li class="file"><a target="_blank" href="pdf/151267505809 19-07-17 Resignation of Company Secretary.pdf">19-07-17 Resignation of Company Secretary</a></li>
			<li class="file"><a target="_blank" href="pdf/151267502410 06-07-17 Ministry of Environment Clearance for Expansion.pdf">06-07-17 Ministry of Environment Clearance for Expansion</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-4-26">  Investors Calls and Conferences  </label>
        <input type="checkbox" id="menu-4-26" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1763194642Concall_Audio_Link_Signed.pdf">Concall_12.11.2024_Audio Recording Link</a></li>
			<li class="file"><a target="_blank" href="pdf/1763194592Concall_Signed.pdf">Preponement of Concall_12.11.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1763194563Concall_Signed.pdf">Concall_12.11.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1763194528Intimation_Signed.pdf">Investor Meet_27.06.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1763194376Audio Link_Intimation.pdf">Concall_19.06.2024_Audio Recording Link</a></li>
			<li class="file"><a target="_blank" href="pdf/1750134199Concall_Signed.pdf">Concall_19.06.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1748255576Intimation_Signed.pdf">Cancellation of Scheduled Earnings Conference Call.</a></li>
			<li class="file"><a target="_blank" href="pdf/1748251918Intimation.pdf">Concall_29.05.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1742619284Intimation.pdf">Investor Meet_31.03.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1740148135Investormeet.pdf">Investor Meet_26.02.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1733818375Investormeet.pdf">Investor Meet_16.12.2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1733749032Investormeet13.pdf">Investor Meet_13.12.2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1733748991Investormeet.pdf">Investor Meet_12.12.2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1732360153Intimation.pdf">Concall_19.11.2024_Transcript</a></li>
			<li class="file"><a target="_blank" href="pdf/1732035761Concall.pdf">Concall_19.11.2024_Audio Recording Link</a></li>
			<li class="file"><a target="_blank" href="pdf/1731475559Intimation.pdf">Concall_19.11.2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1725544337Intimation.pdf">Investor Meet_10.09.2024</a></li>
			<li class="file"><a target="_blank" href="pdf/17199213161.pdf">Investor Meet_04.07.2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1718631467Intimation.pdf">Investor Meet_21.06.2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1717407261intimation.pdf">Investor Meet_06.06.2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1715867256TranscriptSE.pdf">CONCALL_10.05.2024_Transcript</a></li>
			<li class="file"><a target="_blank" href="pdf/1715400765Audio.pdf">Concall_10.05.2024_Audio Recording Link</a></li>
			<li class="file"><a target="_blank" href="pdf/1715157302Concall.pdf">Concall_08.05.2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1711089480Intimation.pdf">Investor Meet 22.03.2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1703140512SEIntimation.pdf">Investor Meet_26.12.2023</a></li>
			<li class="file"><a target="_blank" href="pdf/16994200313d0523a4-0853-4e2a-a1a7-dc878afac715.pdf">Concall_08.11.2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1695206843InvestorMeet.pdf">Investor Meet_26.09.2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1694789217TranscriptSigned.pdf">Concall_08.09.2023_Transcript</a></li>
			<li class="file"><a target="_blank" href="pdf/1694188695Concall.pdf">Concall_08.09.2023_Audio Recording Link</a></li>
			<li class="file"><a target="_blank" href="pdf/1693845818IntimationConcall.pdf">Concall_08.09.2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1688034301InvestorMeet.pdf">Investor Meet_30.06.2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1684772665Concall.pdf">Concall_22.05.2023_Audio Recording Link</a></li>
			<li class="file"><a target="_blank" href="pdf/1684234266ConcallQ4FY23.pdf">Concall_22.05.2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1678341667BALInvestorMeet14032023.pdf">Investor Meet_14.03.2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1677243271BALInvestorMeet22.pdf">Investor Meet_22.02.2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1676544201Conference.pdf">Investor Meet_16.02.2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1672323482BALInvestorMeet29122022.pdf">Investor Meet_29.12.2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1671429302BALInvestorMeet19122022.pdf">Investor Meet_19.12.2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1670060192BALInvestor Meet.pdf">Investor Meet_03.12.2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1669695658Intimation.pdf">INVESTOR MEET_01122022</a></li>
			<li class="file"><a target="_blank" href="pdf/1664286247Investor Meet.pdf">Investor Meet_30.09.2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1652868796Transcipt Letter.pdf"> Transcript of Balaji Amines Q4 FY-22 Earnings Conference Call May 12, 2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1652266888BAL Conference Call Intimation.pdf">Concall_12.05.2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1648121255Stock.pdf">INVESTOR MEET_25032022</a></li>
			<li class="file"><a target="_blank" href="pdf/1647499557Investor Meet.pdf">INVESTOR MEET_17032022</a></li>
			<li class="file"><a target="_blank" href="pdf/1646834976BALInvestorConference.pdf">Investor Meet - 10.03.2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1645012498Transcript.pdf">Transcript of Balaji Amines Q3 FY-22 Earnings Conference Call February, 3 2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1643636354concall.pdf">CONCALL_31012022</a></li>
			<li class="file"><a target="_blank" href="pdf/1638864361Investor Meet.pdf">INVESTOR MEET_08122021</a></li>
			<li class="file"><a target="_blank" href="pdf/1636968294final transcript.pdf">Transcript of Balaji Amines Q2 FY-22 Earnings Conference Call October, 28 2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1634962847BALCONCALL.pdf">CONCALL_22102021</a></li>
			<li class="file"><a target="_blank" href="pdf/1629715755ConcallInvestormeet.pdf">INVESTOR MEET_23082021 (Virtual Meeting)</a></li>
			<li class="file"><a target="_blank" href="pdf/1629715676Final.pdf">Transcript of Balaji Amines Q4 FY-20 Earnings Conference Call  July, 29 2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1627558433CONCALL.pdf">CONCALL_29072021</a></li>
			<li class="file"><a target="_blank" href="pdf/1624528780Investor Meet - Motilal Oswal.pdf">INVESTOR MEET_24062021 (Virtual Meeting)</a></li>
			<li class="file"><a target="_blank" href="pdf/1623658651Investormeet.pdf">INVESTOR MEET_14062021 (Virtual Meeting)</a></li>
			<li class="file"><a target="_blank" href="pdf/1623152495Concalltranscript.pdf">Transcript of Balaji Amines Q4 FY-20 Earnings Conference Call May 26, 2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1622112413Investormeet.pdf">INVESTOR MEET_28052021</a></li>
			<li class="file"><a target="_blank" href="pdf/1621905566Concall24052021.pdf">Concall_26052021</a></li>
			<li class="file"><a target="_blank" href="pdf/1613990748concalltranscript.pdf">Transcript of Balaji Amines Q3 FY-21 Earnings Conference Call February 9, 2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1612613557CONCALL06022021.pdf">Concall_09022021</a></li>
			<li class="file"><a target="_blank" href="pdf/1608555253Intimationofinvestormeet.pdf">INVESTOR MEET_22122020 (Virtual Investor Conference)</a></li>
			<li class="file"><a target="_blank" href="pdf/1605954049Transcript of Call.pdf">Transcript of Balaji Amines Q2 FY-21 Earnings Conference Call November 2, 2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1603776066rescheduledBalaji Amines - Q2FY21 Earnings Call Invite.pdf">Concall_02112020[RESCHEDULED]</a></li>
			<li class="file"><a target="_blank" href="pdf/1603438046CONCALLQ2FY21.pdf">Concall_29102020</a></li>
			<li class="file"><a target="_blank" href="pdf/1598008953ConcallTranscript13082020.pdf">Transcript of Balaji Amines Q1 FY-21 Earnings Conference Call August 13, 2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1597213353concall12082020.pdf">Concall_13082020</a></li>
			<li class="file"><a target="_blank" href="pdf/1593755295transcript23062020.pdf">Transcript of Balaji Amines Q4 FY-20 Earnings Conference Call June 23, 2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1592918599Investormeet25062020.pdf">INVESTOR MEET_25062020 (Virtual Investor Conference)</a></li>
			<li class="file"><a target="_blank" href="pdf/1591945127BALCONCALL23062020.pdf">Concall_23062020</a></li>
			<li class="file"><a target="_blank" href="pdf/1581312337Transcript.pdf">Transcript of Balaji Amines Q3 FY-20 Earnings Conference Call February 3, 2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1580361428Concall.pdf">Concall_03022020</a></li>
			<li class="file"><a target="_blank" href="pdf/1575184585INVESTORCONFUPDATE.pdf">INVESTOR MEET_03122019</a></li>
			<li class="file"><a target="_blank" href="pdf/1573281099Transcript.pdf">Transcript of Balaji Amines Q2 FY-20 Earnings Conference Call November 01, 2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1571636322Concall.pdf">Concall_01112019</a></li>
			<li class="file"><a target="_blank" href="pdf/1569315566IntimationofScheduleanalyst.pdf">INVESTOR MEET_25092019</a></li>
			<li class="file"><a target="_blank" href="pdf/1564811944concalltranscript29072019.pdf">Transcript of Balaji Amines Q1 FY-20 Earnings Conference Call July 29, 2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1564811823Balaji Amines Q1 FY-20 Earnings Conference Call July 29, 2019.pdf">Balaji Amines Q1 FY-20 Earnings Conference Call July 29, 2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1561466007Intimation.pdf">INVESTOR MEET_26062019</a></li>
			<li class="file"><a target="_blank" href="pdf/1558675278CONCALL.pdf">"Balaji Amines Q4 FY-19 Earnings Conference Call" May 20, 2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1558012166Concall letter to SE.pdf">CONCALL_20052019</a></li>
			<li class="file"><a target="_blank" href="pdf/1555409966BALAJI INVESTOR PPT.pdf">Investor Presentation</a></li>
			<li class="file"><a target="_blank" href="pdf/1555074111Intimation of Schedule.pdf">INVESTOR MEET_15042019</a></li>
			<li class="file"><a target="_blank" href="pdf/1533270853Con Cal.pdf">"Balaji Amines Q1 FY-19 Earnings Conference Call" July 31, 2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1532854139CONCALL3172018.pdf">CONCALL_31072018</a></li>
			<li class="file"><a target="_blank" href="pdf/1528808844INTIMATION INVESTOR MEETING.pdf">CONCALL_14062018</a></li>
			<li class="file"><a target="_blank" href="pdf/1527142995Balaji Amines Q4 FY2018 Earnings Conference Call May 21, 2018.pdf">"Balaji Amines Q4 FY2018 Earnings Conference call" May 21, 2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1526617654CON CALL.pdf">CON CALL 21.05.2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1518777458Systematix-BalajiAmines-Feb14-2018 (2).pdf">“Balaji Amines Q3 FY2018 Earnings Conference Call” February 14, 2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1517992498CONCALL14022018.pdf">CON CALL 14.2.2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1512677649150749007104_Concall_10072017.pdf">Concall_10072017</a></li>
			<li class="file"><a target="_blank" href="pdf/1512677625150749001903_Concall_14022017.pdf">Concall_14022017</a></li>
			<li class="file"><a target="_blank" href="pdf/1512677588150748995302_AmbitCap_27012017.pdf">AmbitCap_27012017</a></li>
			<li class="file"><a target="_blank" href="pdf/1512677539150748991301_Concall_28102016.pdf">Concall_28102016</a></li>
	        </ol> 
      </li>
     	    </ol>
  </li>
	  <li>
    <label for="menu-5">Board Meetings</label>
    <input type="checkbox" id="menu-5" />
    <ol>
	      <li>
        <label for="menu-5-20"> Notice of Board Meeting & Trading Windows </label>
        <input type="checkbox" id="menu-5-20" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1762009058Intimation_Signed.pdf">Notice 01.11.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1753598708Intimation_Signed.pdf">Notice 24.07.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1748251788Intimation_Signed.pdf">Notice 25.05.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1747492097Intimation_Signed.pdf">Notice 17.05.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1738762250BM Intimation.pdf">Notice 05.02.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1730901140BMIntimation.pdf">Notice 06.11.2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1722001929Intimation.pdf">Notice 26-07-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1714551218Intimation.pdf">Notice 01-05-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1711716161TW.pdf">Notice 24-01-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1698846806BMINTIMATION.pdf">Notice 01-11-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1692631109BMIntimation.pdf">Notice 21-08-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1683979438IntimationofBoardMeeting.pdf">Notice 13-05-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1675067511BM.pdf">Notice 30-01-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1666189227BM Intimation.pdf">Notice 19-10-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1660895446Notice 12-08-2022.pdf">Notice 12-08-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1651551759BM Intimation.pdf">Notice 02-05-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1643093776BMIntimation.pdf">Notice 02-02-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1634618086Intimation of Board Meeting.pdf">Notice 27-10-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1626958779IntimationofBM.pdf">Notice 22-07-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1621002641intimation.pdf">Notice 14-05-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/161122875721-01-2021.pdf">Notice 21-01-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1609402193INTIMATIONOFBOARDMEETING.pdf">Notice 27-01-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1603279863preponeofbm28102020.pdf">Notice 28-10-2020[RESCHEDULED]</a></li>
			<li class="file"><a target="_blank" href="pdf/1601963393intimationofBM30092020.pdf">Notice 30-10-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1596183574INTIMATIONBM.pdf">Notice 12-08-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1591682479BMINTIMATION22062020.pdf">Notice 22-06-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1582698976Intimation of Board Meeting.pdf">Notice 09-03-20</a></li>
			<li class="file"><a target="_blank" href="pdf/1577517961Intimation of Board Meeting to SE.pdf">Notice 30-01-20</a></li>
			<li class="file"><a target="_blank" href="pdf/1577517874Intimationbm.pdf">Notice 30-10-19</a></li>
			<li class="file"><a target="_blank" href="pdf/1562321365Intimation of BM to SE.pdf">Notice 26-07-19</a></li>
			<li class="file"><a target="_blank" href="pdf/1556627424intimation of BM.pdf">Notice 15-05-19</a></li>
			<li class="file"><a target="_blank" href="pdf/1547619034BM Intimation.pdf">Notice 28-01-19</a></li>
			<li class="file"><a target="_blank" href="pdf/1539674134Intimation of Bm.pdf">Notice 31-10-18</a></li>
			<li class="file"><a target="_blank" href="pdf/1531381813Notice 23-07-18 .pdf">Notice 23-07-18</a></li>
			<li class="file"><a target="_blank" href="pdf/1524653574INTIMATION.pdf">Notice 14-05-18</a></li>
			<li class="file"><a target="_blank" href="pdf/1515817531IntimationofBM29012018.pdf">Notice 29-01-18</a></li>
			<li class="file"><a target="_blank" href="pdf/151267639830-10-17.pdf">Notice 30-10-17</a></li>
			<li class="file"><a target="_blank" href="pdf/151267636327-07-17.pdf">Notice 27-07-17</a></li>
			<li class="file"><a target="_blank" href="pdf/151267633311-05-17.pdf">Notice 11-05-17</a></li>
			<li class="file"><a target="_blank" href="pdf/151267630206-02-17.pdf">Notice 06-02-17</a></li>
			<li class="file"><a target="_blank" href="pdf/15126762281507489759Notice 21_05_2016.pdf">Notice 21_05_2016</a></li>
			<li class="file"><a target="_blank" href="pdf/15126761981507489722Notice 20_01_2016.pdf">Notice 20_01_2016</a></li>
			<li class="file"><a target="_blank" href="pdf/15126761711507489689Notice 31_10_2015.pdf">Notice 31_10_2015</a></li>
			<li class="file"><a target="_blank" href="pdf/15126761351507489660Notice 30_07_2015.pdf">Notice 30_07_2015</a></li>
			<li class="file"><a target="_blank" href="pdf/15126761071507489623Notice 20_05_2015.pdf">Notice 20_05_2015</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-5-21">  Outcome of Board Meetings </label>
        <input type="checkbox" id="menu-5-21" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1762783976Financial Results .pdf">10.11.2025 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1762783919BM - Outcome_compressed --222.pdf">02.08.2025 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1748511129Results_signed.pdf">28-05-2025 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1739368947Outcome of BM-1.pdf">12-02-2025 Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1731585827Outcome.pdf">14-11-2024 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1731585775Outcome.pdf">14-11-2024 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1723031703Results.pdf">07-08-2024 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1715157538Financials.pdf">08-05-2024 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1706702038Outcome.pdf">31-01-2024 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1699442928Outcome.pdf">08-11-2023 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1693482566Results.pdf">31-08-2023 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1684573405Outcome Final.pdf">20-05-2023 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1675686085Results.pdf">06-02-2023 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1666857020Results.pdf">27-10-2022 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1660286349Results.pdf">12-08-2022 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1652266950BM Outcome.pdf">11-05-2022 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1643804282Outcome.pdf">02-02-2021 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1635338340Outcome Final27102021.pdf">27-10-2021 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1627909766Outcome.pdf">02-08-2021 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1627884690CSAppointment.pdf">30-06-2021 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1622090899finalfinancials.pdf">24-05-2021 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1612787062outcome.pdf">08-02-2021 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1603886016OUTCOMEBM28102020.pdf">28-10-2020 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1597237207Boardoutcome12082020.pdf">12-08-2020 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1592832995Outcome19-20.pdf">22-06-2020 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1583753471Outcome of BM.pdf">09-03-2020 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1580388874BM.PDF">30-01-2020 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1572439579BM OUTCOME.pdf">31-10-2019 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1564145153OUTCOMEUPLOAD.pdf">26-07-2019 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1557924880BMoutcome15052019.PDF">15-05-2019 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1548678612OUTCOME28012019.pdf">28-01-2019 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1540988136outcomeBM31102018.pdf">31-10-2018 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/1540988087230718BM Outcome .pdf">23-07-2018 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/154098807002062018FinancialResults02062018.pdf">02-06-2018 Revised Financial Results</a></li>
			<li class="file"><a target="_blank" href="pdf/1540987999140518outcome of Board Meeting.pdf">14-05-2018 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/151723093029-01-2018 BM Outcome.pdf">29-01-2018 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/151267660701 30-10-2017 BM Outcome.pdf">30-10-2017 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/151267658002 27-07-2017 BM Outcome.pdf"> 27-07-2017 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/151267655903 11-05-2017 BM Outcome.pdf"> 11-05-2017 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/151267654404 11-05-2017 BM Outcome.pdf">11-05-2017 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/151267652905 06-02-2017 BM Outcome.pdf">06-02-2017 BM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/151267650706 24-10-2016 BM Outcome (2).pdf">24-10-2016 BM Outcome (2)</a></li>
			<li class="file"><a target="_blank" href="pdf/151267646507 24-10-2016 BM Outcome.pdf">24-10-2016 BM Outcome</a></li>
	        </ol> 
      </li>
     	    </ol>
  </li>
	  <li>
    <label for="menu-6">Annual General Meetings (AGM)</label>
    <input type="checkbox" id="menu-6" />
    <ol>
	      <li>
        <label for="menu-6-22">  Book Closure </label>
        <input type="checkbox" id="menu-6-22" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1752143243Intimation_of_Record_ Date_Signed.pdf">37TH AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/1718459815Intimation.pdf">36TH AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/1686055352IntimationofBookClosure.pdf">35TH AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/1652268438IntinationofBookClosure.pdf">34th AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/1621905495BookClosure.pdf">33rd AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/1596968774Book closure.pdf">32nd AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/1558012708img20190516_18434527.pdf">31st AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/1532520128INTIMATIONOFBOOKCLOSURE.pdf">30th AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/151267674829th AGM.pdf">29th AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/151267672928th AGM.pdf">28th AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/151267671027th AGM.pdf">27th AGM</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-6-23"> Outcome of AGMs </label>
        <input type="checkbox" id="menu-6-23" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1754739473Outcome_Signed.pdf">08-08-2025 37th AGM Outcome and Voting Results</a></li>
			<li class="file"><a target="_blank" href="pdf/172087346336thAGM.pdf">11-07-2024 36th AGM Outcome & Voting Results</a></li>
			<li class="file"><a target="_blank" href="pdf/1689173303AGM Outcome.pdf">10-07-2023 35th AGM Outcome & Voting Results</a></li>
			<li class="file"><a target="_blank" href="pdf/1656669576Outcome 34th AGM.pdf">29-06-2022 34th AGM Outcome & Voting Results</a></li>
			<li class="file"><a target="_blank" href="pdf/1638861063agmoutcome.pdf">02-08-2021 33rd AGM Outcome & Voting Results</a></li>
			<li class="file"><a target="_blank" href="pdf/1596968360agmoutcome08082020.pdf">08-08-2020 32nd AGM Outcome & Voting Results</a></li>
			<li class="file"><a target="_blank" href="pdf/1564221254Outcome26072019.pdf">26-07-2019 31st AGM Outcome & Voting Results</a></li>
			<li class="file"><a target="_blank" href="pdf/1535784515Outcome (2).pdf">30-08-2018 30th AGM Outcome & Voting Results</a></li>
			<li class="file"><a target="_blank" href="pdf/31-07-2017 29th AGM Outcome & Voting Results.pdf">31-07-2017 29th AGM Outcome & Voting Results</a></li>
			<li class="file"><a target="_blank" href="pdf/01-08-16 28th AGM Outcome.pdf">01-08-16 28th AGM Outcome</a></li>
			<li class="file"><a target="_blank" href="pdf/151267692201-08-2016 28th AGM voting results.pdf">01-08-2016 28th AGM voting results</a></li>
			<li class="file"><a target="_blank" href="pdf/151267687329-07-2014 27th AGM Outcome & Voting Results.pdf">29-07-2014 27th AGM Outcome & Voting Results</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-6-24"> Proceeding of AGMs </label>
        <input type="checkbox" id="menu-6-24" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1754644307Proceedings.pdf">08-08-2025 37th AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/1720706224Proceedings.pdf">11-07-2024 36th AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/1689008191Proceedings.pdf">10-07-2023 35th AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/1656508275Proceedings.pdf">29-06-2022 34th AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/1628513624Proceedings.pdf">09-08-2021 33rd AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/1596884685AGMproceeding08082020.pdf">08-08-2020 32ND AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/1564137316proceedings of 31st AGM.pdf">26-07-2019 31st AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/1535634736proceedings.pdf">30-08-2018 30th AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/28th AGM.pdf">28th AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/151267717031-07-17 29th AGM.pdf">31-07-17 29th AGM</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-6-25"> Scrutinizers Reports for AGMs </label>
        <input type="checkbox" id="menu-6-25" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1754739312Outcome_Signed.pdf">37th AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/172087332936thAGM.pdf">36th AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/1689173297AGM Outcome.pdf">35th AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/165674043934th AGM.pdf">34th AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/1638264911agmoutcome.pdf">33rd AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/1596968626agmoutcome08082020.pdf">32nd AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/1564221390Outcome26072019.pdf">31st AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/1535784428Outcome (2).pdf">30th AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/s29th AGM.pdf">29th AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/28th AGM.pdf">28th AGM</a></li>
			<li class="file"><a target="_blank" href="pdf/151267723227th AGM.pdf">27th AGM</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-6-59"> Inspection Documents </label>
        <input type="checkbox" id="menu-6-59" />
        <ol>
		        </ol> 
      </li>
     	    </ol>
  </li>
	  <li>
    <label for="menu-7">Quarterly Compliances</label>
    <input type="checkbox" id="menu-7" />
    <ol>
	      <li>
        <label for="menu-7-27"> Quarterly Compliances - Shareholding pattern  </label>
        <input type="checkbox" id="menu-7-27" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/176138723630-09-2025 SP.pdf">30-09-2025 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1753176041Website.pdf">30-06-2025 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1744971022SHP-output.pdf">31-03-2025SP</a></li>
			<li class="file"><a target="_blank" href="pdf/173736097731-12-24 SP.pdf">31-12-2024 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1734931907SHP Sept 24.pdf">30-09-2024 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1722598227SHP.pdf">30-06-2024 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1713513330SP.pdf">31-03-2024 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1713513117SHP.pdf">31-12-2023 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1698901438SHP.pdf">30-09-2023 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1689656594SHP.pdf">30-06-2023 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1682398829SHP.pdf">31-03-2023 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1673881028SHP Dec 2022.pdf">31-12-2022 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1666357734SHP.pdf">30-09-2022 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1658205969SHP.pdf">30-06-2022 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1649933811SHP.pdf">31-03-2022 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1641815195SHP.pdf">31-12-2021 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1633775492SHP.pdf">30-09-2021 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1626775774shp.pdf">30-06-2021 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1619608601Share holding Pattern.pdf">31-03-2021 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1619608511SP.pdf">30-09-2020 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1594539494SHP30062020website.pdf">30-06-2020 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1587119379SHPforwebsite31032020.pdf">31-03-2020 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1579840802SHP 31122019.pdf">31-12-2019 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1571298185SHP WEBSITE.pdf">30-09-2019 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1563627204SHP.pdf">30-06-2019 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1554466875SHP.pdf">31-03-2019 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1546517201SHP.pdf">31-12-2018 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1539321654SP.pdf">30-09-2018 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/153146155330-06-2018 SP.pdf">30-06-2018 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1522928218SHP 31-3-18.PDF">31-03-2018 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1515563337SP31122017.pdf">31-12-2017 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/151267791801 30-09-2017 SP.pdf">30-09-2017 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/151267789902 30-06-2017 SP.pdf"> 30-06-2017 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/151267787603 31-03-2017 SP.pdf"> 31-03-2017 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/151267785004 31-12-2016 SP.pdf"> 31-12-2016 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/151267781705 30-09-2016 SP.pdf"> 30-09-2016 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/151267779806 30-06-2016 SP.pdf">30-06-2016 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/151267777507 31-03-2016 SP.pdf">31-03-2016 SP</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-7-28"> Quarterly Compliances - Corporate Governance Reports  </label>
        <input type="checkbox" id="menu-7-28" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/173744234731-12-24 CG.pdf">31-12-2024 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1732513321CG.pdf">30-09-2024 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1722598267CG.pdf">30-06-2024 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1713512964CG.pdf">31-03-2024 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1704862625CG.pdf">31-12-2023 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1697290113CG.pdf">30-09-2023 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1691752673CG.pdf">30-06-2023 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1682398698CG.pdf">31-03-2023 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1675258325CG Report.pdf">31-12-2022 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1666357696CG.pdf">30-09-2022 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1658207382CG June 2022.pdf">30-06-2022 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1649933863CG.pdf">31-03-2022 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1641974329cg.pdf">31-12-2021 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1634796284CG.PDF">30-09-2021 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1626775884CG.pdf">30-06-2021 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1618482901Corporate Governance.pdf">31-03-2021 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1610444833CG31122020.pdf">31-12-2020 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1601713812CGBAL30092020.pdf">30-09-2020 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1594539532CG30062020website.pdf">30-06-2020 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1587119431CGforwebiste31032020.pdf">31-03-2020 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1579840886CG 31122019.pdf">31-12-2019 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1570779307CG30092019.pdf">30-09-2019 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1562736867CG30062019forwebsite.pdf">30-06-2019 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1554466915CG.pdf">31-03-2019 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1546674764CG.pdf">31-12-2018 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1539321709CG.pdf">30-09-2018 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/153146156930-06-2018 CG .pdf">30-06-2018 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1523016062CG.PDF">31-03-2018 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/1515563443CG.pdf">31-12-2017 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/151267816501 30-09-2017 CG.pdf">30-09-2017 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/151267814302 30-06-2017 CG.pdf">30-06-2017 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/151267812103 31-03-2017 CG.pdf">31-03-2017 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/151267810504 31-12-2016 CG.pdf">31-12-2016 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/151267809105 30-09-2016 CG.pdf"> 30-09-2016 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/151267807606 30-06-2016 CG.pdf"> 30-06-2016 CG</a></li>
			<li class="file"><a target="_blank" href="pdf/151267806107 31-03-2016 CG.pdf">31-03-2016 CG</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-7-29"> Quarterly Compliances - Statement of Investor Complaints  </label>
        <input type="checkbox" id="menu-7-29" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1759582154BAL-Investor Complaints-30-09-2025.pdf">Q Ended 30-09-2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1753859781Investor Complaints.pdf">Q Ended 30-06-2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1744605681Investor Complaints (2).pdf">Q Ended 31-03-2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1736318721Statement of Investor Complaints.pdf">Q Ended 31-12-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1728644540IG.pdf">Q Ended 30-09-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1720100756Investor Compliants.pdf">Q Ended 30-06-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/171283015820240411155433.pdf">Q Ended 31-03-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1704345075Investor Complaints.pdf">Q Ended 31-12-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1696513053Investor Compliants.pdf">Q Ended 30-09-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1688572441IG1.pdf">Q Ended 30-06-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1688572241Investor Compliants.pdf">Q Ended 31-03-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1673000994Investor Compliants.pdf">Q Ended 31-12-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1665401695Investor Compliants.pdf">Q Ended 30-09-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1657025449InvestorCompliants.pdf">Q Ended 30-06-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1649078213InvestorCompliants.pdf">Q Ended 31-03-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1641281280Investor Complaints.pdf">Q Ended 31-12-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1633347115Investor Complaints.pdf">Q Ended 30-09-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1626065300Investorcompliants.pdf">Q Ended 30-06-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1618483014Investor Complaints.pdf">Q Ended 31-03-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1610346074133InvestorCompliantsQ32020.pdf">Q Ended 31-12-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/160189350313(3)investorcomplaintQ22020.pdf">Q Ended 30-09-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1594539566Investor complaints 30062020.pdf">Q Ended 30-06-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1586951010Investor Complaints.pdf">Q Ended 31-03-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1578135865Reg13(3).pdf">Q Ended 31-12-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1570428773Statement of Investor Compliants 13(3).pdf">Q Ended 30-09-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1564983450Statement of Investor Compliants.pdf">Q Ended 30-06-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1554466279Statement of Investor Compliants 13(3).pdf">Q Ended 31-03-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1546598647Statement of Investor Complaints 13(3).pdf">Q Ended 31-12-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1539323681Q Ended 31-09-2018.pdf">Q Ended 30-09-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1531461513Q Ended 30-06-2018.pdf">Q Ended 30-06-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1522928253INVESTER COMPLIENTS.pdf">Q Ended 31-03-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1515563474Statementofinvestorcompl311217.pdf">Q Ended 31-12-2017</a></li>
			<li class="file"><a target="_blank" href="pdf/151267842601 Q Ended 30-09-2017.pdf"> Q Ended 30-09-2017</a></li>
			<li class="file"><a target="_blank" href="pdf/151267840602 Q Ended 30-06-2017.pdf"> Q Ended 30-06-2017</a></li>
			<li class="file"><a target="_blank" href="pdf/151267837804 Q Ended 31-03-2017.pdf"> Q Ended 31-03-2017</a></li>
			<li class="file"><a target="_blank" href="pdf/151267836405 Q ended 31-12-2016.pdf"> Q ended 31-12-2016</a></li>
			<li class="file"><a target="_blank" href="pdf/151267833706 Q Ended 30-09-2016.pdf">Q Ended 30-09-2016</a></li>
			<li class="file"><a target="_blank" href="pdf/151267830207 Q Ended 30-06-2016.pdf">Q Ended 30-06-2016</a></li>
			<li class="file"><a target="_blank" href="pdf/151267824008 Q Ended 31-03-2016.pdf">Q Ended 31-03-2016</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-7-44"> Quarterly Compliance - Reconciliation of Share Capital Audit Report </label>
        <input type="checkbox" id="menu-7-44" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1753858226RSCA_Signed.pdf">Q Ended 30-06-2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1745929877RSCA_signed.pdf">Q Ended 31-03-2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1738129921RSCA Intimation.pdf">Q Ended 31-12-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1730266895RSCAWEB.pdf">Q Ended 30-09-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1721826711RSCANSE.pdf">Q Ended 30-06-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1713605487RSCA.pdf">Q Ended 31-03-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1711716488RSCA.pdf">Q Ended 31-12-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1698499563RSCA.pdf">Q Ended 30-09-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1690638707RSCA.pdf">Q Ended 30-06-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1682846772RSCA.pdf">Q Ended 31-03-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1674915120RSCA.pdf">Q Ended 31-12-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1666853876RSCA.pdf">Q Ended 30-09-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1658399020RSCA.pdf">Q Ended 30-06-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1649417362RSCA.pdf">Q Ended 31-03-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1643374406RSCA.pdf">Q Ended 31-12-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1634905689RSCA.pdf">Q Ended 30-09-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1626871215rsca30062021.pdf">Q Ended 30-06-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1619607854RSCA30032021.pdf">Q Ended 31-03-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1610345985RSCA55AQ32020.pdf">Q Ended 31-12-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1602138961Bal55AQ22020.pdf">Q Ended 30-09-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1594798403Reconciliation of Audit Report150720.pdf">Q Ended 30-06-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/158933043455A.pdf">Q Ended 31-03-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1579599072rsca.pdf">Q Ended 31-12-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1571395149RSCA 30092019.pdf">Q Ended 30-09-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1564983511RSCA 30062019.pdf">Q Ended 30-06-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1554898878Reconciliation of Share capital.pdf">Q Ended 31-03-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1546680569Reconciliation of Share Capital.pdf">Q Ended 31-12-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1540360034Reconciliaion of share Capital .pdf">Q Ended 30-09-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1532002057Q Ended 30-06-2018.pdf">Q Ended 30-06-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1524134245RSCA 31318.pdf">Q Ended 31-03-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1524134221RSCA 31122017.pdf">Q Ended 31-12-2017</a></li>
			<li class="file"><a target="_blank" href="pdf/1524134195Rsca 30092017.pdf">Q Ended 30-09-2017</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-7-56"> Quarterly Compliance - Certificate under Regulation 74(5) </label>
        <input type="checkbox" id="menu-7-56" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1759580285Certificate.pdf">Q Ended 30-09-2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1751551239Certificate_Signed.pdf">Q Ended 30-06-2025</a></li>
			<li class="file"><a target="_blank" href="pdf/174377387974(5)_signed.pdf">Q Ended 31-03-2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1736253065Certificate.pdf">Q Ended 31-12-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1728644298certificet .pdf">Q Ended 30-09-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/172010065774.pdf">Q Ended 30-06-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/171220466874.pdf">Q Ended 31-03-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/170434319174.pdf">Q Ended 31-12-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/169651309174_5.pdf">Q Ended 30-09-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/168857247774(5).pdf">Q Ended 30-06-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/168087201774.pdf">Q Ended 31-03-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1673001043Reg74.pdf">Q Ended 31-12-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/166540174574 5.pdf">Q Ended 30-09-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/165701863174.pdf">Q Ended 30-06-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/164907825174.pdf">Q Ended 31-03-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/164128132574(5).pdf">Q Ended 31-12-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/163334752074 5.pdf">Q Ended 30-09-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/162606532874.pdf">Q Ended 30-06-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/161855271174.pdf">Q Ended 31-03-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/161034571974(5)Q32020.pdf">Q Ended 31-12-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/160189087674(5) CoverlettercertificateQ22020.pdf">Q Ended 30-09-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1594539612745.pdf">Q Ended 30-06-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/158704878274 5.pdf">Q Ended 31-03-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1578135934Reg 74(5).pdf">Q Ended 31-12-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1570429647Certificate under Reg 74(5).pdf">Q Ended 30-09-2019</a></li>
	        </ol> 
      </li>
     	    </ol>
  </li>
	  <li>
    <label for="menu-8">Half yearly Compliances</label>
    <input type="checkbox" id="menu-8" />
    <ol>
	      <li>
        <label for="menu-8-30"> Half yearly Compliances - Compliance Certificate 7(3) </label>
        <input type="checkbox" id="menu-8-30" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1650285241BA.pdf">HY ended 31-03-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1618483144Reg.PDF">HY ended 31-03-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1601618510reg7(3).PDF">HY ended 30-09-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/158694940173.PDF">HY ended 31-03-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1570429536balaji.PDF">HY ended 30-09-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1570429192img20191007_11465821.pdf">HY ended 31-03-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1540452822Compliance Certificate 7(3) .PDF">HY ended 30-09-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1522928284BalajiAminesComplianceCertificate.pdf">HY ended 31-03-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1512678760HY ended 30-10-2017.pdf">HY ended 30-10-2017</a></li>
			<li class="file"><a target="_blank" href="pdf/1512678740HY ended 31-03-2017.pdf">HY ended 31-03-2017</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-8-31">  Half yearly Compliances - Compliance certificate 40(9)  </label>
        <input type="checkbox" id="menu-8-31" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/168284685440_9.pdf">Y Ended 31-03-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/167894208740(9).pdf">HY Ended 31-03-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/161960902040.pdf">HY Ended 31-03-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1602139419Bal40-9Q22020.pdf">HY Ended 30-09-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1589330563409.pdf">HY Ended 31-03-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1571395118Reg 40 9.pdf">HY Ended 30-09-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/155489891140(9).pdf">HY Ended 31-03-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1540454177Compliance Certificate 40(9).pdf">HY Ended 30-09-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1524110846Compliance Certificate under Regulation 40(9).pdf">HY Ended 31-03-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1512678852HY Ended 30-09-2017.pdf">HY Ended 30-09-2017</a></li>
			<li class="file"><a target="_blank" href="pdf/1512678822HY Ended 31-03-2017.pdf">HY Ended 31-03-2017</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-8-53"> Half Yearly Compliances - Related Party Transactions 23(9) </label>
        <input type="checkbox" id="menu-8-53" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1763529421RPT.pdf">HY Ended 30-09-2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1752662620RPT Meged.pdf">HY Ended 31-03-2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1732518529RPT Sept 2024.pdf">HY Ended 30-09-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1732518502RPT March 2024_.pdf">HY Ended 31-03-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1732516825RPT Sept 2023.pdf">HY Ended 30-09-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1732516796RPT March 2023.pdf">HY Ended 31-03-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1732516768RPT Sept 2022.pdf">HY Ended 30-09-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1654619688RelatedPartyTransactions.pdf">HY Ended 31-03-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1638352145RPT Sept 2021.pdf">HY Ended 30-09-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1622552892RPT.pdf">HY Ended 31-03-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1604573892RPT30092020.pdf">HY Ended 30-09-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1592918396RPT31032020.pdf">HY Ended 31-03-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1573280989Related Party Transactions.pdf">HY Ended 30-09-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1559640489RPT Half-yearly.pdf">HY Ended 31-03-2019</a></li>
	        </ol> 
      </li>
     	    </ol>
  </li>
	  <li>
    <label for="menu-13"> News</label>
    <input type="checkbox" id="menu-13" />
    <ol>
	      <li>
        <label for="menu-13-32"> Newspaper Advertisements  </label>
        <input type="checkbox" id="menu-13-32" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1763720561Advt_Re-Lodgement_Marathi.pdf">Re-Lodgment of Transfer request of Physical Shares Marathi 21.11.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1763720473Advt_Re-Lodgment_English.pdf">Re-Lodgment of Transfer request of Physical Shares English 21.11.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1762952016BAL-News ADV-Finantial Result-Marathi.pdf">Financials 12.11.2025 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1762951965Business Standard.pdf">Financials 12.11.2025 English</a></li>
			<li class="file"><a target="_blank" href="pdf/17589784062) BAL-Re-Lodgement-Newspaper Advertisement-Marathi.pdf">Re-Lodgment of Transfer request of Physical Shares Marathi 27.09.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/17589783741) BAL-Re-Lodgement-Newspaper Advertisement-English.pdf">Re-Lodgment of Transfer request of Physical Shares English 27.09.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1756105976BAL-Marathi-IEPF Campaign-News Advertisment-24-08-2025.pdf">IEPF Campaign "Saksham Niveshak" Marathi 24.08.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1756105874BAL-English-IEPF Campaign-News Advertisment-24-08-2025.pdf">IEPF Campaign "Saksham Niveshak" English 24.08.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1756105257BAl-Marathi-News Advertisment-Re-lodgement of Transfer of Shares--24-08-2025.pdf">Re-Lodgment of Transfer request of Physical Shares Marathi 24.08.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1756105231BAl-English-News Advertisment-Re-lodgement of Transfer of Shares--24-08-2025.pdf">Re-Lodgment of Transfer request of Physical Shares English 24.08.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1754293105Sanchar_Marathi.pdf">Financials 04.08.2025 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1754293036Balaji Amines_English.pdf">Financials 04.08.2025 English</a></li>
			<li class="file"><a target="_blank" href="pdf/17526608992) BAL_After Dispatch_Marathi.pdf">AGM Notice 16.07.2025 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/17526608651)BAL-After Dispatch-English-16-07-2025.pdf">AGM Notice 16.07.2025 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1752132000Newspaper Advertisement Marathi.pdf">AGM Notice 10.07.2025 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1752131431BAL-Before Dispatch-English Advertisment.pdf">AGM Notice 10.07.2025 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1749900084BAL-IEPF NOTICE-Marathi.pdf">Transfer of Shares to IEPF 14.06.2025 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1749900044BAL-IEPF NOTICE-English.pdf">Transfer of Shares to IEPF 14.06.2025 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1748609022Marathi.pdf">Financials 30.05.2025 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1748608724Balaji Amines - AFR (BS - 30 May 25).pdf">Financials 30.05.2025 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1739445251Marathi Newspaper.pdf">Financials 13.02.2025 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1739429376Balaji Amines - UFR (BS - 13 Feb 25).pdf">Financials 13.02.2025 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1731673336Sanchar.pdf">Financials 15.11.2024 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1731673295Business Standard.pdf">Financials 15.11.2024 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1723266898English.pdf">Financials 09.08.2024 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1723266486Marathi.pdf">Financials 08.08.2024 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1718878495English.pdf">AGM Notice 18.06.2024 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1718878466Marathi.pdf">AGM Notice 18.06.2024 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1718459666Newspaper Ad-Marathi.pdf">AGM Notice 15.06.2024 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1718459592Newpaper Ad-English.pdf">AGM Notice 15.06.2024 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1717751159English.pdf">Transfer of Shares to IEPF 01.06.2024 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1717399835IEPF_Marathi.pdf">Transfer of Shares to IEPF 01.06.2024 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1715335391Marathi.pdf">Financials 09.05.2024 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1715335352English.pdf">Financials 09.05.2024 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1706786174English.pdf">Financials 01.02.2024 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1706786151Marathi Financial.pdf">Financials 01.02.2024 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1699589741English.pdf">Financials 09.11.2023 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1699589705Marathi.pdf">Financials 09.11.2023 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/16977876971693568666English.pdf">Financials 01.08.2023 English</a></li>
			<li class="file"><a target="_blank" href="pdf/16977876671693568698Marathi.pdf">Financials 01.08.2023 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1697787587Newspaper Advt-1.pdf">Transfer of Shares to IEPF 08.06.2023 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1697787556Newspaper Advt-2.pdf">Transfer of Shares to IEPF 08.06.2023 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1687187714English.pdf">AGM Notice 18.06.2023 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1687187694Marathi.pdf">AGM Notice 18.06.2023 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1686932934Marathi.pdf">AGM Notice 16.06.2023 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1686932907English.pdf">AGM Notice 16.06.2023 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1684773046English.pdf">Financials 22.05.2022 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1684772931Matathi.pdf">Financials 21.05.2022 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1675770633img20230207_16192839.pdf">Financials 07.02.2022 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1675770567Balaji Amines Limited-Results, Extract of Standalone & Consolidated Unaudited Financial Results for the Quarter AND Nine month Ended December 31, 2022,.pdf">Financials 07.02.2022 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1667041694Marathi.pdf">Financials 29.10.2022 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1667041661English.pdf">Financials 29.10.2022 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1660392755Marathi.pdf">Financials 13.08.2022 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1660392632English.pdf">Financials 13.08.2022 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1658465829Marathi.pdf">Transfer of Shares to IEPF 21.07.2022 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1658465758English.pdf">Transfer of Shares to IEPF 21.07.2022 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1654926050Newspaper Marathi.pdf">Corrigendum to Annual Report 10.06.2022 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1654926004Newspaper English.pdf">Corrigendum to Annual Report 10.06.2022 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1654619611Marathi.pdf">AGM Notice 04.06.2022 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1654619581English.pdf">AGM Notice 04.06.2022 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1654316904AGM Notice Mar.pdf">AGM Notice 01.06.2022 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1654316856AGM Notice Eng.pdf">AGM Notice 01.06.2022 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1652361119Marathi.pdf">Financials 11.05.2022 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1652361095English.pdf">Financials 11.05.2022 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1643887540Marathi.pdf">Financials 02.02.2022 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1643886294English.pdf">Financials 02.02.2022 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1635426467Marathi.pdf">Financials 27.10.2021 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1635426442English.pdf">Financials 27.10.2021 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1627986459English.pdf">Financials 02.08.2021 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1627986436Marathi.pdf">Financials 02.08.2021 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1626697587Marathi.pdf">AGM Notice 17.07.2021 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1626697552English.pdf">AGM Notice 16.07.2021 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1626065553Marathi.pdf">AGM Notice 10.07.2021 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1626065428English.pdf">AGM Notice 10.07.2021 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1624691409Marathi.pdf">Transfer of Shares to IEPF 26.06.2021 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1624691387English.pdf">Transfer of Shares to IEPF 26.06.2021 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1612867977Newspaper Advt Marathi.pdf">Financials 08.02.2021 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1612867755Newspaper Advt English.pdf">Financials 08.02.2021 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1612175708newsadmarathi.pdf">BM Notice 08.02.2021 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1612175537newsbmenglish.pdf">BM Notice 08.02.2021 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1604985507NewspaperADPostalBallot10112020.pdf">Postal Ballot [ESOP] Notice Part II</a></li>
			<li class="file"><a target="_blank" href="pdf/1604466509Postalballotademailidupdation.pdf">Postal Ballot [ESOP] Notice Part I</a></li>
			<li class="file"><a target="_blank" href="pdf/1603957240newsadfinancialsbm29102020.pdf">Financials 28.10.2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1603280025NEWSADBM28102020 (2).pdf">BM Notice 21.10.2020[RESCHEDULED]</a></li>
			<li class="file"><a target="_blank" href="pdf/1601878887NewspaperAdBMintimation30102020.pdf">BM Notice 04.10.2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1597312821newspaperadfinancials13082020.pdf">Financials 12.08.2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1596267215ADBMNOTICE01082020.pdf">BM Notice 01.08.2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1594798500News Paper Advertisement 150720.pdf">AGM Notice Part II 15.07.2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1594534157newspaperadagm12072020.pdf">AGM Notice Part I 12.07.2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1593588442newspaperadiepf01072020.pdf">Transfer to IEPF 01.07.2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1584439740Marathi.pdf">Intimation of Record Date</a></li>
			<li class="file"><a target="_blank" href="pdf/1584439723English.pdf">Intimation of Record Date</a></li>
			<li class="file"><a target="_blank" href="pdf/1580454842Marathi.pdf">Financials 30.01.2020 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1580454784English.pdf">Financials 30.01.2020 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1577766454img20191231_09533658.pdf">BM Notice 30.01.2020 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1577766426English.pdf">BM Notice 30.01.2020 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1572514527Marathi.pdf">Financials 30.10.2019 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1572514499results (1).pdf">Financials 30.10.2019 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1569995982Intimation to SE-3.pdf">BM Notice 30.10.2019 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1569995920Intimation to SE-2.pdf">BM Notice 30.10.2019 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1564206744Pudhari.pdf">Financials 26.07.2019 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1564206687Business Standard.pdf">Financials 26.07.2019 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1562395199Marathi.pdf">BM Notice 26.07.2019 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1562395151English.pdf">BM Notice 26.07.2019 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1561959478Notice 31st AGM english.pdf">AGM Notice 01.07.2019 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1561959361legal.pdf">AGM Notice 01.07.2019 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1558509389English.pdf">Transfer of Shares to IEPF 22.05.2019 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1558509291Marathi.pdf">Transfer of Shares to IEPF 22.05.2019 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1558507718Marathi.pdf">Financials 15.05.2019 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1558507699English.pdf">Financials 15.05.2019 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1556772621Sanchar.pdf">BM Notice 15.05.2019 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1556772585Indian Express.pdf">BM Notice 15.05.2019 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1548753011marathi.pdf">Financials 28.01.2019 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1548752988English.pdf">Financials 28.01.2019 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1547727848Pudhari.pdf">BM Notice 28.01.2019 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1547727827Indian Express.pdf">BM Notice 28.01.2019 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1541073036Sanchar Newspaper Advt 31102018.pdf">Financials 31.10.2018 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1541072946PAPER RESULTS.pdf">Financials 31.10.2018 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1539767903Punyanagari .pdf">BM Notice 31.10.2018 Marathi </a></li>
			<li class="file"><a target="_blank" href="pdf/1539767793Financial Express .pdf">BM Notice 31.10.2018 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1533539422Sakal 30th AGM Notice.pdf">AGM Notice 06.08.2018 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1533539378Indian Express 30th AGM Notice .pdf">AGM Notice 06.08.2018 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1532670074Financials.pdf">Financials 23.07.2018 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1531572272BM Notice  English.pdf">BM Notice 23.07.2018 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1527144073Indian Express.pdf">Transfer of Shares to IEPF 24.05.2018 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1527144013Divya Marathi.pdf">Transfer of Shares to IEPF 24.05.2018 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1526358906Financials English.pdf">Financials 31.03.2018 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1526358867Financials Marathi.pdf">Financials 31.03.2018 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1524717971Punya Nagari  Newspaper advt.pdf">BM Notice 14.05.2018 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1524717840Lokmat Times newspaper advt.pdf">BM Notice 14.05.2018 English</a></li>
			<li class="file"><a target="_blank" href="pdf/151737433631122017.pdf">Financials 31.12.2017 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1517299687convert-jpg-to-pdf net_2018-01-30_08-47-28.pdf">Financials 31.12.2017 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1514615164NWADVT29122017.pdf">Notice of hearing of Petition under Rule 16 of the Companies (Compromises, Arrangements and Amalgamations) Rules, 2016</a></li>
			<li class="file"><a target="_blank" href="pdf/1512678890Amalgamation Ads.pdf">Amalgamation Ads</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-13-114"> Postal Ballot Notice </label>
        <input type="checkbox" id="menu-13-114" />
        <ol>
		        </ol> 
      </li>
     	    </ol>
  </li>
	  <li>
    <label for="menu-14"> Press Releases</label>
    <input type="checkbox" id="menu-14" />
    <ol>
	      <li>
        <label for="menu-14-33"> Press Releases  </label>
        <input type="checkbox" id="menu-14-33" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1762857781Press_Release_Signed.pdf">Press Release Q2 FY26</a></li>
			<li class="file"><a target="_blank" href="pdf/1754151925Press_Realease.pdf">Press Release Q1 FY26</a></li>
			<li class="file"><a target="_blank" href="pdf/1748497920Press_Release_signed.pdf">Press Release Q4 FY25</a></li>
			<li class="file"><a target="_blank" href="pdf/1739376430Press Release.pdf">Press Release Q3 FY25</a></li>
			<li class="file"><a target="_blank" href="pdf/1731597378Intimation.pdf">Press Release Q2 FY25</a></li>
			<li class="file"><a target="_blank" href="pdf/1723036945PR.pdf">Press Release Q1 FY25</a></li>
			<li class="file"><a target="_blank" href="pdf/1715174599PR.pdf">Press Release Q4 FY24</a></li>
			<li class="file"><a target="_blank" href="pdf/1706760402PR.pdf">Press Release Q3 FY24</a></li>
			<li class="file"><a target="_blank" href="pdf/16995064218bf1afac-7ea4-4012-af5d-61adcb2e0021.pdf">Press Release Q2 FY24</a></li>
			<li class="file"><a target="_blank" href="pdf/1693546475Pressrelease.pdf">Press Release Q1 FY24</a></li>
			<li class="file"><a target="_blank" href="pdf/1684691873PressRelease.pdf">Press Release Q4 FY23</a></li>
			<li class="file"><a target="_blank" href="pdf/1675767372PR.pdf">Press Release Q3 FY23</a></li>
			<li class="file"><a target="_blank" href="pdf/1666931291PR.pdf">Press Release Q2 FY23</a></li>
			<li class="file"><a target="_blank" href="pdf/1663162893Press Release.pdf">Press Release - Completion of Phase 1 of Greenfield Project (Unit IV)</a></li>
			<li class="file"><a target="_blank" href="pdf/1660309557PR.pdf">Press Release Q1 FY23</a></li>
			<li class="file"><a target="_blank" href="pdf/1652339537Press Release.pdf">Press Release Q4 FY22</a></li>
			<li class="file"><a target="_blank" href="pdf/1643867033Press Release.pdf">Press Release Q3 FY22</a></li>
			<li class="file"><a target="_blank" href="pdf/1635340738Press Release.pdf">Press Release Q2 FY22</a></li>
			<li class="file"><a target="_blank" href="pdf/1627915970Pressrelease.pdf">Press Release Q1 FY22</a></li>
			<li class="file"><a target="_blank" href="pdf/1627915921Press Release.pdf">Press Release Q4 FY21</a></li>
			<li class="file"><a target="_blank" href="pdf/1612792091press.pdf">Press Release Q3 FY21</a></li>
			<li class="file"><a target="_blank" href="pdf/1603956963pressrelease30092020.pdf">Press Release Q2 FY21</a></li>
			<li class="file"><a target="_blank" href="pdf/1597294192pressrelease.pdf">Press Release Q1 FY21</a></li>
			<li class="file"><a target="_blank" href="pdf/1592918679pressrelease.pdf">Press Release Q4 FY20</a></li>
			<li class="file"><a target="_blank" href="pdf/1580463069Press.pdf">Press Release Q3 FY20</a></li>
			<li class="file"><a target="_blank" href="pdf/1572497175Press Release.pdf">Press Release Q2 FY20</a></li>
			<li class="file"><a target="_blank" href="pdf/1566995493Press Release BSCPL.pdf">Press Release REACH Registration BSCPL</a></li>
			<li class="file"><a target="_blank" href="pdf/1564146787Pressupload.pdf">Press Release Q1 FY19</a></li>
	        </ol> 
      </li>
     	    </ol>
  </li>
	  <li>
    <label for="menu-15"> Codes and Policies</label>
    <input type="checkbox" id="menu-15" />
    <ol>
	      <li>
        <label for="menu-15-34">  Codes and Policies  </label>
        <input type="checkbox" id="menu-15-34" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1753782419CSRActionPlan2025-26.pdf">CSR Action Plan for FY 2025-26</a></li>
			<li class="file"><a target="_blank" href="pdf/1744374465Whistle Blower Policy.pdf">Whistle Blower Policy</a></li>
			<li class="file"><a target="_blank" href="pdf/1744374244Policy on Related Party Transactions.pdf">Policy on Related Party Transactions</a></li>
			<li class="file"><a target="_blank" href="pdf/1744374223Policy on Material Subsidiaries.pdf">Policy on Material Subsidiaries</a></li>
			<li class="file"><a target="_blank" href="pdf/1744374197Archival Policy.pdf">Archival Policy</a></li>
			<li class="file"><a target="_blank" href="pdf/1744374171Nomination, Remuneration and Evaluation Policy.pdf">Nomination, Remuneration and Evaluation Policy</a></li>
			<li class="file"><a target="_blank" href="pdf/1744374137Policy on Preservation of Documents.pdf">Policy on Preservation of Documents</a></li>
			<li class="file"><a target="_blank" href="pdf/1715840061SupplierCodeofConduct.pdf">Supplier Code of Conduct</a></li>
			<li class="file"><a target="_blank" href="pdf/1709547488CriteriaforPaymenttoNonExecutiveDirectors.pdf">Criteria for Payment to Non Executive Directors</a></li>
			<li class="file"><a target="_blank" href="pdf/1709545684PolicyforProcedureofInquiryincaseofLeakofUPSI.pdf">Policy for Procedure of Inquiry in case of Leak of UPSI</a></li>
			<li class="file"><a target="_blank" href="pdf/1709545145CodeofConductforDirectorsandSeniorManagement.pdf">Code of Conduct for Directors and Senior Management</a></li>
			<li class="file"><a target="_blank" href="pdf/1708062412CorporateSocialReponsibilityPolicy.pdf">Corporate Social Responsibility Policy</a></li>
			<li class="file"><a target="_blank" href="pdf/1708002869FamiliarisationProgramme.pdf">Familiarisation Programme for Independent Directors</a></li>
			<li class="file"><a target="_blank" href="pdf/1703161222TermsandConditionsofAppointmentofIndependentDirectors.pdf">Terms and Conditions of Appointment of Independent Directors</a></li>
			<li class="file"><a target="_blank" href="pdf/1703159270DividendDistributionPolicy.pdf">Dividend Distribution Policy</a></li>
			<li class="file"><a target="_blank" href="pdf/1702972928RiskManagementPolicy.pdf">Risk Management Policy</a></li>
			<li class="file"><a target="_blank" href="pdf/1700893568PolicyforDeterminationofMaterialityofEventsorInformation.pdf">Policy for Determination of Materiality of Events or Information</a></li>
			<li class="file"><a target="_blank" href="pdf/1698395742Code of Business Conduct and Ethics.pdf">Code of Business Conduct and Ethics</a></li>
			<li class="file"><a target="_blank" href="pdf/1686925902Human Rights Policy.pdf">Human Rights Policy</a></li>
			<li class="file"><a target="_blank" href="pdf/1645091304Anti Sexual Harassment Policy.pdf">Anti Sexual Harassment Policy</a></li>
	        </ol> 
      </li>
     	    </ol>
  </li>
	  <li>
    <label for="menu-16"> Unpaid & Unclaimed dividend and Shares</label>
    <input type="checkbox" id="menu-16" />
    <ol>
	      <li>
        <label for="menu-16-35"> Unpaid & Unclaimed dividend and Shares  </label>
        <input type="checkbox" id="menu-16-35" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1751968252IEPF2_20250708110303.pdf">Unclaimed Dividend 2023-24</a></li>
			<li class="file"><a target="_blank" href="pdf/1732532240Unclaimed Dividend 2022-23.pdf">Unclaimed Dividend 2022-23</a></li>
			<li class="file"><a target="_blank" href="pdf/1732532198Unclaimed Dividend 2021-22.pdf">Unclaimed Dividend 2021-22</a></li>
			<li class="file"><a target="_blank" href="pdf/1732532151Unclaimed Dividend 2020-21.pdf">Unclaimed Dividend 2020-21</a></li>
			<li class="file"><a target="_blank" href="pdf/1732532111Unclaimed Dividend 2019-20 Final Dividend.pdf">Unclaimed Dividend 2019-20 Final Dividend</a></li>
			<li class="file"><a target="_blank" href="pdf/1732532090Unclaimed Dividend 2019-20 Interim Dividend.pdf">Unclaimed Dividend 2019-20 Interim Dividend</a></li>
			<li class="file"><a target="_blank" href="pdf/1732532011Unclaimed Dividend 2018-19.pdf">Unclaimed Dividend 2018-19</a></li>
			<li class="file"><a target="_blank" href="pdf/1732531985Unclaimed Dividend 2017-18.pdf">Unclaimed Dividend 2017-18</a></li>
			<li class="file"><a target="_blank" href="pdf/1717754572Share Transfered detailsIEPF2024.pdf">Details of Shares Transferred to IEPF - 2024</a></li>
			<li class="file"><a target="_blank" href="pdf/16942665661694263454Details of Shares Transferred to IEPF - 2023.pdf">Details of Shares Transferred to IEPF - 2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1694266499IEPF_2022.pdf">Details of Shares Transferred to IEPF - 2022</a></li>
			<li class="file"><a target="_blank" href="pdf/16942634371638874461Details of Shares Transferred to IEPF 2021.pdf">Details of Shares Transferred to IEPF - 2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1694263411Details of Shares Transferred to IEPF - 2020.pdf">Details of Shares Transferred to IEPF - 2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1694262796Unclaimed Dividend 2016-17.pdf">Unclaimed Dividend 2016-17</a></li>
			<li class="file"><a target="_blank" href="pdf/1694262744Unclaimed Dividend 2015-16.pdf">Unclaimed Dividend 2015-16</a></li>
			<li class="file"><a target="_blank" href="pdf/1573886799Details of Shares Transferred to IEPF-2019_final.pdf">Details of Shares Transferred to IEPF - 2019</a></li>
			<li class="file"><a target="_blank" href="pdf/157388655814-15.pdf">Unclaimed Dividend 2014-15</a></li>
			<li class="file"><a target="_blank" href="pdf/157388651713-14.pdf">Unclaimed Dividend 2013-14</a></li>
			<li class="file"><a target="_blank" href="pdf/157388648012-13.pdf">Unclaimed Dividend 2012-13</a></li>
			<li class="file"><a target="_blank" href="pdf/1573886439Unclaimed Dividend.pdf">Unclaimed Dividend 2011-12</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-16-118"> Unclaimed Dividend 2023-24 </label>
        <input type="checkbox" id="menu-16-118" />
        <ol>
		        </ol> 
      </li>
     	    </ol>
  </li>
	  <li>
    <label for="menu-17">Corporate Actions</label>
    <input type="checkbox" id="menu-17" />
    <ol>
	      <li>
        <label for="menu-17-36">  Amalgamation </label>
        <input type="checkbox" id="menu-17-36" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/152661848420-02-2018 Order of Scheme of Amalgamation.pdf">20-02-2018 Order of Scheme of Amalgamation</a></li>
			<li class="file"><a target="_blank" href="pdf/15126808131509344544TCM.pdf">Results of the TCM and Postal Ballot (Including E-Voting) Under Regulation 30 and Regulation 44(3) of the SEBI LODR 2015</a></li>
			<li class="file"><a target="_blank" href="pdf/151268078515075282081.pdf">Notice and advertisement of notice of the meeting of shareholders of BAL – English</a></li>
			<li class="file"><a target="_blank" href="pdf/151268076115075281872.pdf">Notice and advertisement of notice of the meeting of shareholders of BAL – Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/151268073915075281423.pdf">Notice of postal ballot and e-voting BAL - english</a></li>
			<li class="file"><a target="_blank" href="pdf/151268071115075281084.pdf">Notice of postal ballot and e-voting BAL- Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/151268065415075281084.pdf">Notice and advertisement of notice of the meeting of sundry creditors of Balaji Amines Limited- English</a></li>
			<li class="file"><a target="_blank" href="pdf/151268062015075280535.pdf">Notice and advertisement of notice of the meeting of sundry creditors of Balaji Amines Limited- Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/151268059115075279816.pdf">NOTICE AND ADVERTISEMENT OF NOTICE OF THE MEETING OF SHAREHOLDERS OF BCL – English</a></li>
			<li class="file"><a target="_blank" href="pdf/151268056615075279517.pdf">NOTICE AND ADVERTISEMENT OF NOTICE OF THE MEETING OF SHAREHOLDERS OF BCL – Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/151268054415075278929.pdf">NOTICE AND ADVERTISEMENT OF NOTICE OF THE MEETING OF 10% CUMULATIVE REDEEMABLE PREFERENCE SHAREHOLDER OF BGPL – English</a></li>
			<li class="file"><a target="_blank" href="pdf/1512680517150752785710.pdf">NOTICE AND ADVERTISEMENT OF NOTICE OF THE MEETING OF 10% CUMULATIVE REDEEMABLE PREFERENCE SHAREHOLDER OF BGPL - Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1512680489150752781411.pdf">NOTICE AND ADVERTISEMENT OF NOTICE OF THE MEETING OF SHAREHOLDERS OF BGPL – English</a></li>
			<li class="file"><a target="_blank" href="pdf/1512680463150752776912.pdf">NOTICE AND ADVERTISEMENT OF NOTICE OF THE MEETING OF SHAREHOLDERS OF BGPL – Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/15126802361507527734BAL REPORT.pdf">BAL REPORT</a></li>
			<li class="file"><a target="_blank" href="pdf/15126802141507527699BCL REPORT.pdf">BCL REPORT</a></li>
			<li class="file"><a target="_blank" href="pdf/15126801951507527658NOC from BSE.pdf">NOC from BSE</a></li>
			<li class="file"><a target="_blank" href="pdf/15126801441507527636NOC from BSE.pdf">NOC from NSE</a></li>
			<li class="file"><a target="_blank" href="pdf/15126799571507527597Notice of Tribunal Convened Meeting of Equity Shareholders (1).pdf">Notice of Tribunal Convened Meeting of Equity Shareholders</a></li>
			<li class="file"><a target="_blank" href="pdf/15126799351507527464Postal Ballot Notice for Tribunal convened Meeting of Equity Share holders.pdf">Postal Ballot Notice for Tribunal convened Meeting of Equity Share holders</a></li>
			<li class="file"><a target="_blank" href="pdf/15126798931507527377Notice of Tribunal Convened Meeting of Sundry creditors.pdf">Notice of Tribunal Convened Meeting of Sundry creditors</a></li>
			<li class="file"><a target="_blank" href="pdf/15126798591507526965Postal Ballot form along with Instructions.pdf">Postal Ballot form along with Instructions</a></li>
			<li class="file"><a target="_blank" href="pdf/15126798281507526855ANN-01 Scheme of Amalgamation.pdf">Scheme of Amalgamation</a></li>
			<li class="file"><a target="_blank" href="pdf/15126798081507526727ANN-02 Valuation Report.pdf">Valuation Report</a></li>
			<li class="file"><a target="_blank" href="pdf/15126797851507526687ANN-03 Report of Audit Committee.pdf">Report of Audit Committee</a></li>
			<li class="file"><a target="_blank" href="pdf/15126797571507526648ANN-04 Fairness opinion.pdf">Fairness opinion</a></li>
			<li class="file"><a target="_blank" href="pdf/15126797391507526604ANN-05 Shareholding pattern of all the Companies - Pre and Post.pdf">Shareholding pattern of all the Companies - Pre and Post</a></li>
			<li class="file"><a target="_blank" href="pdf/15126797131507526571ANN-06 Audited financials of last 3 years of all the companies.pdf">Audited financials of last 3 years of all the companies</a></li>
			<li class="file"><a target="_blank" href="pdf/15126796851507526525ANN-07 Auditor certificate on confirmation of Accounting Standards.pdf">Auditor certificate on confirmation of Accounting Standards</a></li>
			<li class="file"><a target="_blank" href="pdf/15126796641507526490ANN-11 Board Resolutions.pdf">Board Resolutions</a></li>
			<li class="file"><a target="_blank" href="pdf/15126796431507526414COMPLAINTS REPORT.pdf">Complaints Report</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-17-61"> ESOP 2020 </label>
        <input type="checkbox" id="menu-17-61" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1608811253ESOPTRUSTDEED2020.pdf">ESOP TRUST DEED</a></li>
			<li class="file"><a target="_blank" href="pdf/1608117765MinutesofResolutionpassedbypostalballot.pdf">PROCEEDINGS OF POSTAL BALLOT</a></li>
			<li class="file"><a target="_blank" href="pdf/16081176441608104325PBRESULT.pdf">POSTAL BALLOT RESULTS</a></li>
			<li class="file"><a target="_blank" href="pdf/1608104284NewspaperADPostalBallot10112020.pdf">Newspaper Ad Postal Ballot [ESOP] Notice Part II</a></li>
			<li class="file"><a target="_blank" href="pdf/1604904446BALAJI MOA AOA.pdf">MOA AOA</a></li>
			<li class="file"><a target="_blank" href="pdf/1604902939ESOP SCHEME 2020.pdf">ESOP SCHEME 2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1604902898POSTAL BALLOT NOTICE ESOP.pdf">POSTAL BALLOT NOTICE ESOP</a></li>
			<li class="file"><a target="_blank" href="pdf/1604466638Postalballotademailidupdation.pdf">Newspaper Ad Postal Ballot [ESOP] Notice Part I</a></li>
	        </ol> 
      </li>
     	    </ol>
  </li>
	  <li>
    <label for="menu-50">Yearly Compliances</label>
    <input type="checkbox" id="menu-50" />
    <ol>
	      <li>
        <label for="menu-50-51"> Secretarial Compliance Report </label>
        <input type="checkbox" id="menu-50-51" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1752661995ASCR_Signed.pdf">Year Ended 31-03-2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1716469584ASCR.pdf">Year Ended 31-03-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1685442928ASCR.pdf">Year Ended 31-03-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1653485722Secretariarl Audit report.pdf">Year Ended 31-03-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1623152582AnnualCompliancereport.pdf">Year Ended 31-03-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1592918480compliancereport31032020.pdf">Year Ended 31-03-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1558325864Annual Secretarial Compliance-Report.pdf">Year Ended 31-03-2019</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-50-69"> Yearly Compliances - Compliance Certificate 7(3) </label>
        <input type="checkbox" id="menu-50-69" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/17128292967.pdf">Year Ended 31-03-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/16817049247(3).pdf">Year Ended 31-03-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1681467514HY ended 31-03-2022.pdf">HY ended 31-03-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1681467140HY ended 31-03-2021.PDF">HY ended 31-03-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1681467043HY ended 30-09-2020.PDF">HY ended 30-09-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1681467009HY ended 31-03-2020.PDF">HY ended 31-03-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1681466977HY ended 30-09-2019.PDF">HY ended 30-09-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1681466949HY ended 31-03-2019.pdf">HY ended 31-03-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1681466919HY ended 30-09-2018.PDF">HY ended 30-09-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1681466888HY ended 31-03-2018.pdf">HY ended 31-03-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1681466833HY ended 30-10-2017.pdf">HY ended 30-10-2017</a></li>
			<li class="file"><a target="_blank" href="pdf/1681466764HY ended 31-03-2017.pdf">HY ended 31-03-2017</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-50-70"> Yearly Compliances - Compliance certificate 40(9) </label>
        <input type="checkbox" id="menu-50-70" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/171360537340.pdf">Y Ended 31-03-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/168284693840_9.pdf">Y Ended 31-03-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1681468784HY Ended 31-03-2022.pdf">HY Ended 31-03-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1681468762HY Ended 31-03-2021.pdf">HY Ended 31-03-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1681468741HY Ended 30-09-2020.pdf">HY Ended 30-09-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1681468715HY Ended 31-03-2020.pdf">HY Ended 31-03-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1681468687HY Ended 30-09-2019.pdf">HY Ended 30-09-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1681468665HY Ended 31-03-2019.pdf">HY Ended 31-03-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1681468641HY Ended 30-09-2018.pdf">HY Ended 30-09-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1681468616HY Ended 31-03-2018.pdf">HY Ended 31-03-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1681468594HY Ended 30-09-2017.pdf">HY Ended 30-09-2017</a></li>
			<li class="file"><a target="_blank" href="pdf/1681468563HY Ended 31-03-2017.pdf">HY Ended 31-03-2017</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-50-71"> Year Ended 31-03-2022 </label>
        <input type="checkbox" id="menu-50-71" />
        <ol>
		        </ol> 
      </li>
     	    </ol>
  </li>
	  <li>
    <label for="menu-54">Investors Presentation</label>
    <input type="checkbox" id="menu-54" />
    <ol>
	      <li>
        <label for="menu-54-55"> July 2019 </label>
        <input type="checkbox" id="menu-54-55" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1562157064IP.pdf">Investor Presentation - July 2019</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-54-57"> Investor Presentation </label>
        <input type="checkbox" id="menu-54-57" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1762930080Investor_Presentation_Signed.pdf">Investor Presentation SEP 2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1754401696Investor_Presentation_Signed.pdf">Investor Presentation JUN 2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1749277928Investor Presentation_Signed.pdf">Investor Presentation Mar 2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1739540778Intimation.pdf">Investor Presentation Dec 2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1732003674Intimation.pdf">Investor Presentation SEPT 2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1723136090IP.pdf">Investor Presentation JUN 2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1723136022ip march.pdf">Investor Presentation MAR 2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1723135924ip dec.pdf">Investor Presentation FEB 2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1699620919b885f59a-2def-4a8c-80e0-7371cda65b25.pdf">Investor Presentation NOV 2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1693660137IP.pdf">Investor Presentation SEP 2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1684750647InvestorPresentation.pdf">Investor Presentation MAR 2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1675767479IP.pdf">Investor Presentation FEB 2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1667018683Investor Presentation.pdf">Investor Presentation OCT 2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1660386270IP.pdf">Investor Presentation AUG 2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1652361028IP.pdf">Investor Presentation MAY 2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1643887669Investor Presentation.pdf">Investor Presentation FEB 2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1637132202Investor Presentation.pdf">Investor Presentation OCT 2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1628063598Investorpresentation.pdf">Investor Presentation AUG 2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1622090082Investor Presentation.pdf">Investor Presentation MAY 2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1612864447IP.pdf">Investor Presentation FEB 2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1604311476investorpresentation.pdf">Investor Presentation NOV 2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1597312716INVESTORPRESENATATION082020.pdf">Investor Presentation AUG 2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1593668875Q4FY20InvestorPresentation.pdf">Investor Presentation JUNE 2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1580730592Investor Presentation - FEB 2020.pdf">Investor Presentation FEB 2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1579610869IP.pdf">Investor Presentation JAN 2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1575184531InvestorPresentationDEC2019.pdf">Investor Presentation DEC 2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1572612297Investor Presentation.pdf">Investor Presentation - Q2FY20</a></li>
			<li class="file"><a target="_blank" href="pdf/1565162331InvestorPresentation.pdf">Investor Presentation - Q1FY20</a></li>
	        </ol> 
      </li>
     	    </ol>
  </li>
	  <li>
    <label for="menu-62">FAQ’s and Forms for TDS</label>
    <input type="checkbox" id="menu-62" />
    <ol>
	      <li>
        <label for="menu-62-63"> FAQ’s and Forms for TDS </label>
        <input type="checkbox" id="menu-62-63" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/16261680505 Self-Declaration-Form.pdf">Self Declaration Form</a></li>
			<li class="file"><a target="_blank" href="pdf/16261680184 Form-10-F-NRI.pdf">Form-10 F NRI</a></li>
			<li class="file"><a target="_blank" href="pdf/16261679873 Form_15H.pdf">Form 15H</a></li>
			<li class="file"><a target="_blank" href="pdf/16261679612 Form_15G.pdf">Form 15G</a></li>
			<li class="file"><a target="_blank" href="pdf/16261679371 FAQs-TDS-on-dividend-26-06-2020.pdf">FAQs - TDS on dividend 26-06-2020</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-62-64"> 1 FAQs-TDS-on-dividend-26-06-2020 </label>
        <input type="checkbox" id="menu-62-64" />
        <ol>
		        </ol> 
      </li>
     	    </ol>
  </li>
	  <li>
    <label for="menu-65">Annual Return</label>
    <input type="checkbox" id="menu-65" />
    <ol>
	      <li>
        <label for="menu-65-66"> Annual Returns of Balaji Amines Ltd. </label>
        <input type="checkbox" id="menu-65-66" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1752839757MGT-7_Website.pdf">Annual Return MGT-7 2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1727782518Form_MGT_7_BAL.pdf">Annual Return MGT-7 2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1704193246Form MGT-7_Web.pdf">Annual Return MGT-7 2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1664432498Annual Return.pdf">Annual Return MGT-7 2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1638267439MGT-7 2021.pdf">Annual Return MGT-7 2021</a></li>
	        </ol> 
      </li>
     	    </ol>
  </li>
	  <li>
    <label for="menu-67">Investors Communication</label>
    <input type="checkbox" id="menu-67" />
    <ol>
	      <li>
        <label for="menu-67-68"> Common and Simplified Norms for processing Investor’s service requests </label>
        <input type="checkbox" id="menu-67-68" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1709981002SEBIFAQ'sInvestorServiceRequestsprocessedbyRTA.pdf">FAQ's issued by SEBI with respect to Investor Service Requests processed by RTA</a></li>
			<li class="file"><a target="_blank" href="pdf/1707306263Intimation.pdf">Intimation to Physical Shareholders for KYC and Nomination</a></li>
			<li class="file"><a target="_blank" href="pdf/1707306048Form ISR-1.pdf">Form ISR-1- Request for Registering PAN, KYC Details or Changes and / or Updation</a></li>
			<li class="file"><a target="_blank" href="pdf/1707306029Form ISR-2.pdf">Form ISR-2- Confirmation of Signature by Banker</a></li>
			<li class="file"><a target="_blank" href="pdf/1707306010Form ISR-3.pdf">Form ISR-3- Declaration for opting-out of Nomination</a></li>
			<li class="file"><a target="_blank" href="pdf/1707305989Form ISR-4.pdf">Form ISR-4- Request for Issue of Duplicate Share Certificate and other Service Request</a></li>
			<li class="file"><a target="_blank" href="pdf/1707305969Form ISR-5.pdf">Form ISR-5- Request for Transmission of Securities by Nominee or Legal Heir</a></li>
			<li class="file"><a target="_blank" href="pdf/1707305945Form SH-13.pdf">Form SH-13- Request for Registering Nomination</a></li>
			<li class="file"><a target="_blank" href="pdf/1707305919Form SH-14.pdf">Form SH-14- Request for Cancellation or Variation in Nomination</a></li>
			<li class="file"><a target="_blank" href="pdf/1704200072Circular for Nomination and KYC.pdf">Circular for Nomination and KYC</a></li>
			<li class="file"><a target="_blank" href="pdf/1648110344SEBI Circulars on Norms for furnishing PAN, KYC details and Nomination.pdf">Norms for furnishing PAN, KYC details and Nomination</a></li>
	        </ol> 
      </li>
     	    </ol>
  </li>
	  <li>
    <label for="menu-72">Compliances</label>
    <input type="checkbox" id="menu-72" />
    <ol>
	      <li>
        <label for="menu-72-73"> EC Letter </label>
        <input type="checkbox" id="menu-72-73" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1706349827BAL Unit-IV- Existing EC Letter.pdf">BAL Unit-IV- Existing EC Letter</a></li>
			<li class="file"><a target="_blank" href="pdf/1682774078Balaji Amines LtdUnit-I- Environmental Clearance Certificate.pdf">Balaji Amines Ltd Unit-I- Environmental Clearance Certificate</a></li>
			<li class="file"><a target="_blank" href="pdf/1682774015BAL Unit-II EC Letter.pdf">BAL Unit-II EC Letter</a></li>
			<li class="file"><a target="_blank" href="pdf/1682773942BalajiAminesLtdUnit-III.pdf">Balaji Amines Ltd. Unit-III- Environmental Clearance Certificate</a></li>
			<li class="file"><a target="_blank" href="pdf/1682773834BAL Unit-IV Expansion EC Letter.pdf">BAL Unit-IV Expansion EC Letter</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-72-74"> Six Monthly Compliance Report </label>
        <input type="checkbox" id="menu-72-74" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1751716469BAL-I Six Monthly Compliance.pdf">BAL-I Six Monthly Compliance</a></li>
			<li class="file"><a target="_blank" href="pdf/1751716439BAL-III Six Monthly Compliance.pdf">BAL-III Six Monthly Compliance</a></li>
			<li class="file"><a target="_blank" href="pdf/1751716408BAL-IV Six Monthly Compliance.pdf">BAL-IV Six Monthly Compliance</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-72-75"> Hazardous Waste Return Form No-IV </label>
        <input type="checkbox" id="menu-72-75" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1751716644BAL - Hazardous Waste Return Form No-IV.pdf">BAL - Hazardous Waste Return Form No-IV</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-72-76"> Environmental Statement Form-V  </label>
        <input type="checkbox" id="menu-72-76" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1729923305BAL Environment Statment FORM-V.pdf">BAL - Environment Statment FORM-V</a></li>
	        </ol> 
      </li>
     	    </ol>
  </li>
	  <li>
    <label for="menu-77">Disclosure under Regulation 46 of SEBI (LODR) Regulations, 2015</label>
    <input type="checkbox" id="menu-77" />
    <ol>
	      <li>
        <label for="menu-77-78"> Details of Business </label>
        <input type="checkbox" id="menu-77-78" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1713169460Details of Business.pdf">Details of Business</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-77-79"> Terms and Conditions of Appointment of Independent Directors </label>
        <input type="checkbox" id="menu-77-79" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1713173238Terms and Conditions of Appointment of Independent Directors.pdf">Terms and Conditions of Appointment of Independent Directors</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-77-80"> Composition of various committees of Board of Directors </label>
        <input type="checkbox" id="menu-77-80" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1713173394Committees of the Board.pdf">Committees of the Board</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-77-81"> Code of Conduct of Directors and Senior Management Personnel </label>
        <input type="checkbox" id="menu-77-81" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1713173556Code of conduct for board of directors and senior management personnel.pdf">Code of Conduct of Board of Directors and Senior Management Personnel</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-77-82"> Details of Establishment of Vigil Mechanism or Whistle Blower Policy </label>
        <input type="checkbox" id="menu-77-82" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1744374012Whistle Blower Policy.pdf">Vigil Mechanism / Whistle Blower Policy</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-77-83"> Criteria of making payments to Non-Executive Directors </label>
        <input type="checkbox" id="menu-77-83" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1713174003Criteria of making payments to Non-Executive Directors.pdf">Criteria of making payments to Non-Executive Directors</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-77-84"> Policy on dealing with Related Party Transactions </label>
        <input type="checkbox" id="menu-77-84" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1744373914Policy on Related Party Transactions.pdf">Policy on Related Party Transactions</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-77-85"> Policy for determining 'material' subsidiaries  </label>
        <input type="checkbox" id="menu-77-85" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1744373952Policy on Material Subsidiaries.pdf">Policy on Material Subsidiaries</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-77-86"> Details of Familiarisation Programme imparted to Independent Directors </label>
        <input type="checkbox" id="menu-77-86" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1749298192Familiarisation Programme of Indpendent Directors.pdf">Familiarisation Programme for Independent Directors</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-77-87"> Credit Rating </label>
        <input type="checkbox" id="menu-77-87" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1750153017Credit_Rating_Signed.pdf">17.062025</a></li>
			<li class="file"><a target="_blank" href="pdf/171317849314-03-2024.pdf">14-03-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/171317846212-01-2023.pdf">12-01-2023 </a></li>
			<li class="file"><a target="_blank" href="pdf/171317843527-10-2021.pdf">27-10-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/171317839015-04-2021.pdf">15-04-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/171317836329-01-2020.pdf">29-01-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/171317832121-12-2018.pdf">21-12-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/171317828405-12-2017.pdf">05-12-2017</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-77-88"> Secretarial Compliance Report </label>
        <input type="checkbox" id="menu-77-88" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1750335837ASCR_Signed.pdf">Annual Secretarial Compliance Report 2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1717407410Secretarial.pdf">Year Ended 31-03-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1713178944Annual Secretarial Compliance Report 2023.pdf">Annual Secretarial Compliance Report 2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1713178912Annual Secretarial Compliance Report 2022.pdf">Annual Secretarial Compliance Report 2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1713178893Annual Secretarial Compliance Report 2021.pdf">Annual Secretarial Compliance Report 2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1713178874Annual Secretarial Compliance Report 2020.pdf">Annual Secretarial Compliance Report 2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1713178850Annual Secretarial Compliance Report 2019.pdf">Annual Secretarial Compliance Report 2019</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-77-89"> Materiality Policy as per Regulation 30(4) </label>
        <input type="checkbox" id="menu-77-89" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1713179133Policy for Determination of Materiality of Events or Information.pdf">Policy for Determination of Materiality of Events or Information</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-77-90"> Dividend Distribution Policy as per Regulation 43A(1) </label>
        <input type="checkbox" id="menu-77-90" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1713179260Dividend Distribution Policy.pdf">Dividend Distribution Policy</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-77-91"> Annual Return </label>
        <input type="checkbox" id="menu-77-91" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1756465916MGT-7_Website.pdf">Annual Return 2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1727782572Form_MGT_7_BAL.pdf">Annual Return MGT-7 2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1713179452Annual Return 2023.pdf">Annual Return 2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1713179424Annual Return 2022.pdf">Annual Return 2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1713179399Annual Return 2021.pdf">Annual Return 2021</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-77-92"> Financial Results </label>
        <input type="checkbox" id="menu-77-92" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1762783010Financial Results .pdf">Results for the quarter ended 30-09-2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1754145635BM - Outcome_compressed --222-output.pdf">Results for the quarter ended 30-06-2025</a></li>
			<li class="file"><a target="_blank" href="pdf/17501353071748500735Q4-2024-25-Results (1).pdf">Results for the quarter ended 31-03-2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1739369636Financial Results.pdf">Results for the quarter ended 31-12-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1735986299Results for the quarter ended 30-09-2024.pdf">Results for the quarter ended 30-09-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1723031781Results.pdf">Results for the quarter ended 30-06-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1715157610BM Financials.pdf">Results for the quarter and year ended March 31, 2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1713947478dec.pdf">Results for the quarter and nine months ended 31.12.2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1713947440q.pdf">RESULTS FOR HALF YEAR AND QUARTER ENDED 30-09-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1713947403June.pdf">Results for the quarter ended 30-06-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1713947361March.pdf">Results for the quarter and year ended March 31, 2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1713947321rr.pdf">Results for the quarter and nine months ended 31.12.2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1713947280sep.pdf">RESULTS FOR HALF YEAR AND QUARTER ENDED 30-09-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1713947244result.pdf">Results for the quarter ended 30-06-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1713947146resul.pdf">Results for the quarter ended 30-06-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1713947031bm.pdf">Results for the quarter and year ended March 31, 2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1713946990com.pdf">Results for the quarter and nine months ended 31.12.2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1713946950oct.pdf">RESULTS FOR HALF YEAR AND QUARTER ENDED 30-09-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1713946914out.pdf">Results for the quarter ended 30-06-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1713946875fin.pdf">Results for the quarter and year ended March 31, 2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1713946811res.pdf">Results for the quarter and nine months ended 31.12.2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1713946221year.pdf">RESULTS FOR HALF YEAR AND QUARTER ENDED 30-09-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1713946176ompressed.pdf">Results for the quarter ended 30-06-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/17139342391592832734Results19-20.pdf">Results for the Quarter and Year Ended March 31, 2020</a></li>
			<li class="file"><a target="_blank" href="pdf/17139336401580388664BM Outcome.pdf">Results for Quarter & Nine Months ended 31-12-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/17139335111572439872BM OUTCOME-2-17.pdf">RESULTS FOR HALF YEAR AND QUARTER ENDED 30-09-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/17139334591564207697Outcome final.pdf">Results for the quarter ended 30-06-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/17139334191557928223Q4_31032019.PDF">Results for the year ended and quarter ended 31-03-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/17139333751548678999OUTCOME.pdf">Results for Quarter & Nine Months ended 31-12-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/17139333381540986847outcome 30092018.pdf">RESULTS FOR HALF YEAR AND QUARTER ENDED 30-09-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/17139332971532354616Results.pdf">Results for the quarter ended 30-06-2018</a></li>
			<li class="file"><a target="_blank" href="pdf/17139332501526304771outcome of Board Meeting.pdf">Results for the year ended: 31-03-2018</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-77-93"> Shareholding Pattern </label>
        <input type="checkbox" id="menu-77-93" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1763471285OCR--SHP-Website - Final-25-10-2025.pdf">30-09-2025 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1756465863Website.pdf">30.06.2025SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1744981716SHP-output.pdf">31-03-2025SP</a></li>
			<li class="file"><a target="_blank" href="pdf/173734786431-12-24 SP.pdf">31-12-2024 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1734931943SHP Sept 24.pdf">30-09-2024 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/17226663021722598227SHP.pdf">30-06-2024 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/1713876333SHP.pdf">31-03-2024 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/171335630031-12-2023 SP.pdf">31-12-2023 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/171335626930-09-2023 SP.pdf">30-09-2023 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/171335625230-06-2023 SP.pdf">30-06-2023 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/171335623631-03-2023 SP.pdf">31-03-2023 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/171335616030-09-2022 SP.pdf">30-09-2022 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/171335613430-06-2022 SP.pdf">30-06-2022 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/171335611731-03-2022 SP.pdf">31-03-2022 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/171335608231-12-2021 SP.pdf">31-12-2021 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/171335605730-09-2021 SP.pdf">30-09-2021 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/171335603330-06-2021 SP.pdf">30-06-2021 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/171335598131-03-2020 SP.pdf">31-03-2021 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/171335586430-09-2020 SP.pdf">30-09-2020 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/171335584030-06-2020 SP.pdf">30-06-2020 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/171335582131-03-2020 SP.pdf">31-03-2020 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/171335580031-12-2019 SP.pdf">31-12-2019 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/171335577730-09-2019 SP.pdf">30-09-2019 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/171335575530-06-2019 SP.pdf">30-06-2019 SP</a></li>
			<li class="file"><a target="_blank" href="pdf/171335573331-03-2019 SP.pdf">31-03-2019 SP</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-77-94"> Schedule of Analyst or Institutional Investor Meet </label>
        <input type="checkbox" id="menu-77-94" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1763471215Concall_Signed.pdf">Preponement of Concall_12.11.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1763471172Concall_Signed.pdf">Concall_12.11.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1750761470Concall_Signed.pdf">Concall_19.06.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1733818241Investormeet.pdf">Investor Meet_16.12.2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1733749150Investormeet13.pdf">Investor Meet_13.12.2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1733749092Investormeet.pdf">Investor Meet_12.12.2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1731475623Intimation.pdf">Concall_19.11.2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1725544367Intimation.pdf">Investor Meet_10.09.2024</a></li>
			<li class="file"><a target="_blank" href="pdf/17199213861.pdf">Investor Meet_04.07.2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1718631515Intimation.pdf">Investor Meet_21.06.2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1717407317intimation.pdf">Investor Meet_06.06.2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1715157347Concall.pdf">Concall_08.05.2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1713876222m.pdf">INVESTOR MEET_22.03.2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1713876182i.pdf">INVESTOR MEET_26.12.2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1713876060C.pdf">CONCALL_08.11.2023</a></li>
			<li class="file"><a target="_blank" href="pdf/17138759841695206843InvestorMeet.pdf">INVESTOR MEET_26.09.2023</a></li>
			<li class="file"><a target="_blank" href="pdf/171387587208.pdf">CONCALL_08.09.2023</a></li>
			<li class="file"><a target="_blank" href="pdf/171387582130.pdf">INVESTOR MEET_30.06.2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1713872086Concall22052023.pdf">CONCALL_22.05.2023</a></li>
			<li class="file"><a target="_blank" href="pdf/171387200014.pdf">INVESTOR MEET_14.03.2023</a></li>
			<li class="file"><a target="_blank" href="pdf/171387193922.pdf">INVESTOR MEET_22.02.2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1713871862160223.pdf">INVESTOR MEET_16.02.2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1713871746291222.pdf">INVESTOR MEET_29.12.2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1713871672191222.pdf">INVESTOR MEET_19.12.2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1713871532031222.pdf">INVESTOR MEET_03.12.2022</a></li>
			<li class="file"><a target="_blank" href="pdf/17138714100112222.pdf">INVESTOR MEET_01.12.2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1713871244300922.pdf">INVESTOR MEET_30.09.2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1713869740150522.pdf">CONCALL_12.05.2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1713869600INVESTOR MEET_25032022.pdf">INVESTOR MEET_25032022</a></li>
			<li class="file"><a target="_blank" href="pdf/1713869491INVESTOR MEET_17032022.pdf">INVESTOR MEET_17032022</a></li>
			<li class="file"><a target="_blank" href="pdf/171386938110032022.pdf">INVESTOR MEET_10.03.2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1713868908CONCALL_31012022.pdf">CONCALL_31012022</a></li>
			<li class="file"><a target="_blank" href="pdf/1713868831INVESTOR MEET_08122021.pdf">INVESTOR MEET_08122021</a></li>
			<li class="file"><a target="_blank" href="pdf/1713868673CONCALL_22102021.pdf">CONCALL_22102021</a></li>
			<li class="file"><a target="_blank" href="pdf/1713866861INVESTOR MEET_23082021 (Virtual Meeting).pdf">INVESTOR MEET_23082021 (Virtual Meeting)</a></li>
			<li class="file"><a target="_blank" href="pdf/1713866775CONCALL_29072021.pdf">CONCALL_29072021</a></li>
			<li class="file"><a target="_blank" href="pdf/1713866719INVESTOR MEET_24062021 (Virtual Meeting).pdf">INVESTOR MEET_24062021 (Virtual Meeting)</a></li>
			<li class="file"><a target="_blank" href="pdf/1713866673INVESTOR MEET_14062021 (Virtual Meeting).pdf">INVESTOR MEET_14062021 (Virtual Meeting)</a></li>
			<li class="file"><a target="_blank" href="pdf/1713866558INVESTOR MEET_28052021.pdf">INVESTOR MEET_28052021</a></li>
			<li class="file"><a target="_blank" href="pdf/1713866510Concall_26052021.pdf">Concall_26052021</a></li>
			<li class="file"><a target="_blank" href="pdf/1713866417Concall_09022021.pdf">Concall_09022021</a></li>
			<li class="file"><a target="_blank" href="pdf/1713866373INVESTOR MEET_22122020 (Virtual Investor Conference).pdf">INVESTOR MEET_22122020 (Virtual Investor Conference)</a></li>
			<li class="file"><a target="_blank" href="pdf/1713866273Concall_02112020[RESCHEDULED].pdf">Concall_02112020[RESCHEDULED]</a></li>
			<li class="file"><a target="_blank" href="pdf/1713866228Concall_29102020.pdf">Concall_29102020</a></li>
			<li class="file"><a target="_blank" href="pdf/1713866125Concall_13082020.pdf">Concall_13082020</a></li>
			<li class="file"><a target="_blank" href="pdf/1713865991INVESTOR MEET_25062020 (Virtual Investor Conference).pdf">INVESTOR MEET_25062020 (Virtual Investor Conference)</a></li>
			<li class="file"><a target="_blank" href="pdf/1713865942Concall_23062020.pdf">Concall_23062020</a></li>
			<li class="file"><a target="_blank" href="pdf/1713865788Concall_03022020.pdf">Concall_03022020</a></li>
			<li class="file"><a target="_blank" href="pdf/1713865744INVESTOR MEET_03122019.pdf">INVESTOR MEET_03122019</a></li>
			<li class="file"><a target="_blank" href="pdf/1713865633Concall_01112019.pdf">Concall_01112019</a></li>
			<li class="file"><a target="_blank" href="pdf/1713865570INVESTOR MEET_25092019.pdf">INVESTOR MEET_25092019</a></li>
			<li class="file"><a target="_blank" href="pdf/1713865414Balaji Amines Q1 FY-20 Earnings Conference Call July 29, 2019.pdf">Balaji Amines Q1 FY-20 Earnings Conference Call July 29, 2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1713865273INVESTOR MEET_26062019.pdf">INVESTOR MEET_26062019</a></li>
			<li class="file"><a target="_blank" href="pdf/1713358125Balaji Amines Q4 FY-19 Earnings Conference Call May 20, 2019.pdf">Balaji Amines Q4 FY-19 Earnings Conference Call May 20, 2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1713358096CONCALL_20052019.pdf">Concall_20.05.2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1713358055INVESTOR MEET_15042019.pdf">INVESTOR MEET_15.04.2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1713358007Balaji Amines Q1 FY-19 Earnings Conference Call July 31, 2018.pdf">Balaji Amines Q1 FY-19 Earnings Conference Call July 31, 2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1713357975CONCALL_31072018.pdf">Concall_31.07.2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1713357935CONCALL_14062018.pdf">Concall_14.06.2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1713357552Balaji Amines Q4 FY2018 Earnings Conference call May 21, 2018.pdf">Balaji Amines Q4 FY2018 Earnings Conference call May 21, 2018</a></li>
			<li class="file"><a target="_blank" href="pdf/17133574711526617654CON CALL.pdf">Concall_21.05.2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1713357209“Balaji Amines Q3 FY2018 Earnings Conference Call” February 14, 2018.pdf">Balaji Amines Q3 FY2018 Earnings Conference Call February 14, 2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1713357056concall.pdf">Concall_14.02.2018</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-77-95"> Advertisements </label>
        <input type="checkbox" id="menu-77-95" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1763720646Advt_Re-Lodgement_Marathi.pdf">Re-Lodgment of Transfer request of Physical Shares Marathi 21.11.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1763720611Advt_Re-Lodgment_English.pdf">Re-Lodgment of Transfer request of Physical Shares English 21.11.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1762952096BAL-News ADV-Finantial Result-Marathi.pdf">Financials 12.11.2025 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1762952059Business Standard.pdf">Financials 12.11.2025 English</a></li>
			<li class="file"><a target="_blank" href="pdf/17589785092) BAL-Re-Lodgement-Newspaper Advertisement-Marathi.pdf">Re-Lodgment of Transfer request of Physical Shares Marathi 27.09.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/17589784671) BAL-Re-Lodgement-Newspaper Advertisement-English.pdf">Re-Lodgment of Transfer request of Physical Shares English 27.09.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1756106027BAL-Marathi-IEPF Campaign-News Advertisment-24-08-2025.pdf">IEPF Campaign "Saksham Niveshak" Marathi 24.08.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1756105997BAL-English-IEPF Campaign-News Advertisment-24-08-2025.pdf">IEPF Campaign "Saksham Niveshak" English 24.08.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1756105312BAl-Marathi-News Advertisment-Re-lodgement of Transfer of Shares--24-08-2025.pdf">Re-Lodgment of Transfer request of Physical Shares Marathi 24.08.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1756105283BAl-English-News Advertisment-Re-lodgement of Transfer of Shares--24-08-2025.pdf">Re-Lodgment of Transfer request of Physical Shares English 24.08.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1754293182Sanchar_Marathi.pdf">Financials 04.08.2025 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1754293147Balaji Amines_English.pdf">Financials 04.08.2025 English</a></li>
			<li class="file"><a target="_blank" href="pdf/17526611772) BAL_After Dispatch_Marathi.pdf">AGM Notice 16.07.2025 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/17526611461)BAL-After Dispatch-English-16-07-2025.pdf">AGM Notice 16.07.2025 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1752661109BAL-Before Dispatch-Marathi Advertisment-pages.pdf">AGM Notice 10.07.2025 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1752660994BAL-Before Dispatch-English-News Adv-2025-26.pdf">AGM Notice 10.07.2025 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1748609132Balaji Amines - AFR (BS - 30 May 25).pdf">Financials 30.05.2025 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1748609095Marathi.pdf">Financials 30.05.2025 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1739865349Marathi Newspaper.pdf">Financials 13.02.2025 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1739865209Balaji Amines - UFR (BS - 13 Feb 25).pdf">Financials 13.02.2025 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1731673743Sanchar.pdf">Financials 15.11.2024 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1731673708Business Standard.pdf">Financials 15.11.2024 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1731673642AD Mar.pdf">Financials 08.08.2024 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1731673440AD.pdf">Financials 09.08.2024 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1718878562Marathi.pdf">AGM Notice 18.06.2024 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1718878532English.pdf">AGM Notice 18.06.2024 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1718459775Newspaper Ad-Marathi.pdf">AGM Notice 15.06.2024 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1718459754Newpaper Ad-English.pdf">AGM Notice 15.06.2024 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1717754619English.pdf">Transfer of Shares to IEPF 01.06.2024 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1717399881IEPF_Marathi.pdf">Transfer of Shares to IEPF 01.06.2024 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1715335555Marathi.pdf">Financials 09.05.2024 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1715335527English.pdf">Financials 09.05.2024 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713944167en.pdf">Financials 01.02.2024 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713944109gur.pdf">Financials 01.02.2024 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713944074eg.pdf">Financials 09.11.2023 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713943899Mar.pdf">Financials 09.11.2023 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713943851SS.pdf">Financials 01.08.2023 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713943805ES.pdf">Financials 01.08.2023 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713943767ie.pdf">Transfer of Shares to IEPF 08.06.2023 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713943733adv.pdf">Transfer of Shares to IEPF 08.06.2023 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713943701eng.pdf">AGM Notice 18.06.2023 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713943675BA.pdf">AGM Notice 18.06.2023 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713943641Ma.pdf">AGM Notice 16.06.2023 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/171394361123.pdf">AGM Notice 16.06.2023 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713943581eng.pdf">Financials 22.05.2022 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713943548taru.pdf">Financials 21.05.2022 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713943513imh.pdf">Financials 07.02.2022 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713943473ectr.pdf">Financials 07.02.2022 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713943436Mar.pdf">Financials 29.10.2022 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713943401BS.pdf">Financials 29.10.2022 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713943326sur.pdf">Financials 13.08.2022 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713943286hy.pdf">Financials 13.08.2022 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713943238BAL.pdf"> Transfer of Shares to IEPF 21.07.2022 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713943143jul.pdf"> Transfer of Shares to IEPF 21.07.2022 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713943115sak.pdf"> Corrigendum to Annual Report 10.06.2022 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713943076t5rf2.pdf"> Corrigendum to Annual Report 10.06.2022 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713943043jun.pdf">AGM Notice 04.06.2022 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713942970fi.pdf">AGM Notice 04.06.2022 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713942941no.pdf">AGM Notice 01.06.2022 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713942903hy.pdf">AGM Notice 01.06.2022 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713942867lo.pdf">Financials 11.05.2022 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713942840pap.pdf">Financials 11.05.2022 English</a></li>
			<li class="file"><a target="_blank" href="pdf/17139428031.pdf">Financials 02.02.2022 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/17139427615.pdf">Financials 02.02.2022 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713942724asd.pdf">Financials 27.10.2021 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/171394268515.pdf">Financials 27.10.2021 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713942648BS.pdf">Financials 02.08.2021 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713942611Ma.pdf">Financials 02.08.2021 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713942276tar.pdf">AGM Notice 17.07.2021 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713942244Lsh.pdf">AGM Notice 16.07.2021 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713942212Lokm.pdf">AGM Notice 10.07.2021 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713942165Eng.pdf">AGM Notice 10.07.2021 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713942128San.pdf">Transfer of Shares to IEPF 26.06.2021 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713942088Sat.pdf">Transfer of Shares to IEPF 26.06.2021 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713942054Mar.pdf">Financials 08.02.2021 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713942017Pap.pdf">Financials 08.02.2021 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713941967pud.pdf">BM Notice 08.02.2021 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713941930BN.pdf">BM Notice 08.02.2021 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713941892POS.pdf">Postal Ballot [ESOP] Notice Part II</a></li>
			<li class="file"><a target="_blank" href="pdf/1713941851ESO.pdf">Postal Ballot [ESOP] Notice Part I</a></li>
			<li class="file"><a target="_blank" href="pdf/1713941807Fi.pdf">Financials 28.10.2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1713941746Ne.pdf">BM Notice 21.10.2020[RESCHEDULED]</a></li>
			<li class="file"><a target="_blank" href="pdf/1713941712IN.pdf">BM Notice 04.10.2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1713941645New.pdf">Financials 12.08.2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1713941613No.pdf">BM Notice 01.08.2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1713941567Pa.pdf"> AGM Notice Part II 15.07.2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1713941508AGM.pdf"> AGM Notice Part I 12.07.2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1713941456ad.pdf">Transfer to IEPF 01.07.2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1713941352Ma.pdf">Intimation of Record Date</a></li>
			<li class="file"><a target="_blank" href="pdf/1713941281Re.pdf">Intimation of Record Date</a></li>
			<li class="file"><a target="_blank" href="pdf/1713941214ek.pdf">Financials 30.01.2020 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713941178En.pdf">Financials 30.01.2020 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713941137Sa.pdf">BM Notice 30.01.2020 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713941097en.pdf">BM Notice 30.01.2020 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713941014Div.pdf">Financials 30.10.2019 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713940970OC.pdf">Financials 30.10.2019 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713940903SE.pdf">BM Notice 30.10.2019 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713940856IN.pdf">BM Notice 30.10.2019 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713940813pu.pdf">Financials 26.07.2019 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713940769BS.pdf">Financials 26.07.2019 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713939798Na.pdf">BM Notice 26.07.2019 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713939761S.pdf">BM Notice 26.07.2019 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713939727A.pdf">AGM Notice 01.07.2019 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713939576l.pdf">AGM Notice 01.07.2019 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713939516n.pdf">Transfer of Shares to IEPF 22.05.2019 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713939455I.pdf">Transfer of Shares to IEPF 22.05.2019 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713939423L.pdf">Financials 15.05.2019 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713939387B.pdf">Financials 15.05.2019 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713939345S.pdf">BM Notice 15.05.2019 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713939311E.pdf">BM Notice 15.05.2019 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713939283D.pdf">Financials 28.01.2019 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713938641B.pdf">Financials 28.01.2019 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713938607p.pdf">BM Notice 28.01.2019 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713938577i.pdf">BM Notice 28.01.2019 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713938517s.pdf">Financials 31.10.2018 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713938470rr.pdf">Financials 31.10.2018 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713938422p.pdf">BM Notice 31.10.2018 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713938382E.pdf">BM Notice 31.10.2018 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713938342a.pdf">AGM Notice 06.08.2018 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713938308n.pdf">AGM Notice 06.08.2018 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713938261b.pdf">Financials 23.07.2018 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713938178e.pdf">BM Notice 23.07.2018 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713938143e.pdf">Transfer of Shares to IEPF 24.05.2018 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713938109d.pdf">Transfer of Shares to IEPF 24.05.2018 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713938076e.pdf">Financials 31.03.2018 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713938038i.pdf">Financials 31.03.2018 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713937956m.pdf">BM Notice 14.05.2018 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713937919l.pdf">BM Notice 14.05.2018 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713937878d.pdf">Financials 31.12.2017 English</a></li>
			<li class="file"><a target="_blank" href="pdf/1713937840r.pdf">Financials 31.12.2017 Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1713937795n.pdf">Notice of hearing of Petition under Rule 16 of the Companies (Compromises, Arrangements and Amalgamations) Rules, 2016</a></li>
			<li class="file"><a target="_blank" href="pdf/17139376651.pdf">Amalgamation Ads</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-77-96"> Subsidiary Audited Financial Statements </label>
        <input type="checkbox" id="menu-77-96" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1722666550Results.pdf">Results for the year ended 31-03-2024</a></li>
			<li class="file"><a target="_blank" href="pdf/1713355517Results for the year ended 31-03-2023.pdf">Results for the year ended 31-03-2023</a></li>
			<li class="file"><a target="_blank" href="pdf/1713355495Results for the year ended 31-03-2022.pdf">Results for the year ended 31-03-2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1713355474Results for the year ended 31-03-2021.pdf">Results for the year ended 31-03-2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1713355454Results for the year ended 31-03-2020.pdf">Results for the year ended 31-03-2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1713355428Results for the year ended 31-03-2019.pdf">Results for the year ended 31-03-2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1713355397Results for the year ended 31-03-2018.pdf">Results for the year ended 31-03-2018</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-77-97"> Audio or Video Recordings of Investor Calls </label>
        <input type="checkbox" id="menu-77-97" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1763470675Concall_Audio_Link_Signed.pdf">Concall_12.11.2024_Audio Recording Link</a></li>
			<li class="file"><a target="_blank" href="pdf/1750333036Intimation.pdf">Concall_19.06.2025_Audio Recording Link</a></li>
			<li class="file"><a target="_blank" href="pdf/1732035791Concall.pdf">Concall_19.11.2024_Audio Recording Link</a></li>
			<li class="file"><a target="_blank" href="pdf/1715400840Audio.pdf">CONCALL_10.05.2024_Audio Recording Link</a></li>
			<li class="file"><a target="_blank" href="pdf/1713944532h.pdf">CONCALL_10.11.2023_Audio Recording Link</a></li>
			<li class="file"><a target="_blank" href="pdf/1713944493audio.pdf">CONCALL_08.09.2023_Audio Recording Link</a></li>
			<li class="file"><a target="_blank" href="pdf/1713944460link.pdf">Concall_22.05.2023_Audio Recording Link</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-77-98"> Transcript of Post Earnings/Quarterly Calls </label>
        <input type="checkbox" id="menu-77-98" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1763459043Transcript_Signed.pdf">Concall_12.11.2025_Transcript</a></li>
			<li class="file"><a target="_blank" href="pdf/1750946230Transcript_Signed.pdf">Concall_19.06.2025_Transcript</a></li>
			<li class="file"><a target="_blank" href="pdf/1732360180Intimation.pdf">Concall_19.11.2024_Transcript</a></li>
			<li class="file"><a target="_blank" href="pdf/1715867187TranscriptSE.pdf">CONCALL_10.05.2024_Transcript</a></li>
			<li class="file"><a target="_blank" href="pdf/1713945275cac.pdf">CONCALL_10.11.2023_Transcript</a></li>
			<li class="file"><a target="_blank" href="pdf/1713945247scr.pdf">CONCALL_08.09.2023_Transcript</a></li>
			<li class="file"><a target="_blank" href="pdf/1713945214tr.pdf"> Concall_22.05.2023_Transcript</a></li>
			<li class="file"><a target="_blank" href="pdf/1713945177erg.pdf">Transcript of Balaji Amines Q4 FY-22 Earnings Conference Call May 12, 2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1713945133re.pdf">Transcript of Balaji Amines Q3 FY-22 Earnings Conference Call February, 3 2022</a></li>
			<li class="file"><a target="_blank" href="pdf/1713945072ear.pdf">Transcript of Balaji Amines Q2 FY-22 Earnings Conference Call October, 28 2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1713945043confere.pdf">Transcript of Balaji Amines Q4 FY-20 Earnings Conference Call July, 29 2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1713945005tr.pdf">Transcript of Balaji Amines Q4 FY-20 Earnings Conference Call May 26, 2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1713944955f.pdf">Transcript of Balaji Amines Q3 FY-21 Earnings Conference Call February 9, 2021</a></li>
			<li class="file"><a target="_blank" href="pdf/1713944917q.pdf">Transcript of Balaji Amines Q2 FY-21 Earnings Conference Call November 2, 2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1713944879fy.pdf">Transcript of Balaji Amines Q1 FY-21 Earnings Conference Call August 13, 2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1713944816ba.pdf"> Transcript of Balaji Amines Q4 FY-20 Earnings Conference Call June 23, 2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1713944759f.pdf">Transcript of Balaji Amines Q3 FY-20 Earnings Conference Call February 3, 2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1713944717b.pdf"> Transcript of Balaji Amines Q2 FY-20 Earnings Conference Call November 01, 2019</a></li>
			<li class="file"><a target="_blank" href="pdf/1713944642t.pdf">Transcript of Balaji Amines Q1 FY-20 Earnings Conference Call July 29, 2019</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-77-99"> Announcements </label>
        <input type="checkbox" id="menu-77-99" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1731475704Intimation.pdf">10-11-2024 Intimation of commencement of commercial production of new Methylamines plant</a></li>
			<li class="file"><a target="_blank" href="pdf/1723626582SEIntimation.pdf">14-08-2024 Intimation regarding Grant of Environmental Clearance (EC) to the proposed Greenfield Project of Balaji Speciality Chemicals Limited, Material Subsidiary Company</a></li>
			<li class="file"><a target="_blank" href="pdf/1714128095cr.pdf">14-03-2024 Credit Rating</a></li>
			<li class="file"><a target="_blank" href="pdf/1714128070Projects.pdf">31-01-2024 Intimation of Expansion Projects</a></li>
			<li class="file"><a target="_blank" href="pdf/1714128042Morpholine.pdf">17-01-2024 Intimation of BIS Certification for the Product “Morpholine” as per IS 12084:2018</a></li>
			<li class="file"><a target="_blank" href="pdf/1714128007Nbutylamines.pdf">16-01-2024 Intimation of commencement of commercial production of N-butylamines </a></li>
			<li class="file"><a target="_blank" href="pdf/1714127942clarification.pdf">27-12-2023 Clarification on Movement in Price</a></li>
			<li class="file"><a target="_blank" href="pdf/1714127913Price.pdf">07-12-2023 Clarification on Movement in Price</a></li>
			<li class="file"><a target="_blank" href="pdf/1714127882SMP.pdf">04-11-2023 Resignation Of Senior Management Personnel</a></li>
			<li class="file"><a target="_blank" href="pdf/1714127856bscl.pdf">08-09-2023 Intimation regarding withdrawal of the Draft Red Herring Prospectus dated August 10, 2022 ("DRHP") filed with the Securities and Exchange Board of India ("SEBI") by Balaji Speciality Chemicals Limited("BSCL")</a></li>
			<li class="file"><a target="_blank" href="pdf/1714127725letter.pdf">16-08-2023 Clarification Letter </a></li>
			<li class="file"><a target="_blank" href="pdf/1714127697intimation.pdf">14-08-2023 Results-Delay in Financial Results</a></li>
			<li class="file"><a target="_blank" href="pdf/1714127469cfo.pdf">20-05-2023 Resignation of Whole-Time Director and Chief Financial Officer</a></li>
			<li class="file"><a target="_blank" href="pdf/1714127329change.pdf">20-05-2023 Change in Designation of Directors</a></li>
			<li class="file"><a target="_blank" href="pdf/1714127294appt.pdf">20-05-2023 Appointment of Independent Directors</a></li>
			<li class="file"><a target="_blank" href="pdf/1714127210resign.pdf">20-05-2023 Resignation of Directors</a></li>
			<li class="file"><a target="_blank" href="pdf/1714127161rta.pdf">30-04-2023 Intimation regarding change in address of Registrar and Share Transfer Agent (RTA) of the Company</a></li>
			<li class="file"><a target="_blank" href="pdf/1714127125haresh.pdf">18-04-2023 Issue of Duplicate Share Certificate of Mr. Haresh M Changlani</a></li>
			<li class="file"><a target="_blank" href="pdf/1714127098Apr.pdf">03-04-2023 Intimation of Loss of Share Certificate of Mr. Haresh M Changlani</a></li>
			<li class="file"><a target="_blank" href="pdf/1714127068ec.pdf">05-02-2023 Grant of Environmental Clearance (EC) to the proposed expansion project at Solapur</a></li>
			<li class="file"><a target="_blank" href="pdf/1714127042cr.pdf">12-01-2023 Credit Rating</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126962dmc.pdf">26-09-2022 Intimation of commencement of commercial production of DMC at MIDC, Chincholi, Solapur</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126938madan.pdf">05-09-2022 Issue of Duplicate Share Certificate of Mr. Himanshu, Mr. Virendra & Mr. Madan</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126907lal.pdf">29-08-2022 Intimation of Loss of Share Certificate of Mr. Madan Lal Kaplish</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126883Himanshu.pdf">19-08-2022 Intimation of Loss of Share Certificate of Mr. Himanshu J. Patel & Mr. Virendra Kumar Singh</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126856ipo.pdf">01-06-2022 Proposed Initial Public offering of Equity Shares of Face Value of Rs. 2 Each ('Equity Shares') by the Company's Material Subsidiary, Balaji Speciality Chemicals Limited</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126721DM.pdf">24-11-2021 Issue of Duplicate Share Certificate of Ms. Sunita Deva, Ms. Sharada Deva & Mr. Sadasivarao Deva</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126691DMF.pdf">23-11-2021 Intimation of Commencement of DMF Plant</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126666dup.pdf">13-11-2021 Issue of Duplicate Share Certificate of Mr. Divakar Reddy Bendram, Mr. Ramesh Reddy Y & Mrs. sunita Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126617deva.pdf">09-11-2021 Intimation of Loss of Share Certificate of Mr. Deva Family</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126564ramesh.pdf">25-10-2021 Intimation of Loss of Share Certificate of Mr. Ramesh Reddy Y & Mrs. Suneetha Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126531crrs.pdf">27-10-2021 Credit Rating India Ratings & Research</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126503oc.pdf">25-10-2021 Intimation of Loss of Share Certificate of Mr. Divakar Reddy Bendram</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126476o.pdf">06-10-2021 Intimation of Breakdown of Plant</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126448sept.pdf">16-09-2021 Issue of Duplicate Share Certificate of Shah Nandkishore Motital Shah Priti Nandkishore</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126420sep.pdf">07-09-2021 Intimation of Loss of Share Certificate of Mr. SHAH NANDKISHOR MOTITAL </a></li>
			<li class="file"><a target="_blank" href="pdf/1714126390se.pdf">03-08-2021 Setting up of new plant for manufacture of Acetonitirle</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126345cs.pdf">30-06-2021 Appointment of Company Secretary & Compliance Officer</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126316gf.pdf">21-05-2021 Commissioning of first phase of green field project of the company at Unit - IV</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126288cr.pdf">15-04-2021 Credit Rating India Ratings & Research</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126250cs.pdf">22-01-2021 Intimation of Sad Demise of Ms Jimisha Parth Dawda, Company Secretary and Compliance Officer of the Company</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126215clarity.pdf">Clarification on Outcome of Board Meeting held on 28th October, 2020</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126187dsc.pdf">22-10-2020 Issue of Duplicate Share Certificate of muruga vellaichamy r</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126148sc.pdf">09-10-2020 Intimation of Loss of Share Certificate of Mr. MURUGA VELLAICHEMY R </a></li>
			<li class="file"><a target="_blank" href="pdf/1714126115bse.pdf">01-04-2020 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126084inti.pdf">24-03-2020 Intimation for temporary Disruption of Company 's Business Operations due to COVID-19</a></li>
			<li class="file"><a target="_blank" href="pdf/1714126026final.pdf">26-02-2020 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714125973asr.pdf">06-02-2020 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/17141258932020.pdf">05-02-2020 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714125859credit.pdf">29-01-2020 Credit Rating India Ratings & Research</a></li>
			<li class="file"><a target="_blank" href="pdf/1714125827devi.pdf">13-12-2019 Disclosure under PIT Regulations Mrs. A. Shakuntala Devi</a></li>
			<li class="file"><a target="_blank" href="pdf/1714125795dec.pdf">12-12-2019 Disclosure under PIT Regulations Mrs. A. Shakuntala Devi</a></li>
			<li class="file"><a target="_blank" href="pdf/1714125763pit.pdf">04-12-2019 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/17141257372019.pdf">30-11-2019 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714125689pit.pdf">29-11-2019 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714125660clear.pdf">27-11-2019 Ministry of Environment Clearance for Unit-IV</a></li>
			<li class="file"><a target="_blank" href="pdf/1714125617RTA.pdf">01-11-2019 Intimation of RTA Reappointment</a></li>
			<li class="file"><a target="_blank" href="pdf/17141255842019.pdf">24-09-2019 Disclosure under PIT Regulations Mr. A. Srinivas Reddy </a></li>
			<li class="file"><a target="_blank" href="pdf/1714125557pit.pdf">17-09-2019 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714125501final.pdf">14-09-2019 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714125414reg.pdf">13-09-2019 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714125378final.pdf">11-09-2019 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714125333pit.pdf">11-09-2019 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714125300pit.pdf">22-08-2019 Disclosure under PIT Regulations Mr. N. Eeshan Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714125271eeshan.pdf">20-08-2019 Disclosure under PIT Regulations Mr. N. Eeshan Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714125241ASR.pdf">14-08-2019 Disclosure under PIT Regulations Mr. A. Srinivas Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714125213ghr.pdf">08-08-2019 Disclosure under PIT Regulations Mr. G. Hemanth Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714125180ghr.pdf">07-08-2019 Disclosure under PIT Regulations Mr. G. Hemanth Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714125143Hemanth Reddy.pdf">06-08-2019 Disclosure under PIT Regulations Mr. G. Hemanth Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714125094GHR.pdf">03-08-2019 Disclosure under PIT Regulations Mr. G. Hemanth Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714125065eeshan.pdf">01-08-2019 Disclosure under PIT Regulations Mr. N. Eeshan Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714125039DVR.pdf">31-07-2019 Disclosure under PIT Regulations Mrs. D. Vandana Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714125008GHR.pdf">21-06-2019 Disclosure under PIT Regulations Mr. G. Hemanth Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714124973DRR S.pdf">13-06-2019 Disclosure under PIT Regulations Mr. D. Ram Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714124941DRR.pdf">11-06-2019 Disclosure under PIT Regulations Mr. D. Ram Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714124899mpcb.pdf">11-06-2019 Consent from MPCB - BSCPL</a></li>
			<li class="file"><a target="_blank" href="pdf/1714124826APR.pdf">08-06-2019 Disclosure under PIT Regulations Mr. A. Prathap Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714124798PIT.pdf">07-06-2019 Disclosure under PIT Regulations Mr. A. Prathap Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714124759besker l.pdf">25-05-2019 Issue of Duplicate Share Certificate</a></li>
			<li class="file"><a target="_blank" href="pdf/1714124724MPCB.pdf">15-05-2019 Consent from MPCB</a></li>
			<li class="file"><a target="_blank" href="pdf/1714124690entities.pdf">30-04-2019 Large Corporate Disclosure-Non applicability</a></li>
			<li class="file"><a target="_blank" href="pdf/1714124657besker.pdf">12-04-2019 Intimation of Loss of Share Certificate Besker</a></li>
			<li class="file"><a target="_blank" href="pdf/1714124613PIT.pdf">25-03-2019 Announcement under Regulation 30 SEBI PIT Code </a></li>
			<li class="file"><a target="_blank" href="pdf/1714124567APR.pdf">05.02.2019 Disclosure under PIT Regulations Mr. A. Prathap Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714124388duplicate.pdf">02-02-2019 Issue of Duplicate Share Certificate </a></li>
			<li class="file"><a target="_blank" href="pdf/1714124260certificate.pdf">08-01-2019 Intimation of Loss of Share Certificate Astakala Vidyacharan</a></li>
			<li class="file"><a target="_blank" href="pdf/1714124217credit.pdf">21-12-2018 Credit Rating India Ratings & Research</a></li>
			<li class="file"><a target="_blank" href="pdf/1714124065gund.pdf">29.09.2018 Intimation of regarding Issue of Duplicate Share Certificate </a></li>
			<li class="file"><a target="_blank" href="pdf/1714124018APR S.pdf">06.09.2018 Disclosure under PIT Regulations A. Prathap Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714123971APR.pdf">07.06.2018 Disclosure under PIT Regulations A. Prathap Reddy</a></li>
			<li class="file"><a target="_blank" href="pdf/1714123852MD.pdf"> 14-05-2018 Appointment of Mr. D. Ram Reddy as Managing Director</a></li>
			<li class="file"><a target="_blank" href="pdf/1714123754BSCPL.pdf">28-03-2018 Investment in Balaji Speciality Chemicals Private Limited</a></li>
			<li class="file"><a target="_blank" href="pdf/1714123726Dimethylacetamide.pdf">22-02-2018 Anti-dumping duty concerning imports of ‘Dimethylacetamide’ </a></li>
			<li class="file"><a target="_blank" href="pdf/1714122985Amalgamation.pdf">20-02-2018 Order of Scheme of Amalgamation </a></li>
			<li class="file"><a target="_blank" href="pdf/1714122939credit.pdf">05-12-2017 Credit Rating India Ratings & Research</a></li>
			<li class="file"><a target="_blank" href="pdf/1714122895com.pdf">04-12-2017 Allotment of land to company</a></li>
			<li class="file"><a target="_blank" href="pdf/1714122845pro.pdf">04-12-2017 Mega Project</a></li>
			<li class="file"><a target="_blank" href="pdf/171403676511.pdf">20-11-2017 Clarification on Increase in Volume -BSE</a></li>
			<li class="file"><a target="_blank" href="pdf/17140367332017.pdf">08-11-2017 Clarification on Financial Results -Q2 2017</a></li>
			<li class="file"><a target="_blank" href="pdf/1714036653co.pdf">30-10-2017 Appointment of Company Secretary & Compliance Officer</a></li>
			<li class="file"><a target="_blank" href="pdf/1714036605BSCL.pdf">30-10-2017 Approval of Investment in Balaji Speciality Chemicals Pvt Ltd</a></li>
			<li class="file"><a target="_blank" href="pdf/1714036524Raja.pdf">17-10-2017 Request from Mr. G. Raja Reddy - Reclassification</a></li>
			<li class="file"><a target="_blank" href="pdf/1714036456cs.pdf">19-07-2017 Resignation of Company Secretary</a></li>
			<li class="file"><a target="_blank" href="pdf/1714036424mn.pdf">06-07-2017 Ministry of Environment Clearance for Expansion</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-77-107"> Memorandum of Association and Articles of Association </label>
        <input type="checkbox" id="menu-77-107" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1734762664BALMOAAOA.pdf">Memorandum of Association and Articles of Association</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-77-108"> Brief profile of Board of Directors </label>
        <input type="checkbox" id="menu-77-108" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1735197094Profile.pdf">Brief profile of Board of Directors</a></li>
	        </ol> 
      </li>
     	    </ol>
  </li>
	  <li>
    <label for="menu-110">Integrated Filing</label>
    <input type="checkbox" id="menu-110" />
    <ol>
	      <li>
        <label for="menu-110-111"> Integrated Filing (Financials) </label>
        <input type="checkbox" id="menu-110-111" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1739594857Integrated Filing.pdf">Integrated Filing for Quarter Ended 31.12.2024</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-110-112"> Integrated Filing (XBRL) </label>
        <input type="checkbox" id="menu-110-112" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1762324841Integrated Governance.pdf">Integrated Governance Report for Q2 30.09.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1762324803Integrated Governance.pdf">Integrated Governance Report for Q2 30.09.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1753875156IG -merged.pdf">Integrated Governance Report for Q1 30.06.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1751462278IG _Merged.pdf">Integrated Governance Report for Q4 31.03.2025</a></li>
			<li class="file"><a target="_blank" href="pdf/1751461592Integrated Governance Report.pdf">Integrated Governance Report for Q3 31.12.2024</a></li>
	        </ol> 
      </li>
     	    </ol>
  </li>
	  <li>
    <label for="menu-113">Postal Ballot</label>
    <input type="checkbox" id="menu-113" />
    <ol>
	      <li>
        <label for="menu-113-115"> Postal Ballot Notice </label>
        <input type="checkbox" id="menu-113-115" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1740230381Postal Ballot Notice.pdf">Notice 21-02-2025</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-113-116"> Scrutinizer Report and Voting Results of Postal Ballot </label>
        <input type="checkbox" id="menu-113-116" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1742911026Outcome_signed.pdf">25.03.25- Outcome of Postal Ballot</a></li>
	        </ol> 
      </li>
     	      <li>
        <label for="menu-113-117"> Newspaper Advertisement Postal Ballot </label>
        <input type="checkbox" id="menu-113-117" />
        <ol>
				<li class="file"><a target="_blank" href="pdf/1740230752Postal Ballot news in Marathi 22022025.pdf">Newspaper Advertisement 22-02-2025- Marathi</a></li>
			<li class="file"><a target="_blank" href="pdf/1740230708Postal Ballot news in English 22022025.pdf">Newspaper Advertisement 22-02-2025-English</a></li>
	        </ol> 
      </li>
     	    </ol>
  </li>
	  <!-- <li>
    <label for="menu-2">Shareholding Pattern</label>
    <input type="checkbox" id="menu-2" />
        <ol>
      <li>
        <label for="menu-2-1">Shareholding pattern</label>
        <input type="checkbox" id="menu-2-1" />
        <ol>
          <li class="file"><a target="_blank" href="pdf/Shareholding Pattern as on 31-03.2011.pdf">Shareholding Pattern as on 31-03.2011.pdf</a></li>
        </ol> 
      </li>
     <li>
        <label for="menu-2-2">Unclaimed dividend</label>
        <input type="checkbox" id="menu-2-2" />
        <ol>
          <li class="file"><a target="_blank" href="pdf/2009-10.pdf">Unclaimed Dividend 2009-10</a></li>
          <li class="file"><a target="_blank" href="pdf/2010-11.pdf">Unclaimed Dividend 2010-11</a></li>
          <li class="file"><a target="_blank" href="pdf/2011-12.pdf">Unclaimed Dividend 2011-12</a></li>
          <li class="file"><a target="_blank" href="pdf/2012-13.pdf">Unclaimed Dividend 2012-13</a></li>
		  <li class="file"><a target="_blank" href="pdf/13-14.pdf">Unclaimed Dividend 2013-14</a></li>
		  <li class="file"><a target="_blank" href="pdf/14-15.pdf">Unclaimed Dividend 2014-15</a></li>
		  <li class="file"><a target="_blank" href="pdf/2015-16.pdf">Unclaimed Dividend 2015-16</a></li>
        </ol> 
      </li>
       <li>
        <label for="menu-2-3">Insider trading regulations</label>
        <input type="checkbox" id="menu-2-3" />
        <ol>
          <li class="file"><a target="_blank" href="pdf/fitch_rating.pdf">fitch rating</a></li>
        </ol> 
      </li>
    </ol>
  </li>
  <li>
    <label for="menu-3">Annual General meetings</label>
    <input type="checkbox" id="menu-3" />
        <ol>
      <li>
        <label for="menu-3-1">AGM Notice </label>
        <input type="checkbox" id="menu-3-1" />
        <ol>
          <li class="file"><a target="_blank" href="#">AGM Notice</a></li>
        </ol> 
      </li>
     <li>
        <label for="menu-3-2">Annual Reports</label>
        <input type="checkbox" id="menu-3-2" />
       <ol>
	   <li class="file"><a target="_blank" href="pdf/FS_BGPL-2016-17.pdf">Financial Statements of Balaji Greentech Products Limited (Subsidiary) - 2016-17</a></li>
	   <li class="file"><a target="_blank" href="pdf/FS_BCL-2016-17.pdf">Financial Statements of Bhagyanagar Chemicals Limited (Subsidiary) - 2016-17</a></li>
	      <li class="file"><a target="_blank" href="pdf/AR2016-17.pdf">Balaji Amines Ltd. 29th Annual Report  2016-2017</a></li>
          <li class="file"><a target="_blank" href="pdf/AR_2015-16.pdf">Balaji Amines Ltd. 28th Annual Report  2015-2016</a></li>
          <li class="file"><a target="_blank" href="pdf/AR_2014-15.pdf">Balaji Amines Ltd. 27th Annual Report  2014-2015</a></li>
          <li class="file"><a target="_blank" href="pdf/AR_2013-14.pdf">Balaji Amines Ltd. 26th Annual Report  2013-2014</a></li>
          <li class="file"><a target="_blank" href="pdf/Balaji%20Amines%20AR_2013.pdf">Balaji Amines Ltd. 25th Annual Report  2012-2013</a></li>
		  <li class="file"><a target="_blank" href="pdf/Balaji%20Amines%20AR%202011-12.pdf">Balaji Amines Ltd. 24th Annual Report  2011-2012</a></li>
          <li class="file"><a target="_blank" href="pdf/Balaji%20Amines%20Ltd_AR%202010-11.pdf">Balaji Amines Ltd. 23th Annual Report  2010-2011</a></li>
          <li class="file"><a target="_blank" href="pdf/Annual%20Report%2009-10.pdf">Balaji Amines Ltd. 22th Annual Report  2009-2010</a></li>
          <li class="file"><a target="_blank" href="pdf/BAL_21_Annual_Report.pdf">Balaji Amines Ltd. 21th Annual Report  2008-2009</a></li>
		  <li class="file"><a target="_blank" href="pdf/2007-2008.pdf">Balaji Amines Ltd. 20th Annual Report  2007-2008</a></li>
          <li class="file"><a target="_blank" href="pdf/test.pdf">Balaji Amines Ltd. 19th Annual Report  2006-2007</a></li>
        </ol> 
      </li>
       <li>
        <label for="menu-3-3">Outcome of AGM</label>
        <input type="checkbox" id="menu-3-3" />
        <ol>
          <li class="file"><a target="_blank" href="pdf/OUTCOME.pdf">Outcome of AGM</a></li>
		   <li class="file"><a target="_blank" href="pdf/PROCEEDINGS OF 29TH AGM.pdf">PROCEEDINGS OF 29TH AGM</a></li>
		    <li class="file"><a target="_blank" href="pdf/Outcome of AGM 2017.pdf">Outcome of AGM 2017</a></li>
			<li class="file"><a target="_blank" href="pdf/scrutinizer's Report on Evoting - 2017.pdf">scrutinizer's Report on Evoting - 2017</a></li>
        </ol> 
      </li>
	  <li>
        <label for="menu-3-4">Scrutiziner’s Report on E-voting</label>
        <input type="checkbox" id="menu-3-4" />
        <ol>
          <li class="file"><a target="_blank" href="pdf/consolidated_report.pdf">Scrutiziner’s Report on Evoting</a></li>
        </ol> 
      </li>
	  <li>
        <label for="menu-3-5">Postal ballot</label>
        <input type="checkbox" id="menu-3-5" />
        <ol>
          <li class="file"><a href="#">Postal ballot</a></li>
        </ol> 
      </li>
    </ol>
  </li>
  
  <li>
    <label for="menu-4">Corporate Governance</label>
    <input type="checkbox" id="menu-4" />
    <ol>
      <li>
        <label for="menu-4-1">Corporate Governance Report </label>
        <input type="checkbox" id="menu-4-1" />
        <ol>
          <li class="file"><a href="#">Corporate Governance Report PDF</a></li>
        </ol> 
      </li>
     <li>
        <label for="menu-4-2">Code of Conduct</label>
        <input type="checkbox" id="menu-4-2" />
        <ol>
          <li class="file"><a href="pdf/coc.pdf">Code of Conduct PDF</a></li>
        </ol> 
      </li>
       <li>
        <label for="menu-4-3">Whistle blower policy</label>
        <input type="checkbox" id="menu-4-3" />
        <ol>
          <li class="file"><a href="pdf/WbPolicy.pdf">Whistle blower policy</a></li>
        </ol> 
      </li>
	  <li>
        <label for="menu-4-4">Insider trading regulations</label>
        <input type="checkbox" id="menu-4-4" />
        <ol>
          <li class="file"><a href="pdf/COCBAL.pdf">Insider trading regulations</a></li>
        </ol> 
      </li>
	  <li>
        <label for="menu-4-5">Credit rating</label>
        <input type="checkbox" id="menu-4-5" />
        <ol>
          <li class="file"><a href="pdf/fitch_rating.pdf">fitch_rating</a></li>
        </ol> 
      </li>
	  <li>
        <label for="menu-4-6">Other policies</label>
        <input type="checkbox" id="menu-4-6" />
        <ol>
          <li class="file"><a href="">Terms and conditions for independent directors appointment</a></li>
		  <li class="file"><a href="">Appointment and Qualification of Directorship</a></li>
        </ol> 
      </li>
    </ol>
  </li>
  
  <li>
    <label for="menu-5">Amalgamation </label>
    <input type="checkbox" id="menu-5" />
    <ol>
              <li class="file"><a target="_blank"  href="pdf/ANN-01 Scheme of Amalgamation.pdf">Scheme of Amalgamation</a></li>
              <li class="file"><a target="_blank"  href="pdf/ANN-02%20Valuation%20Report.pdf">Valuation Report</a></li>
              <li class="file"><a target="_blank"  href="pdf/ANN-03 Report of Audit Committee.pdf">Report of Audit Committee</a></li>
              <li class="file"><a target="_blank"  href="pdf/ANN-04 Fairness opinion.pdf">Fairness opinion</a></li>
              <li class="file"><a target="_blank"  href="pdf/ANN-05 Shareholding pattern of all the Companies - Pre and Post.pdf">Shareholding pattern of all the Companies - Pre and Post</a></li>
			  <li class="file"><a target="_blank"  href="pdf/ANN-06 Audited financials of last 3 years of all the companies.pdf"> Audited financials of last 3 years of all the companies</a></li>
			  <li class="file"><a target="_blank"  href="pdf/ANN-07 Auditor certificate on confirmation of Accounting Standards.pdf">Auditor certificate on confirmation of Accounting Standards</a></li>
			  <li class="file"><a target="_blank"  href="pdf/ANN-11 Board Resolutions.pdf">Board Resolutions</a></li>
			  <li class="file"><a target="_blank"  href="pdf/COMPLAINTS REPORT.pdf">Complaints Report</a></li>
    </ol>
  </li> -->
  
</ol>
                    </div>

            </div>
        </div>
 <footer class="full-bg " id="footer">

            <div class="container">
                <div class="row">

                    <div class="col-sm-4  widget-cell" id="footer-widget-1">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">ABOUT</h3>
                            <div class="menu-overview-footer-container">
                                <ul id="menu-overview-footer" class="menu">
                                    <li id="menu-item-412" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-412"><a href="company-profile.php">Company Profile</a></li>
                                    <li id="menu-item-415" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-415"><a href="mission-values.php">Mission &#038; Values</a></li>
                                    <li id="menu-item-414" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-414"><a href="certificate-awards.php">Certificate &#038; Awards</a></li>
                                    <li id="menu-item-413" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-413"><a href="balaji-management-team.php">Management Team</a></li>
                                    <li id="menu-item-479" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-479"><a href="balaji-amines-history.php">History</a></li>
                                    <li id="menu-item-709" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-709"><a href="bal-presence.php">BAL&#8217;s Presence</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4  widget-cell">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">PRODUCTS</h3>
                            <div class="menu-overview-footer-1-container">
                                <ul id="menu-overview-footer-1" class="menu">
                                    <li id="menu-item-417" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-417"><a href="amines.php">Amines</a></li>
                                    <li id="menu-item-416" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-416"><a href="derivatives.php">Derivatives</a></li>
                                    <li id="menu-item-418" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-418"><a href="speciality-chemicals.php">Speciality Chemicals</a></li>
                                    <li id="menu-item-679" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-679"><a href="excipients.php">Pharma Excipients</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4  widget-cell">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">OTHERS</h3>
                            <div class="menu-footer3-container">
                                <ul id="menu-footer3" class="menu">
                                    <li id="menu-item-655" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-655"><a href="investor-relations.php">Investor Relations</a></li>
                                    <li id="menu-item-420" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-286 current_page_item menu-item-420 active"><a href="careers.php">Careers</a></li>
                                    <li id="menu-item-421" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-421"><a href="corporate-social-responsibility.php">Corporate Social Responsibility</a></li>
                                    <li id="menu-item-713" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-713"><a href="e-brochures.php">E-Brochure</a></li>
                                    <li id="menu-item-423" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-423"><a href="balaji-media.php">Media</a></li>
                                    <li id="menu-item-422" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-422"><a href="contact-us.php">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-1  widget-cell col-sm-offset-1">
                        <div class="widget widget_text">
                            <div class="textwidget"></div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="row">
                            <div class="col-sm-12" id="social-media-icons"></div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 col-sm-offset-6"></div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
		<div class="container-fluid">
            <div class="ddl-full-width-row row">
                <div class="col-sm-12 copyright-footer">
                    <p>copyright © balaji Amines 2025 Developed By <a href="http://katareinfo.com/">Katrare Informatics</a></p>
                </div>
            </div>
        </div>
    </div>
    <!--</div>-->
    <!-- .container & canvas-->
    <script type="text/html" id="tmpl-wp-playlist-current-item">
        <# if ( data.image ) { #>
            <img src="{{ data.thumb.src }}" alt="" />
            <# } #>
                <div class="wp-playlist-caption">
                    <span class="wp-playlist-item-meta wp-playlist-item-title">&#8220;{{ data.title }}&#8221;</span>
                    <# if ( data.meta.album ) { #><span class="wp-playlist-item-meta wp-playlist-item-album">{{ data.meta.album }}</span>
                        <# } #>
                            <# if ( data.meta.artist ) { #><span class="wp-playlist-item-meta wp-playlist-item-artist">{{ data.meta.artist }}</span>
                                <# } #>
                </div>
    </script>
    <script type="text/html" id="tmpl-wp-playlist-item">
        <div class="wp-playlist-item">
            <a class="wp-playlist-caption" href="{{ data.src }}">
			{{ data.index ? ( data.index + '. ' ) : '' }}
			<# if ( data.caption ) { #>
				{{ data.caption }}
			<# } else { #>
				<span class="wp-playlist-item-title">&#8220;{{{ data.title }}}&#8221;</span>
				<# if ( data.artists && data.meta.artist ) { #>
				<span class="wp-playlist-item-artist"> &mdash; {{ data.meta.artist }}</span>
				<# } #>
			<# } #>
		</a>
            <# if ( data.meta.length_formatted ) { #>
                <div class="wp-playlist-item-length">{{ data.meta.length_formatted }}</div>
                <# } #>
        </div>
    </script>
    <script type='text/javascript' src='wp-content/themes/toolset-bootstrap/bootstrap3/js/bootstrap.min.js?ver=3.3.4'></script>
    <script type='text/javascript' src='wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='wp-includes/js/jquery/ui/datepicker.min.js?ver=1.11.4'></script>
    <script type='text/javascript'>
        jQuery(document).ready(function(jQuery) {
            jQuery.datepicker.setDefaults({
                "closeText": "Close",
                "currentText": "Today",
                "monthNames": ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                "monthNamesShort": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                "nextText": "Next",
                "prevText": "Previous",
                "dayNames": ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                "dayNamesShort": ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                "dayNamesMin": ["S", "M", "T", "W", "T", "F", "S"],
                "dateFormat": "MM d, yy",
                "firstDay": 1,
                "isRTL": false
            });
        });
    </script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var mejsL10n = {
            "language": "en-US",
            "strings": {
                "Close": "Close",
                "Fullscreen": "Fullscreen",
                "Turn off Fullscreen": "Turn off Fullscreen",
                "Go Fullscreen": "Go Fullscreen",
                "Download File": "Download File",
                "Download Video": "Download Video",
                "Play": "Play",
                "Pause": "Pause",
                "Captions\/Subtitles": "Captions\/Subtitles",
                "None": "None",
                "Time Slider": "Time Slider",
                "Skip back %1 seconds": "Skip back %1 seconds",
                "Video Player": "Video Player",
                "Audio Player": "Audio Player",
                "Volume Slider": "Volume Slider",
                "Mute Toggle": "Mute Toggle",
                "Unmute": "Unmute",
                "Mute": "Mute",
                "Use Up\/Down Arrow keys to increase or decrease volume.": "Use Up\/Down Arrow keys to increase or decrease volume.",
                "Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.": "Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds."
            }
        };
        var _wpmejsSettings = {
            "pluginPath": "\/wp-includes\/js\/mediaelement\/"
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='wp-includes/js/mediaelement/mediaelement-and-player.min.js?ver=2.22.0'></script>
    <script type='text/javascript' src='wp-includes/js/mediaelement/wp-mediaelement.min.js?ver=4.7.3'></script>
    <script type='text/javascript' src='wp-includes/js/underscore.min.js?ver=1.8.3'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var _wpUtilSettings = {
            "ajax": {
                "url": "\/wp-admin\/admin-ajax.php"
            }
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='wp-includes/js/wp-util.min.js?ver=4.7.3'></script>
    <script type='text/javascript' src='wp-includes/js/backbone.min.js?ver=1.2.3'></script>
    <script type='text/javascript' src='wp-includes/js/mediaelement/wp-playlist.min.js?ver=4.7.3'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var wpv_pagination_local = {
            "front_ajaxurl": "http:\/\/www.balajiamines.in\/wp-admin\/admin-ajax.php",
            "ajax_pagination_url": "http:\/\/www.balajiamines.in\/wpv-ajax-pagination\/",
            "calendar_image": "http:\/\/www.balajiamines.in\/wp-content\/plugins\/wp-views\/embedded\/res\/img\/calendar.gif",
            "calendar_text": "Select date",
            "datepicker_min_date": null,
            "datepicker_max_date": null
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='wp-content/plugins/wp-views/embedded/res/js/wpv-pagination-embedded.js?ver=1.10'></script>
    <script type='text/javascript' src='wp-includes/js/wp-embed.min.js?ver=4.7.3'></script>
    <script>
        jQuery(window).scroll(function() {
            if (jQuery(document).scrollTop() > 50) {
                jQuery('header').addClass('shrink');
            } else {
                jQuery('header').removeClass('shrink');
            }
        });

        /*Youtube video*/
        jQuery('.js-lazyYT').lazyYT();

        /** Stop playing youtube video when page scrolls */

        jQuery(document).on('scroll', function() {
            var scrollTop = jQuery(window).scrollTop();
            if (scrollTop > pos.top + 315) {
                player.stopVideo();
            }
        })
    </script>
    <script>
        /* moving object */
        jQuery('.marquee').marquee({
            //speed in milliseconds of the marquee
            duration: 6000,
            //gap in pixels between the tickers
            gap: 1500,
            //time in milliseconds before the marquee will start animating
            delayBeforeStart: 0,
            //'left' or 'right'
            direction: 'right',
            //true or false - should the marquee be duplicated to show an effect of continues flow
            duplicated: true
        });
    </script>
    <script>
        jQuery(document).ready(function() {

            /* Apply fancybox to multiple items */

            jQuery("a.balaji-products").fancybox({
                'transitionIn': 'elastic',
                'transitionOut': 'elastic',
                'speedIn': 600,
                'speedOut': 200,
                'overlayShow': false
            });

            jQuery('.member-mug-shot').on('click', function() {
                jQuery('.collapse').collapse('hide');
            })

        });
    </script>
    <script>
        (function(jQuery) {
            jQuery(document).ready(function() {
                jQuery(".video-button").click(function() {
                    jQuery(".video-embed").css({
                        "opacity": "1",
                        "display": "block"
                    });
                    jQuery(".video-embed")[0].src += "&autoplay=1";
                    jQuery(this).unbind("click");
                });
            });
        })(jQuery)
    </script>
    <script>
        jQuery(document).ready(function() {

            jQuery('.fancybox').fancybox({
                beforeShow: function() {
                    this.title = jQuery(this.element).data("caption");
                }
            });

            jQuery("a#single_image-popup").fancybox();

        });
    </script>
    <script>
        jQuery(window).load(function() {
            jQuery('#single_image-popup').fancybox({
                beforeLoad: function() {
                    this.title = jQuery(this.element).find('img').attr('alt');
                }

            });

            jQuery('#single_image-popup').fancybox({
                'titleFromAlt': true,
                'titlePosition': 'inside'

            });

            jQuery("a#single_image-popup").trigger('click');
        });
    </script>
    <script>
        function myFunction() {
            window.print();
        }
    </script>
</body>

</html>