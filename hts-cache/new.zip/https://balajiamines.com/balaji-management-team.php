<!DOCTYPE html>
<html lang="en-US" class="no-js">
<head>
    <meta charset="UTF-8" />
		<meta name="author" content="Balaji Amines" />
	<meta name="keywords" content=" balaji , balaji amines, balaji amines solapur, Chemical Manufacturers in India, Chemical Manufacturers India, Industrial Chemicals Manufacturers, Industrial Chemicals Manufacturers in India Chemical manufacturing company in india, Chemical manufacturing company in Solapur, Chemical manufacturing company, methyl, Chemical Manufacturer,hydrochloride derivatives, industrial chemicals manufacturers, industrial chemicals suppliers, industrial chemicals india, industrial chemicals exporters, industrial chemicals manufacturer, industrial chemicals supplier, industrial chemicals exporter, industrial chemicals from india, industrial chemicals wholesale, industrial chemicals in india">
	<meta name="description"  content="Manufacturer of methyl and ethyl amines and their amide and hydrochloride derivatives, located in India.  Chemical manufacturing company in india">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Balaji &ndash; Management Team</title>
    <link rel="shortcut icon" href="wp-content/themes/toolset-bootstrap/favicon.ico">
    <style type="text/css">
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 .07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
    <link rel='stylesheet' id='formidable-css' href='wp-content/uploads/formidable/css/formidablepro.css?ver=2.03.03' type='text/css' media='all' />
    <link rel='stylesheet' id='wp_ddl_layout_fe_css-css' href='wp-content/uploads/ddl-layouts-tmp/d41d8cd98f00b204e9800998ecf8427e.css?ver=1.3.2' type='text/css' media='screen' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3/css/bootstrap.min.css?ver=3.3.4' type='text/css' media='all' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_theme_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3/css/bootstrap-theme.min.css' type='text/css' media='all' />
    <link rel='stylesheet' id='toolset-bootstrap-theme-style-css' href='wp-content/themes/toolset-bootstrap/style.css?ver=1.8' type='text/css' media='all' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_adjustment_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3_adjustment.css' type='text/css' media='all' />
    <link rel='stylesheet' id='menu-cells-front-end-css' href='wp-content/plugins/layouts/resources/css/cell-menu-css.css?ver=4.7.3' type='text/css' media='screen' />
    <link rel='stylesheet' id='ddl-front-end-css' href='wp-content/plugins/layouts/resources/css/ddl-front-end.css?ver=4.7.3' type='text/css' media='screen' />
    <link rel='stylesheet' id='toolset-common-css' href='wp-content/plugins/layouts/toolset/toolset-common/res/css/toolset-common.css?ver=4.7.3' type='text/css' media='screen' />
    <link rel='stylesheet' id='wptoolset-field-datepicker-css' href='wp-content/plugins/wp-views/embedded/common/toolset-forms/css/wpt-jquery-ui/datepicker.css?ver=1.10' type='text/css' media='all' />
    <link rel='stylesheet' id='mediaelement-css' href='wp-includes/js/mediaelement/mediaelementplayer.min.css?ver=2.22.0' type='text/css' media='all' />
    <link rel='stylesheet' id='wp-mediaelement-css' href='wp-includes/js/mediaelement/wp-mediaelement.min.css?ver=4.7.3' type='text/css' media='all' />
    <link rel='stylesheet' id='views-pagination-style-css' href='wp-content/plugins/wp-views/embedded/res/css/wpv-pagination.css?ver=1.10' type='text/css' media='all' />
    <script type='text/javascript' src='wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
    <script type='text/javascript' src='wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var DDLayout_fe_settings = {
            "DDL_JS": {
                "css_framework": "bootstrap-3",
                "DEBUG": false
            }
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='wp-content/plugins/layouts/resources/js/ddl-layouts-frontend.js?ver=1.3.2'></script>
   <style type="text/css">
        .recentcomments a {
            display: inline !important;
            padding: 0 !important;
            margin: 0 !important;
        }
    </style><!-- Important Owl stylesheet -->
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/owl.carousel.css">
    <!-- Default Theme -->
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/owl.theme.css">
    <!-- Include js plugin -->
    <script src="wp-content/themes/toolset-bootstrap/js/owl.carousel.js"></script>
    <!--Fancy box -->
    <script type="text/javascript" src="wp-content/themes/toolset-bootstrap/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/fancybox/jquery.fancybox-1.3.4.css" type="text/css" media="screen" />
    <!--Fancy box ends-->
    <link href='https://fonts.googleapis.com/css?family=Khand:400,300,500,600,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,100italic,100,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link rel='stylesheet' href="wp-content/themes/toolset-bootstrap/css/mediatree.css">
    <link rel='stylesheet' media="print" href="wp-content/themes/toolset-bootstrap/css/custom-print.css">
    <link rel='stylesheet' href="wp-content/themes/toolset-bootstrap/css/zara.css">
    <link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>
    <link href="wp-content/themes/toolset-bootstrap/css/jasny-bootstrap.min.css" rel="stylesheet" media="screen">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.matchHeight.js"></script>
    <script src="wp-content/themes/toolset-bootstrap/js/jasny-bootstrap.min.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/flexslider.css" type="text/css">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.flexslider.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.matchHeight-min.js" type="text/javascript"></script>
    <script type="text/javascript" src="wp-content/themes/toolset-bootstrap/lazyyt/lazyYT.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/lazyyt/lazyYT.css">
    <script type='text/javascript' src='//cdn.jsdelivr.net/jquery.marquee/1.3.1/jquery.marquee.min.js'></script>
</head>
<body class="page-template page-template-page-layouts page-template-page-layouts-php page page-id-246">

    <!-- Off Canvas Menu Starts -->

    <div class="navmenu navmenu-default navmenu-fixed-right">
        <ul id="menu-menu-1" class="nav navmenu-nav">
            <li id="menu-item-20" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-2 current_page_item menu-item-20 active"><a href="index.php">Homepage</a></li>
            <li id="menu-item-656" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-656"><a href="#">About us</a>
                <ul class="sub-menu">
                    <li id="menu-item-267" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-267"><a href="company-profile.php">Company Profile</a></li>
                    <li id="menu-item-261" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-261"><a href="mission-values.php">Mission &#038; Values</a></li>
                    <li id="menu-item-280" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-280"><a href="certificate-awards.php">Certificate &#038; Awards</a></li>
                    <li id="menu-item-348" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-348"><a href="balaji-management-team.php">Management Team</a></li>
                    <li id="menu-item-339" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-339"><a href="balaji-amines-history.php">History</a></li>
                    <li id="menu-item-710" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-710"><a href="bal-presence.php">BAL&#8217;s Presence</a></li>
                </ul>
            </li>
            <li id="menu-item-400" class="menu-item menu-item-type-post_type_archive menu-item-object-product menu-item-has-children menu-item-400"><a href="category.php">Products</a>
                <ul class="sub-menu">
                    <li id="menu-item-658" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-658"><a href="amines.php">Amines</a></li>
                    <li id="menu-item-657" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-657"><a href="derivatives.php">Derivatives</a></li>
                    <li id="menu-item-659" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-659"><a href="speciality-chemicals.php">Speciality Chemicals</a></li>
                    <li id="menu-item-678" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-678"><a href="excipients.php">Pharma Excipients</a></li>
                </ul>
            </li>
            <li id="menu-item-534" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-534"><a href="investor-relations.php">Investor Relations</a></li>
            <li id="menu-item-290" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-290"><a href="careers.php">Careers</a></li>
            <li id="menu-item-299" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-299"><a href="corporate-social-responsibility.php">Corporate Social Responsibility</a></li>
            <li id="menu-item-282" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-282"><a href="contact-us.php">Contact Us</a></li>
            <li id="menu-item-307" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-307"><a href="balaji-media.php">Media</a></li>
            <li id="menu-item-711" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-711"><a href="e-brochures.php">E-Brochure</a></li>
        </ul>
    </div>    <div class="canvas">
        <header class="full-bg black-bg" id="homepage-header">

            <div class="container">
                <div class="row">

                    <div class="col-sm-1" id="off-canvas-button">
                        <div class="navbar navbar-default">
                            <button type="button" class="navbar-toggle" data-toggle="offcanvas" data-recalc="false" data-target=".navmenu" data-canvas=".canvas">
                                <br />
                                <span class="icon-bar"></span>
                                <br />
                                <span class="icon-bar"></span>
                                <br />
                                <span class="icon-bar"></span>
                                <br />
                            </button>
                        </div>
                    </div>
                    <div class="col-sm-4 col-sm-offset-3" id="homepage-logo">
                        <p>
                            <!--<a href=""><img src="wp-content/uploads/2015/09/modernxd-logo.png" alt="Modern XD" class="aligncenter size-full img-responsive"  ></a>--></p>
                        <p>
                            <a href=""><img src="wp-content/uploads/2015/10/balaji_logo.png" alt="Balaji Almines" class="aligncenter size-full img-responsive"></a>
                        </p>
                    </div>
                </div>
            </div>
        </header>
        <div class="container-fluid">
            <div class="ddl-full-width-row row">
                <div class="col-sm-12 page-featured-image">
                    <div class="thumbnail">
                        <img src="wp-content/uploads/2015/10/managmnt-banner.jpg">
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">

                <div class="col-sm-4 page-title-div text-center col-sm-offset-4">
                    <h1>MANAGEMENT TEAM</h1>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">

                <div class="col-sm-10 heading-color col-sm-offset-1">
                    <h2>Board of Directors</h2>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">

                <div class="col-sm-12">
                    <div class="thumbnail">
                        <img src="wp-content/uploads/2015/10/board-of-directors.jpg">
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">

                <div class="col-sm-10 heading-color col-sm-offset-1">
                    <h2>WHOLE TIME DIRECTORS</h2>
                    <h2></h2>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">

                <div class="col-sm-10 col-sm-offset-1">

                    <div class="row">
										<div class="col-md-2 management-thumb-col">
                            <a href="#member-1" class="member-mug-shot" data-toggle="collapse" aria-expanded="false" aria-controls="member-1"><img style ="border:1px solid #13238e;" width="151" height="144" src="team/350_1506058768.jpg" class="attachment-medium size-medium wp-post-image" alt="prathap_reddy" srcset="team/350_1506058768.jpg" sizes="(max-width: 151px) 100vw, 151px" />Mr. Ande Prathap Reddy,<br/> Executive Chairman</a>
                        </div>
						<div class="col-md-2 management-thumb-col">
                            <a href="#member-2" class="member-mug-shot" data-toggle="collapse" aria-expanded="false" aria-controls="member-2"><img style ="border:1px solid #13238e;" width="151" height="144" src="team/350_1506058816.jpg" class="attachment-medium size-medium wp-post-image" alt="prathap_reddy" srcset="team/350_1506058816.jpg" sizes="(max-width: 151px) 100vw, 151px" />Mr. Rajeshwar Reddy Nomula,<br/> Whole-time Director</a>
                        </div>
						<div class="col-md-2 management-thumb-col">
                            <a href="#member-3" class="member-mug-shot" data-toggle="collapse" aria-expanded="false" aria-controls="member-3"><img style ="border:1px solid #13238e;" width="151" height="144" src="team/350_1506058910.jpg" class="attachment-medium size-medium wp-post-image" alt="prathap_reddy" srcset="team/350_1506058910.jpg" sizes="(max-width: 151px) 100vw, 151px" />Mr. Dundurapu Ram Reddy, <br/>Managing Director</a>
                        </div>
						<div class="col-md-2 management-thumb-col">
                            <a href="#member-5" class="member-mug-shot" data-toggle="collapse" aria-expanded="false" aria-controls="member-5"><img style ="border:1px solid #13238e;" width="151" height="144" src="team/350_1506058989.jpg" class="attachment-medium size-medium wp-post-image" alt="prathap_reddy" srcset="team/350_1506058989.jpg" sizes="(max-width: 151px) 100vw, 151px" />Mr. Ande Srinivas Reddy,<br/> Whole-time Director and CFO</a>
                        </div>
	                        <!-- wpv-loop-start --
                        <div class="col-md-2 management-thumb-col">
                            <a href="#member-426" class="member-mug-shot" data-toggle="collapse" aria-expanded="false" aria-controls="member-426"><img width="151" height="144" src="wp-content/uploads/2015/10/prathap_reddy.png" class="attachment-medium size-medium wp-post-image" alt="prathap_reddy" srcset="wp-content/uploads/2015/10/prathap_reddy.png 151w, wp-content/uploads/2015/10/prathap_reddy-150x144.png 150w" sizes="(max-width: 151px) 100vw, 151px" />Mr. A. Prathap Reddy</a>
                        </div>
                        <div class="col-md-2 management-thumb-col">
                            <a href="#member-434" class="member-mug-shot" data-toggle="collapse" aria-expanded="false" aria-controls="member-434"><img width="152" height="145" src="wp-content/uploads/2015/10/rajeshwar_reddy.png" class="attachment-medium size-medium wp-post-image" alt="rajeshwar_reddy" />Mr. N. Rajeshwar Reddy</a>
                        </div>
                        <div class="col-md-2 management-thumb-col">
                            <a href="#member-436" class="member-mug-shot" data-toggle="collapse" aria-expanded="false" aria-controls="member-436"><img width="151" height="145" src="wp-content/uploads/2015/10/d_ram_reddy.png" class="attachment-medium size-medium wp-post-image" alt="d_ram_reddy" srcset="wp-content/uploads/2015/10/d_ram_reddy.png 151w, wp-content/uploads/2015/10/d_ram_reddy-150x145.png 150w" sizes="(max-width: 151px) 100vw, 151px" />Mr. D. Ram Reddy</a>
                        </div>
                        <div class="col-md-2 management-thumb-col">
                            <a href="#member-438" class="member-mug-shot" data-toggle="collapse" aria-expanded="false" aria-controls="member-438"><img width="151" height="145" src="wp-content/uploads/2015/10/hemanth_reddy.png" class="attachment-medium size-medium wp-post-image" alt="hemanth_reddy" srcset="wp-content/uploads/2015/10/hemanth_reddy.png 151w, wp-content/uploads/2015/10/hemanth_reddy-150x145.png 150w" sizes="(max-width: 151px) 100vw, 151px" />Mr. G. Hemanth Reddy</a>
                        </div>
                        <div class="col-md-2 management-thumb-col">
                            <a href="#member-441" class="member-mug-shot" data-toggle="collapse" aria-expanded="false" aria-controls="member-441"><img width="151" height="145" src="wp-content/uploads/2015/10/srinivas_reddy.png" class="attachment-medium size-medium wp-post-image" alt="srinivas_reddy" srcset="wp-content/uploads/2015/10/srinivas_reddy.png 151w, wp-content/uploads/2015/10/srinivas_reddy-150x145.png 150w" sizes="(max-width: 151px) 100vw, 151px" />Mr. A. Srinivas Reddy</a>
                        </div>

                        -- wpv-loop-end -->
                    </div>

                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">

                <div class="col-sm-10 heading-color col-sm-offset-1">
                    <h2>INDEPENDENT DIRECTORS</h2>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">

                <div class="col-sm-10 col-sm-offset-1">

                    <div class="row">
										<div class="col-md-2 management-thumb-col">
                            <a href="#member-11" class="member-mug-shot" data-toggle="collapse" aria-expanded="false" aria-controls="member-11"><img style ="border:1px solid #13238e;" width="151" height="144" src="team/350_1688732966.jpg" class="attachment-medium size-medium wp-post-image" alt="prathap_reddy" srcset="team/350_1688732966.jpg" sizes="(max-width: 151px) 100vw, 151px" />Dr. Suhasini Yatin Shah, <br/>Independent Director</a>
                        </div>
						<div class="col-md-2 management-thumb-col">
                            <a href="#member-12" class="member-mug-shot" data-toggle="collapse" aria-expanded="false" aria-controls="member-12"><img style ="border:1px solid #13238e;" width="151" height="144" src="team/350_1688733030.jpg" class="attachment-medium size-medium wp-post-image" alt="prathap_reddy" srcset="team/350_1688733030.jpg" sizes="(max-width: 151px) 100vw, 151px" />Dr. Uma Rajiv Pradhan, <br/>Independent Director</a>
                        </div>
						<div class="col-md-2 management-thumb-col">
                            <a href="#member-13" class="member-mug-shot" data-toggle="collapse" aria-expanded="false" aria-controls="member-13"><img style ="border:1px solid #13238e;" width="151" height="144" src="team/350_1688733097.jpg" class="attachment-medium size-medium wp-post-image" alt="prathap_reddy" srcset="team/350_1688733097.jpg" sizes="(max-width: 151px) 100vw, 151px" />Mr. Mohan Kumar Ramakrishna, <br/>Independent Director</a>
                        </div>
						<div class="col-md-2 management-thumb-col">
                            <a href="#member-14" class="member-mug-shot" data-toggle="collapse" aria-expanded="false" aria-controls="member-14"><img style ="border:1px solid #13238e;" width="151" height="144" src="team/350_1688733144.jpg" class="attachment-medium size-medium wp-post-image" alt="prathap_reddy" srcset="team/350_1688733144.jpg" sizes="(max-width: 151px) 100vw, 151px" />Mr. Adabala Seshagiri Rao, <br/>Independent Director</a>
                        </div>
	                        <!-- wpv-loop-start --
                        <div class="col-md-2 management-thumb-col">
                            <a href="#member-444" class="member-mug-shot" data-toggle="collapse" aria-expanded="false" aria-controls="member-444"><img width="151" height="147" src="wp-content/uploads/2015/10/naveen-chandra.png" class="attachment-medium size-medium wp-post-image" alt="naveen-chandra" srcset="wp-content/uploads/2015/10/naveen-chandra.png 151w, wp-content/uploads/2015/10/naveen-chandra-150x147.png 150w" sizes="(max-width: 151px) 100vw, 151px" /><span>T. Naveen Chandra</span></a>
                        </div>
                        <div class="col-md-2 management-thumb-col">
                            <a href="#member-447" class="member-mug-shot" data-toggle="collapse" aria-expanded="false" aria-controls="member-447"><img width="151" height="147" src="wp-content/uploads/2015/10/amerender_reddy.jpg" class="attachment-medium size-medium wp-post-image" alt="amerender_reddy" srcset="wp-content/uploads/2015/10/amerender_reddy.jpg 151w, wp-content/uploads/2015/10/amerender_reddy-150x147.jpg 150w" sizes="(max-width: 151px) 100vw, 151px" /><span>Amarender Reddy Munipuri</span></a>
                        </div>
                        <div class="col-md-2 management-thumb-col">
                            <a href="#member-450" class="member-mug-shot" data-toggle="collapse" aria-expanded="false" aria-controls="member-450"><img width="152" height="149" src="wp-content/uploads/2015/10/blank.png" class="attachment-medium size-medium wp-post-image" alt="blank" /><span>Chavali Satyanarayana Murthy</span></a>
                        </div>
                        <div class="col-md-2 management-thumb-col">
                            <a href="#member-452" class="member-mug-shot" data-toggle="collapse" aria-expanded="false" aria-controls="member-452"><img width="152" height="149" src="wp-content/uploads/2015/10/blank.png" class="attachment-medium size-medium wp-post-image" alt="blank" />Kashinath Revapa Dholle</a>
                        </div>
                        <div class="col-md-2 management-thumb-col">
                            <a href="#member-454" class="member-mug-shot" data-toggle="collapse" aria-expanded="false" aria-controls="member-454"><img width="151" height="145" src="wp-content/uploads/2015/10/vimala.png" class="attachment-medium size-medium wp-post-image" alt="vimala" srcset="wp-content/uploads/2015/10/vimala.png 151w, wp-content/uploads/2015/10/vimala-150x145.png 150w" sizes="(max-width: 151px) 100vw, 151px" />Mrs. Vimala B. Madon</a>
                        </div>

                        -- wpv-loop-end -->
                    </div>

                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
			  <div class="col-sm-10 col-sm-offset-1">
	              
					                 <div class="collapse" id="member-1">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="151" height="145" src="team/350_1506058768.jpg" class="attachment-medium size-medium wp-post-image" alt="vimala" srcset="team/350_1506058768.jpg 150w" sizes="(max-width: 151px) 100vw, 151px" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>Mr. Ande Prathap Reddy,<br/> Executive Chairman</span></div>
                                    <div class="member-description">
                                        <p>Mr. A. Prathap Reddy, a civil engineer by qualification, started Balaji Amines Ltd (BAL) in the year 1988 for the manufacture of Methyl Amines and Ethyl Amines. His impeccable entrepreneurial skills, endurance and passion has brought glory to the firm, making BAL one of the leading manufacturers and exporters of specialty chemicals, aliphatic amines and derivatives in the chemical industry. For his remarkable contribution in this field, he has received an award in World Class Manufacturing and Operational Excellence for the year 2011 as well as in the Manufacturing Leadership Awards & Conclave 2012 instituted by the Industry 2.0 magazine.</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
	              
					                 <div class="collapse" id="member-2">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="151" height="145" src="team/350_1506058816.jpg" class="attachment-medium size-medium wp-post-image" alt="vimala" srcset="team/350_1506058816.jpg 150w" sizes="(max-width: 151px) 100vw, 151px" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>Mr. Rajeshwar Reddy Nomula,<br/> Whole-time Director</span></div>
                                    <div class="member-description">
                                        <p>Mr. N. Rajeshwar Reddy, our Joint M.D joined the BAL director’s team in the year 1988. He was initially appointed as an Executive Director in Balaji Cement Pvt Ltd. for the implementation of a project, which he successfully completed. His main responsibilities are to oversee the routine operations of the plant in Solapur. With his 30 years of expertise, his marvellous skills have made it possible to execute the projects at a lower cost within the specified time.</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
	              
					                 <div class="collapse" id="member-3">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="151" height="145" src="team/350_1506058910.jpg" class="attachment-medium size-medium wp-post-image" alt="vimala" srcset="team/350_1506058910.jpg 150w" sizes="(max-width: 151px) 100vw, 151px" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>Mr. Dundurapu Ram Reddy, <br/>Managing Director</span></div>
                                    <div class="member-description">
                                        <p>Mr. D. Ram’s three decades of experience in the management sector and his contribution to the rise of Balaji Amines is incomparable. Since 1988, he is hugely responsible for the procurement, marketing and logistics activities of the company. He has taken on a central part in setting up customer and supplier relationships with leading buyers and providers of specialty chemicals, both in the state and also overseas. He has been instrumental in achieving the first of its kind large scale supply contract arrangement with the world’s leading company in specialty chemicals.</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
	              
					                 <div class="collapse" id="member-4">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="151" height="145" src="team/350_1506058956.jpg" class="attachment-medium size-medium wp-post-image" alt="vimala" srcset="team/350_1506058956.jpg 150w" sizes="(max-width: 151px) 100vw, 151px" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>Mr. G. Hemanth Reddy</span></div>
                                    <div class="member-description">
                                        <p>Mr. G. Hemanth Reddy, a Post graduate in management with Finance and Marketing as his specialization, has more than 25 years of experience in the business sector. He has been influential in implementing various projects globally such as water supply projects, solar projects, rural electrification and global sourcing of material in Africa to name a few. His primary responsibilities are to manage operations, finance and administration of Unit-II of the company.</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
	              
					                 <div class="collapse" id="member-5">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="151" height="145" src="team/350_1506058989.jpg" class="attachment-medium size-medium wp-post-image" alt="vimala" srcset="team/350_1506058989.jpg 150w" sizes="(max-width: 151px) 100vw, 151px" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>Mr. Ande Srinivas Reddy,<br/> Whole-time Director and CFO</span></div>
                                    <div class="member-description">
                                        <p>Mr. A. Srinivas Reddy commenced his career in one of largest management consulting firms in USA, Capgemini as a management consultant, and worked in several capacities in different countries. He has worked as a project manager on multiple projects at Fortune 100 US companies including Sprint, Goodyear, Agilent Technologies Cummins Inc, etc. Currently, he is responsible for essential projects at the firm.</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
	              
					                 <div class="collapse" id="member-6">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="151" height="145" src="team/350_1506059018.png" class="attachment-medium size-medium wp-post-image" alt="vimala" srcset="team/350_1506059018.png 150w" sizes="(max-width: 151px) 100vw, 151px" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>Mr. T. Naveen Chandra</span></div>
                                    <div class="member-description">
                                        <p>He holds a Bachelor’s degree in Commerce and is a Fellow Member of the Institute of CharteredAccountants of India. He has over 30 years of rich and varied experience in the fields of Finance,Taxation, Projects, and Capital Markets.</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
	              
					                 <div class="collapse" id="member-7">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="151" height="145" src="team/350_1506059048.jpg" class="attachment-medium size-medium wp-post-image" alt="vimala" srcset="team/350_1506059048.jpg 150w" sizes="(max-width: 151px) 100vw, 151px" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>Mr. Amarender Reddy Munipuri</span></div>
                                    <div class="member-description">
                                        <p>He is a graduate by qualification, and is an Independent Director of the firm. He possesses immense knowledge in the Banking sector. He started his career as a Branch Manager in State bank of Hyderabad and proceeded to be the Chief Manager, Asst. General Manager and Dy. General Manager of the same. He also worked with State bank of Mysore as Dy. GeneralManager.</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
	              
					                 <div class="collapse" id="member-8">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="151" height="145" src="team/350_1506059087.png" class="attachment-medium size-medium wp-post-image" alt="vimala" srcset="team/350_1506059087.png 150w" sizes="(max-width: 151px) 100vw, 151px" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>Mrs. Vimala B. Madon</span></div>
                                    <div class="member-description">
                                        <p>As an Independent Director of the company, Mrs. Vimala B. Madon has been a power to reckon with. Her qualifications backed with 40 years of work experience in the banking sector are impeccable. She retired as a General Manager (technology) at SBH, and later worked at the State Bank of Travancore, where she handled the portfolio of MIS and Business Process Reengineering at the bank’s head offices in Hyderabad and Thiruvananthapuram. She retired in 2008.</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
	              
					                 <div class="collapse" id="member-9">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="151" height="145" src="team/350_154236814.jpg" class="attachment-medium size-medium wp-post-image" alt="vimala" srcset="team/350_154236814.jpg 150w" sizes="(max-width: 151px) 100vw, 151px" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>Mr. Chavali Satyanarayana Murthy</span></div>
                                    <div class="member-description">
                                        <p>Mr. Murthy commenced his career with ICICI ventures. Then he moved on to being a Management Consultant, a Successful Entrepreneur and a Professional Executive. Currently, he is the CEO of Aurigene Discovery Technologies Ltd.</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
	              
					                 <div class="collapse" id="member-10">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="151" height="145" src="team/350_12456831.jpg" class="attachment-medium size-medium wp-post-image" alt="vimala" srcset="team/350_12456831.jpg 150w" sizes="(max-width: 151px) 100vw, 151px" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>Mr. Kashinath Revapa Dholle</span></div>
                                    <div class="member-description">
                                        <p>Kashinath Revapa Dholle, an Independent Director of the company, holds a Masters degree in Science (Chemistry). He started his career as a chemist in reputed MNC’s for 10 years where he gained extensive knowledge in manufacturing medicines. He later moved on to being an entrepreneur. At present, he is the Managing Director of Kross International Private Limited Solapur.</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
	              
					                 <div class="collapse" id="member-11">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="151" height="145" src="team/350_1688732966.jpg" class="attachment-medium size-medium wp-post-image" alt="vimala" srcset="team/350_1688732966.jpg 150w" sizes="(max-width: 151px) 100vw, 151px" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>Dr. Suhasini Yatin Shah, <br/>Independent Director</span></div>
                                    <div class="member-description">
                                        <p>Dr. Suhasini Yatin Shah, aged 57 years, holds a bachelor’s degree in law, a bachelor’s degree in medicine and a bachelor’s degree in surgery from Shivaji University, Kolhapur. She has a post graduate diploma in medico legal systems from the Symbiosis Centre of Health Care, Pune and has participated in a programme on small and medium enterprises at Indian Institute of Management, Ahmedabad. She was a founder of Precision Camshafts Limited and has been associated with Precision Camshafts Limited since 1992.</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
	              
					                 <div class="collapse" id="member-12">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="151" height="145" src="team/350_1688733030.jpg" class="attachment-medium size-medium wp-post-image" alt="vimala" srcset="team/350_1688733030.jpg 150w" sizes="(max-width: 151px) 100vw, 151px" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>Dr. Uma Rajiv Pradhan, <br/>Independent Director</span></div>
                                    <div class="member-description">
                                        <p>Dr. Uma Rajiv Pradhan, aged 68 years, holds a Degree in Master of Surgery in Ophthalmology from Shivaji University, Kolhapur and Diploma in Ophthalmic Medicine and Surgery from C.P.S. Bombay and holds Fellowship from College of Physicians and Surgeons, Bombay and also holds Diplomate of National Board (D.N.B.)from National Board, Delhi. She is a Practising Eye Surgeon. She owns and operates Pradhan Eye Hospital & Lasik Laser Center in Solapur and has been practicing for more than 3 decades. She has demonstrated her professional Services in diverse facets of operational and management of the hospital and social service.</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
	              
					                 <div class="collapse" id="member-13">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="151" height="145" src="team/350_1688733097.jpg" class="attachment-medium size-medium wp-post-image" alt="vimala" srcset="team/350_1688733097.jpg 150w" sizes="(max-width: 151px) 100vw, 151px" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>Mr. Mohan Kumar Ramakrishna, <br/>Independent Director</span></div>
                                    <div class="member-description">
                                        <p>Mr. Mohan Kumar Ramakrishna, aged 63 years, holds a Degree of Master of Commerce and Degree of Master of Law from Osmania University and is Retired from Indian Revenue Service as an Additional Commissioner of Income Tax. Presently, he is associated as Partner in SK & SK Associates, Tax Consultants & Advocates at Hyderabad. He has varied experience in taxation, finance, operations and management.</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
	              
					                 <div class="collapse" id="member-14">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="151" height="145" src="team/350_1688733144.jpg" class="attachment-medium size-medium wp-post-image" alt="vimala" srcset="team/350_1688733144.jpg 150w" sizes="(max-width: 151px) 100vw, 151px" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>Mr. Adabala Seshagiri Rao, <br/>Independent Director</span></div>
                                    <div class="member-description">
                                        <p>Mr. Adabala Seshagiri Rao, aged 62 years, holds a Degree of Bachelor of Science and Degree of Bachelor of Law from Andhra University. He holds a diploma in Industrial Relations & Personnel Management and Diploma in Marketing & Sales Management from Bharatiya Vidya Bhavan. He is a Certified Associate of Indian Institute of Bankers (CAIIB Retail Banking examination) from the Institute of Banking & Finance.</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
	                    <!-- wpv-loop-start --

                    <div class="collapse" id="member-454">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="151" height="145" src="wp-content/uploads/2015/10/vimala.png" class="attachment-medium size-medium wp-post-image" alt="vimala" srcset="wp-content/uploads/2015/10/vimala.png 151w, wp-content/uploads/2015/10/vimala-150x145.png 150w" sizes="(max-width: 151px) 100vw, 151px" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>Mrs. Vimala B. Madon</span></div>
                                    <div class="member-description">
                                        <p>As an Independent Director of the company, Mrs. Vimala B. Madon has been a power to reckon with. Her qualifications backed with 40 years of work experience in the banking sector are impeccable. She retired as a General Manager (technology) at SBH, and later worked at the State Bank of Travancore, where she handled the portfolio of MIS and Business Process Reengineering at the bank&#8217;s head offices in Hyderabad and Thiruvananthapuram. She retired in 2008.</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="collapse" id="member-452">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="152" height="149" src="wp-content/uploads/2015/10/blank.png" class="attachment-medium size-medium wp-post-image" alt="blank" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>Kashinath Revapa Dholle</span></div>
                                    <div class="member-description">
                                        <p>Kashinath Revapa Dholle, an Independent Director of the company, holds a Masters degree in Science (Chemistry). He started his career as a chemist in reputed MNC’s for 10 years where he gained extensive knowledge in manufacturing medicines. He later moved on to being an entrepreneur. At present, he is the Managing Director of Kross International Private Limited Solapur.</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="collapse" id="member-450">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="152" height="149" src="wp-content/uploads/2015/10/blank.png" class="attachment-medium size-medium wp-post-image" alt="blank" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>Chavali Satyanarayana Murthy</span></div>
                                    <div class="member-description">
                                        <p>Mr. Murthy commenced his career with ICICI ventures. Then he moved on to being a Management Consultant, a Successful Entrepreneur and a Professional Executive. Currently, he is the CEO of Aurigene Discovery Technologies Ltd. </p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="collapse" id="member-447">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="151" height="147" src="wp-content/uploads/2015/10/amerender_reddy.jpg" class="attachment-medium size-medium wp-post-image" alt="amerender_reddy" srcset="wp-content/uploads/2015/10/amerender_reddy.jpg 151w, wp-content/uploads/2015/10/amerender_reddy-150x147.jpg 150w" sizes="(max-width: 151px) 100vw, 151px" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>Amarender Reddy Munipuri</span></div>
                                    <div class="member-description">
                                        <p>He is a graduate by qualification, and is an Independent Director of the firm. He possesses immense knowledge in the Banking sector. He started his career as a Branch Manager in State bank of Hyderabad and proceeded to be the Chief Manager, Asst. General Manager and Dy. General Manager of the same. He also worked with State bank of Mysore as Dy. GeneralManager.</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="collapse" id="member-444">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="151" height="147" src="wp-content/uploads/2015/10/naveen-chandra.png" class="attachment-medium size-medium wp-post-image" alt="naveen-chandra" srcset="wp-content/uploads/2015/10/naveen-chandra.png 151w, wp-content/uploads/2015/10/naveen-chandra-150x147.png 150w" sizes="(max-width: 151px) 100vw, 151px" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>T. Naveen Chandra</span></div>
                                    <div class="member-description">
                                        <p>He holds a Bachelor’s degree in Commerce and is a Fellow Member of the Institute of CharteredAccountants of India. He has over 30 years of rich and varied experience in the fields of Finance,Taxation, Projects, and Capital Markets.</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="collapse" id="member-441">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="151" height="145" src="wp-content/uploads/2015/10/srinivas_reddy.png" class="attachment-medium size-medium wp-post-image" alt="srinivas_reddy" srcset="wp-content/uploads/2015/10/srinivas_reddy.png 151w, wp-content/uploads/2015/10/srinivas_reddy-150x145.png 150w" sizes="(max-width: 151px) 100vw, 151px" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>Mr. A. Srinivas Reddy</span></div>
                                    <div class="member-description">
                                        <p>Mr. A. Srinivas Reddy commenced his career in one of largest management consulting firms in USA, Capgemini as a management consultant, and worked in several capacities in different countries. He has worked as a project manager on multiple projects at Fortune 100 US companies including Sprint, Goodyear, Agilent Technologies Cummins Inc, etc. Currently, he is responsible for essential projects at the firm.</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="collapse" id="member-438">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="151" height="145" src="wp-content/uploads/2015/10/hemanth_reddy.png" class="attachment-medium size-medium wp-post-image" alt="hemanth_reddy" srcset="wp-content/uploads/2015/10/hemanth_reddy.png 151w, wp-content/uploads/2015/10/hemanth_reddy-150x145.png 150w" sizes="(max-width: 151px) 100vw, 151px" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>Mr. G. Hemanth Reddy</span></div>
                                    <div class="member-description">
                                        <p>Mr. G. Hemanth Reddy, a Post graduate in management with Finance and Marketing as his specialization, has more than 25 years of experience in the business sector. He has been influential in implementing various projects globally such as water supply projects, solar projects, rural electrification and global sourcing of material in Africa to name a few. His primary responsibilities are to manage operations, finance and administration of Unit-II of the company.</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="collapse" id="member-436">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="151" height="145" src="wp-content/uploads/2015/10/d_ram_reddy.png" class="attachment-medium size-medium wp-post-image" alt="d_ram_reddy" srcset="wp-content/uploads/2015/10/d_ram_reddy.png 151w, wp-content/uploads/2015/10/d_ram_reddy-150x145.png 150w" sizes="(max-width: 151px) 100vw, 151px" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>Mr. D. Ram Reddy</span></div>
                                    <div class="member-description">
                                        <p>With Mr. D. Ram’s three decades of experience in the management sector and his contribution to the rise of Balaji Amines is incomparable. Since 1988, he is hugely responsible for the procurement, marketing and logistics activities of the company. He has taken on a central part in setting up customer and supplier relationships with leading buyers and providers of specialty chemicals, both in the state and also overseas. He has been instrumental in achieving the first of its kind large scale supply contract arrangement with the world’s leading company in specialty chemicals.</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="collapse" id="member-434">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="152" height="145" src="wp-content/uploads/2015/10/rajeshwar_reddy.png" class="attachment-medium size-medium wp-post-image" alt="rajeshwar_reddy" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>Mr. N. Rajeshwar Reddy</span></div>
                                    <div class="member-description">
                                        <p>Mr. N. Rajeshwar Reddy, our Joint M.D joined the BAL director’s team in the year 1988. He was initially appointed as an Executive Director in Balaji Cement Pvt Ltd. for the implementation of a project, which he successfully completed. His main responsibilities are to oversee the routine operations of the plant in Solapur. With his 30 years of expertise, his marvellous skills have made it possible to execute the projects at a lower cost within the specified time.</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="collapse" id="member-426">
                        <div class="col-sm-12 management-content-wrapper">
                            <div class="row">
                                <div class="col-md-2"><img width="151" height="144" src="wp-content/uploads/2015/10/prathap_reddy.png" class="attachment-medium size-medium wp-post-image" alt="prathap_reddy" srcset="wp-content/uploads/2015/10/prathap_reddy.png 151w, wp-content/uploads/2015/10/prathap_reddy-150x144.png 150w" sizes="(max-width: 151px) 100vw, 151px" /></div>
                                <div class="col-md-10">
                                    <div class="highlight"><span>Mr. A. Prathap Reddy</span></div>
                                    <div class="member-description">
                                        <p>Mr. A. Prathap Reddy, a civil engineer by qualification, started Balaji Amines Ltd (BAL) in the year 1988 for the manufacture of Methyl Amines and Ethyl Amines. His impeccable entrepreneurial skills, endurance and passion has brought glory to the firm, making BAL one of the leading manufacturers and exporters of specialty chemicals, aliphatic amines and derivatives in the chemical industry. For his remarkable contribution in this field, he has received an award in World Class Manufacturing and Operational Excellence for the year 2011 as well as in the Manufacturing Leadership Awards &#038; Conclave 2012 instituted by the Industry 2.0 magazine.</p>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    -- wpv-loop-end -->

                </div>
            </div>
        </div>
         <footer class="full-bg " id="footer">

            <div class="container">
                <div class="row">

                    <div class="col-sm-4  widget-cell" id="footer-widget-1">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">ABOUT</h3>
                            <div class="menu-overview-footer-container">
                                <ul id="menu-overview-footer" class="menu">
                                    <li id="menu-item-412" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-412"><a href="company-profile.php">Company Profile</a></li>
                                    <li id="menu-item-415" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-415"><a href="mission-values.php">Mission &#038; Values</a></li>
                                    <li id="menu-item-414" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-414"><a href="certificate-awards.php">Certificate &#038; Awards</a></li>
                                    <li id="menu-item-413" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-413"><a href="balaji-management-team.php">Management Team</a></li>
                                    <li id="menu-item-479" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-479"><a href="balaji-amines-history.php">History</a></li>
                                    <li id="menu-item-709" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-709"><a href="bal-presence.php">BAL&#8217;s Presence</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4  widget-cell">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">PRODUCTS</h3>
                            <div class="menu-overview-footer-1-container">
                                <ul id="menu-overview-footer-1" class="menu">
                                    <li id="menu-item-417" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-417"><a href="amines.php">Amines</a></li>
                                    <li id="menu-item-416" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-416"><a href="derivatives.php">Derivatives</a></li>
                                    <li id="menu-item-418" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-418"><a href="speciality-chemicals.php">Speciality Chemicals</a></li>
                                    <li id="menu-item-679" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-679"><a href="excipients.php">Pharma Excipients</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4  widget-cell">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">OTHERS</h3>
                            <div class="menu-footer3-container">
                                <ul id="menu-footer3" class="menu">
                                    <li id="menu-item-655" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-655"><a href="investor-relations.php">Investor Relations</a></li>
                                    <li id="menu-item-420" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-286 current_page_item menu-item-420 active"><a href="careers.php">Careers</a></li>
                                    <li id="menu-item-421" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-421"><a href="corporate-social-responsibility.php">Corporate Social Responsibility</a></li>
                                    <li id="menu-item-713" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-713"><a href="e-brochures.php">E-Brochure</a></li>
                                    <li id="menu-item-423" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-423"><a href="balaji-media.php">Media</a></li>
                                    <li id="menu-item-422" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-422"><a href="contact-us.php">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-1  widget-cell col-sm-offset-1">
                        <div class="widget widget_text">
                            <div class="textwidget"></div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="row">
                            <div class="col-sm-12" id="social-media-icons"></div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 col-sm-offset-6"></div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
		<div class="container-fluid">
            <div class="ddl-full-width-row row">
                <div class="col-sm-12 copyright-footer">
                    <p>copyright © balaji Amines 2025 Developed By <a href="http://katareinfo.com/">Katrare Informatics</a></p>
                </div>
            </div>
        </div>    </div>
    <!--</div>-->
    <!-- .container & canvas-->

    <script type="text/html" id="tmpl-wp-playlist-current-item">
        <# if ( data.image ) { #>
            <img src="{{ data.thumb.src }}" alt="" />
            <# } #>
                <div class="wp-playlist-caption">
                    <span class="wp-playlist-item-meta wp-playlist-item-title">&#8220;{{ data.title }}&#8221;</span>
                    <# if ( data.meta.album ) { #><span class="wp-playlist-item-meta wp-playlist-item-album">{{ data.meta.album }}</span>
                        <# } #>
                            <# if ( data.meta.artist ) { #><span class="wp-playlist-item-meta wp-playlist-item-artist">{{ data.meta.artist }}</span>
                                <# } #>
                </div>
    </script>
    <script type="text/html" id="tmpl-wp-playlist-item">
        <div class="wp-playlist-item">
            <a class="wp-playlist-caption" href="{{ data.src }}">
			{{ data.index ? ( data.index + '. ' ) : '' }}
			<# if ( data.caption ) { #>
				{{ data.caption }}
			<# } else { #>
				<span class="wp-playlist-item-title">&#8220;{{{ data.title }}}&#8221;</span>
				<# if ( data.artists && data.meta.artist ) { #>
				<span class="wp-playlist-item-artist"> &mdash; {{ data.meta.artist }}</span>
				<# } #>
			<# } #>
		</a>
            <# if ( data.meta.length_formatted ) { #>
                <div class="wp-playlist-item-length">{{ data.meta.length_formatted }}</div>
                <# } #>
        </div>
    </script>
    <script type='text/javascript' src='wp-content/themes/toolset-bootstrap/bootstrap3/js/bootstrap.min.js?ver=3.3.4'></script>
    <script type='text/javascript' src='wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='wp-includes/js/jquery/ui/datepicker.min.js?ver=1.11.4'></script>
    <script type='text/javascript'>
        jQuery(document).ready(function(jQuery) {
            jQuery.datepicker.setDefaults({
                "closeText": "Close",
                "currentText": "Today",
                "monthNames": ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                "monthNamesShort": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                "nextText": "Next",
                "prevText": "Previous",
                "dayNames": ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                "dayNamesShort": ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                "dayNamesMin": ["S", "M", "T", "W", "T", "F", "S"],
                "dateFormat": "MM d, yy",
                "firstDay": 1,
                "isRTL": false
            });
        });
    </script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var mejsL10n = {
            "language": "en-US",
            "strings": {
                "Close": "Close",
                "Fullscreen": "Fullscreen",
                "Turn off Fullscreen": "Turn off Fullscreen",
                "Go Fullscreen": "Go Fullscreen",
                "Download File": "Download File",
                "Download Video": "Download Video",
                "Play": "Play",
                "Pause": "Pause",
                "Captions\/Subtitles": "Captions\/Subtitles",
                "None": "None",
                "Time Slider": "Time Slider",
                "Skip back %1 seconds": "Skip back %1 seconds",
                "Video Player": "Video Player",
                "Audio Player": "Audio Player",
                "Volume Slider": "Volume Slider",
                "Mute Toggle": "Mute Toggle",
                "Unmute": "Unmute",
                "Mute": "Mute",
                "Use Up\/Down Arrow keys to increase or decrease volume.": "Use Up\/Down Arrow keys to increase or decrease volume.",
                "Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.": "Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds."
            }
        };
        var _wpmejsSettings = {
            "pluginPath": "\/wp-includes\/js\/mediaelement\/"
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='wp-includes/js/mediaelement/mediaelement-and-player.min.js?ver=2.22.0'></script>
    <script type='text/javascript' src='wp-includes/js/mediaelement/wp-mediaelement.min.js?ver=4.7.3'></script>
    <script type='text/javascript' src='wp-includes/js/underscore.min.js?ver=1.8.3'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var _wpUtilSettings = {
            "ajax": {
                "url": "\/wp-admin\/admin-ajax.php"
            }
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='wp-includes/js/wp-util.min.js?ver=4.7.3'></script>
    <script type='text/javascript' src='wp-includes/js/backbone.min.js?ver=1.2.3'></script>
    <script type='text/javascript' src='wp-includes/js/mediaelement/wp-playlist.min.js?ver=4.7.3'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var wpv_pagination_local = {
            "front_ajaxurl": "http:\/\/www.balajiamines.in\/wp-admin\/admin-ajax.php",
            "ajax_pagination_url": "http:\/\/www.balajiamines.in\/wpv-ajax-pagination\/",
            "calendar_image": "http:\/\/www.balajiamines.in\/wp-content\/plugins\/wp-views\/embedded\/res\/img\/calendar.gif",
            "calendar_text": "Select date",
            "datepicker_min_date": null,
            "datepicker_max_date": null
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='wp-content/plugins/wp-views/embedded/res/js/wpv-pagination-embedded.js?ver=1.10'></script>
    <script type='text/javascript' src='wp-includes/js/wp-embed.min.js?ver=4.7.3'></script>

    <script>
        jQuery(window).scroll(function() {
            if (jQuery(document).scrollTop() > 50) {
                jQuery('header').addClass('shrink');
            } else {
                jQuery('header').removeClass('shrink');
            }
        });

        /*Youtube video*/

        jQuery('.js-lazyYT').lazyYT();

        /** Stop playing youtube video when page scrolls */

        jQuery(document).on('scroll', function() {
            var scrollTop = jQuery(window).scrollTop();
            if (scrollTop > pos.top + 315) {
                player.stopVideo();
            }
        })
    </script>

    <script>
        /* moving object */
        jQuery('.marquee').marquee({
            //speed in milliseconds of the marquee
            duration: 6000,
            //gap in pixels between the tickers
            gap: 1500,
            //time in milliseconds before the marquee will start animating
            delayBeforeStart: 0,
            //'left' or 'right'
            direction: 'right',
            //true or false - should the marquee be duplicated to show an effect of continues flow
            duplicated: true
        });
    </script>

    <script>
        jQuery(document).ready(function() {

            /* Apply fancybox to multiple items */

            jQuery("a.balaji-products").fancybox({
                'transitionIn': 'elastic',
                'transitionOut': 'elastic',
                'speedIn': 600,
                'speedOut': 200,
                'overlayShow': false
            });

            jQuery('.member-mug-shot').on('click', function() {
                jQuery('.collapse').collapse('hide');
            })

        });
    </script>

    <script>
        (function(jQuery) {
            jQuery(document).ready(function() {
                jQuery(".video-button").click(function() {
                    jQuery(".video-embed").css({
                        "opacity": "1",
                        "display": "block"
                    });
                    jQuery(".video-embed")[0].src += "&autoplay=1";
                    jQuery(this).unbind("click");
                });
            });
        })(jQuery)
    </script>

    <!--<script>
        jQuery(document).ready(function() {
            jQuery.fancybox("a#single_image-popup");
        });
    </script>-->

    <script>
        jQuery(document).ready(function() {

            jQuery('.fancybox').fancybox({
                beforeShow: function() {
                    this.title = jQuery(this.element).data("caption");
                }
            });

            jQuery("a#single_image-popup").fancybox();

        });
    </script>
    <script>
        jQuery(window).load(function() {
            jQuery('#single_image-popup').fancybox({
                beforeLoad: function() {
                    this.title = jQuery(this.element).find('img').attr('alt');
                }

            });

            jQuery('#single_image-popup').fancybox({
                'titleFromAlt': true,
                'titlePosition': 'inside'

            });

            jQuery("a#single_image-popup").trigger('click');
        });
    </script>
    <script>
        function myFunction() {
            window.print();
        }
    </script>
</body>
</html>