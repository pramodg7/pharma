<!DOCTYPE html>
<html lang="en-US" class="no-js">
<head>
    <meta charset="UTF-8" />
		<meta name="author" content="Balaji Amines" />
	<meta name="keywords" content=" balaji , balaji amines, balaji amines solapur, Chemical Manufacturers in India, Chemical Manufacturers India, Industrial Chemicals Manufacturers, Industrial Chemicals Manufacturers in India Chemical manufacturing company in india, Chemical manufacturing company in Solapur, Chemical manufacturing company, methyl, Chemical Manufacturer,hydrochloride derivatives, industrial chemicals manufacturers, industrial chemicals suppliers, industrial chemicals india, industrial chemicals exporters, industrial chemicals manufacturer, industrial chemicals supplier, industrial chemicals exporter, industrial chemicals from india, industrial chemicals wholesale, industrial chemicals in india">
	<meta name="description"  content="Manufacturer of methyl and ethyl amines and their amide and hydrochloride derivatives, located in India.  Chemical manufacturing company in india">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Balaji &ndash; BAL&#8217;s Presence</title>
    <script type="text/javascript">
        window._wpemojiSettings = {
            "baseUrl": "https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/72x72\/",
            "ext": ".png",
            "svgUrl": "https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/svg\/",
            "svgExt": ".svg",
            "source": {
                "concatemoji": "http:\/\/www.balajiamines.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.7.4"
            }
        };
        ! function(a, b, c) {
            function d(a) {
                var b, c, d, e, f = String.fromCharCode;
                if (!k || !k.fillText) return !1;
                switch (k.clearRect(0, 0, j.width, j.height), k.textBaseline = "top", k.font = "600 32px Arial", a) {
                    case "flag":
                        return k.fillText(f(55356, 56826, 55356, 56819), 0, 0), !(j.toDataURL().length < 3e3) && (k.clearRect(0, 0, j.width, j.height), k.fillText(f(55356, 57331, 65039, 8205, 55356, 57096), 0, 0), b = j.toDataURL(), k.clearRect(0, 0, j.width, j.height), k.fillText(f(55356, 57331, 55356, 57096), 0, 0), c = j.toDataURL(), b !== c);
                    case "emoji4":
                        return k.fillText(f(55357, 56425, 55356, 57341, 8205, 55357, 56507), 0, 0), d = j.toDataURL(), k.clearRect(0, 0, j.width, j.height), k.fillText(f(55357, 56425, 55356, 57341, 55357, 56507), 0, 0), e = j.toDataURL(), d !== e
                }
                return !1
            }
            function e(a) {
                var c = b.createElement("script");
                c.src = a, c.defer = c.type = "text/javascript", b.getElementsByTagName("head")[0].appendChild(c)
            }
            var f, g, h, i, j = b.createElement("canvas"),
                k = j.getContext && j.getContext("2d");
            for (i = Array("flag", "emoji4"), c.supports = {
                    everything: !0,
                    everythingExceptFlag: !0
                }, h = 0; h < i.length; h++) c.supports[i[h]] = d(i[h]), c.supports.everything = c.supports.everything && c.supports[i[h]], "flag" !== i[h] && (c.supports.everythingExceptFlag = c.supports.everythingExceptFlag && c.supports[i[h]]);
            c.supports.everythingExceptFlag = c.supports.everythingExceptFlag && !c.supports.flag, c.DOMReady = !1, c.readyCallback = function() {
                c.DOMReady = !0
            }, c.supports.everything || (g = function() {
                c.readyCallback()
            }, b.addEventListener ? (b.addEventListener("DOMContentLoaded", g, !1), a.addEventListener("load", g, !1)) : (a.attachEvent("onload", g), b.attachEvent("onreadystatechange", function() {
                "complete" === b.readyState && c.readyCallback()
            })), f = c.source || {}, f.concatemoji ? e(f.concatemoji) : f.wpemoji && f.twemoji && (e(f.twemoji), e(f.wpemoji)))
        }(window, document, window._wpemojiSettings);
    </script>
    <style type="text/css">
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 .07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
    <link rel='stylesheet' id='formidable-css' href='wp-content/uploads/formidable/css/formidablepro.css?ver=2.03.07' type='text/css' media='all' />
    <link rel='stylesheet' id='wp_ddl_layout_fe_css-css' href='wp-content/uploads/ddl-layouts-tmp/d41d8cd98f00b204e9800998ecf8427e.css?ver=1.3.2' type='text/css' media='screen' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3/css/bootstrap.min.css?ver=3.3.4' type='text/css' media='all' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_theme_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3/css/bootstrap-theme.min.css' type='text/css' media='all' />
    <link rel='stylesheet' id='toolset-bootstrap-theme-style-css' href='wp-content/themes/toolset-bootstrap/style.css?ver=1.8' type='text/css' media='all' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_adjustment_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3_adjustment.css' type='text/css' media='all' />
    <link rel='stylesheet' id='menu-cells-front-end-css' href='wp-content/plugins/layouts/resources/css/cell-menu-css.css?ver=4.7.4' type='text/css' media='screen' />
    <link rel='stylesheet' id='ddl-front-end-css' href='wp-content/plugins/layouts/resources/css/ddl-front-end.css?ver=4.7.4' type='text/css' media='screen' />
    <link rel='stylesheet' id='toolset-common-css' href='wp-content/plugins/layouts/toolset/toolset-common/res/css/toolset-common.css?ver=4.7.4' type='text/css' media='screen' />
    <link rel='stylesheet' id='wptoolset-field-datepicker-css' href='wp-content/plugins/wp-views/embedded/common/toolset-forms/css/wpt-jquery-ui/datepicker.css?ver=1.10' type='text/css' media='all' />
    <link rel='stylesheet' id='mediaelement-css' href='wp-includes/js/mediaelement/mediaelementplayer.min.css?ver=2.22.0' type='text/css' media='all' />
    <link rel='stylesheet' id='wp-mediaelement-css' href='wp-includes/js/mediaelement/wp-mediaelement.min.css?ver=4.7.4' type='text/css' media='all' />
    <link rel='stylesheet' id='views-pagination-style-css' href='wp-content/plugins/wp-views/embedded/res/css/wpv-pagination.css?ver=1.10' type='text/css' media='all' />
    <script type='text/javascript' src='wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
    <script type='text/javascript' src='wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var DDLayout_fe_settings = {
            "DDL_JS": {
                "css_framework": "bootstrap-3",
                "DEBUG": false
            }
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='wp-content/plugins/layouts/resources/js/ddl-layouts-frontend.js?ver=1.3.2'></script>
 <style type="text/css">
        .recentcomments a {
            display: inline !important;
            padding: 0 !important;
            margin: 0 !important;
        }
    </style>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/owl.carousel.css">
    <!-- Default Theme -->
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/owl.theme.css">
    <!-- Include js plugin -->
    <script src="wp-content/themes/toolset-bootstrap/js/owl.carousel.js"></script>
    <!--Fancy box -->
    <script type="text/javascript" src="wp-content/themes/toolset-bootstrap/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/fancybox/jquery.fancybox-1.3.4.css" type="text/css" media="screen" />
    <!--Fancy box ends-->

    <link href='https://fonts.googleapis.com/css?family=Khand:400,300,500,600,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,100italic,100,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link rel='stylesheet' href="wp-content/themes/toolset-bootstrap/css/mediatree.css">
    <link rel='stylesheet' media="print" href="wp-content/themes/toolset-bootstrap/css/custom-print.css">

    <link rel='stylesheet' href="wp-content/themes/toolset-bootstrap/css/zara.css">
    <link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>
    <link href="wp-content/themes/toolset-bootstrap/css/jasny-bootstrap.min.css" rel="stylesheet" media="screen">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.matchHeight.js"></script>

    <script src="wp-content/themes/toolset-bootstrap/js/jasny-bootstrap.min.js"></script>

    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/flexslider.css" type="text/css">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.flexslider.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.matchHeight-min.js" type="text/javascript"></script>
    <script type="text/javascript" src="wp-content/themes/toolset-bootstrap/lazyyt/lazyYT.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/lazyyt/lazyYT.css">
    <script type='text/javascript' src='//cdn.jsdelivr.net/jquery.marquee/1.3.1/jquery.marquee.min.js'></script>

</head>

<body class="page-template page-template-page-layouts page-template-page-layouts-php page page-id-705">
    <!-- Off Canvas Menu Starts -->
    <div class="navmenu navmenu-default navmenu-fixed-right">
        <ul id="menu-menu-1" class="nav navmenu-nav">
            <li id="menu-item-20" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-2 current_page_item menu-item-20 active"><a href="index.php">Homepage</a></li>
            <li id="menu-item-656" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-656"><a href="#">About us</a>
                <ul class="sub-menu">
                    <li id="menu-item-267" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-267"><a href="company-profile.php">Company Profile</a></li>
                    <li id="menu-item-261" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-261"><a href="mission-values.php">Mission &#038; Values</a></li>
                    <li id="menu-item-280" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-280"><a href="certificate-awards.php">Certificate &#038; Awards</a></li>
                    <li id="menu-item-348" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-348"><a href="balaji-management-team.php">Management Team</a></li>
                    <li id="menu-item-339" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-339"><a href="balaji-amines-history.php">History</a></li>
                    <li id="menu-item-710" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-710"><a href="bal-presence.php">BAL&#8217;s Presence</a></li>
                </ul>
            </li>
            <li id="menu-item-400" class="menu-item menu-item-type-post_type_archive menu-item-object-product menu-item-has-children menu-item-400"><a href="category.php">Products</a>
                <ul class="sub-menu">
                    <li id="menu-item-658" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-658"><a href="amines.php">Amines</a></li>
                    <li id="menu-item-657" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-657"><a href="derivatives.php">Derivatives</a></li>
                    <li id="menu-item-659" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-659"><a href="speciality-chemicals.php">Speciality Chemicals</a></li>
                    <li id="menu-item-678" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-678"><a href="excipients.php">Pharma Excipients</a></li>
                </ul>
            </li>
            <li id="menu-item-534" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-534"><a href="investor-relations.php">Investor Relations</a></li>
            <li id="menu-item-290" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-290"><a href="careers.php">Careers</a></li>
            <li id="menu-item-299" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-299"><a href="corporate-social-responsibility.php">Corporate Social Responsibility</a></li>
            <li id="menu-item-282" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-282"><a href="contact-us.php">Contact Us</a></li>
            <li id="menu-item-307" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-307"><a href="balaji-media.php">Media</a></li>
            <li id="menu-item-711" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-711"><a href="e-brochures.php">E-Brochure</a></li>
        </ul>
    </div>    <!-- Off Canvas Menu Ends -->
    <div class="canvas">
        <!--<div class="container">-->
        <header class="full-bg black-bg" id="homepage-header">
            <div class="container">
                <div class="row">
                    <div class="col-sm-1" id="off-canvas-button">
                        <div class="navbar navbar-default">
                            <button type="button" class="navbar-toggle" data-toggle="offcanvas" data-recalc="false" data-target=".navmenu" data-canvas=".canvas">
                                <br />
                                <span class="icon-bar"></span>
                                <br />
                                <span class="icon-bar"></span>
                                <br />
                                <span class="icon-bar"></span>
                                <br />
                            </button>
                        </div>
                    </div>
                    <div class="col-sm-4 col-sm-offset-3" id="homepage-logo">
                      
                            <a href=""><img src="wp-content/uploads/2015/10/balaji_logo.png" alt="Balaji Almines" class="aligncenter size-full img-responsive"></a>
                        </p>
                    </div>
                </div>
            </div>
        </header>
        <div class="full-bg full-white-section">

            <div class="container">
                <div class="row">

                    <div class="col-sm-12">
                        <div class="presence-map-wrapper">

                            <style>
                                .wpgmza_map img {
                                    max-width: none;
                                }
                                
                                .wpgmza_widget {
                                    overflow: auto;
                                }
                            </style>

                            <a name='marker26'></a>
                            <a name='marker25'></a>
                            <a name='marker24'></a>
                            <a name='marker23'></a>
                            <a name='marker22'></a>
                            <a name='marker21'></a>
                            <a name='marker20'></a>
                            <a name='marker19'></a>
                            <a name='marker18'></a>
                            <a name='marker17'></a>
                            <a name='marker16'></a>
                            <a name='marker15'></a>
                            <a name='marker14'></a>
                            <a name='marker13'></a>
                            <a name='marker12'></a>
                            <a name='marker11'></a>
                            <a name='marker10'></a>
                            <a name='marker9'></a>
                            <a name='marker8'></a>
                            <a name='marker7'></a>
                            <a name='marker6'></a>
                            <a name='marker5'></a>
                            <a name='marker4'></a>

                            <div class="wpgmza_map" id="wpgmza_map_2" style="display:block; overflow:auto; width:100%; height:550px; margin-left:auto !important; margin-right:auto !important; align:center;"> </div>

                            <div id="wpgmza_marker_list_2" class="wpgmza_marker_list_class wpgmza_basic_list" style='width:100%'>
                                <div id="wpgmza_marker_26" mid="26" mapid="2" class="wpgmaps_blist_row">
                                    <div class='wpgmza-basic-list-item wpgmza_div_marker' style='max-width: 14px; max-height: 14px;'><img src="wp-content/plugins/wp-google-maps//images/marker.png" style="" class="wpgmza_small_img" /></div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_title'> BRAZIL</div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_address'> (Brazil)</div>
                                </div>
                                <div id="wpgmza_marker_25" mid="25" mapid="2" class="wpgmaps_blist_row">
                                    <div class='wpgmza-basic-list-item wpgmza_div_marker' style='max-width: 14px; max-height: 14px;'><img src="wp-content/plugins/wp-google-maps//images/marker.png" style="" class="wpgmza_small_img" /></div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_title'> MEXICO</div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_address'> (Mexico)</div>
                                </div>
                                <div id="wpgmza_marker_24" mid="24" mapid="2" class="wpgmaps_blist_row">
                                    <div class='wpgmza-basic-list-item wpgmza_div_marker' style='max-width: 14px; max-height: 14px;'><img src="wp-content/plugins/wp-google-maps//images/marker.png" style="" class="wpgmza_small_img" /></div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_title'> UKRAINE</div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_address'> (Ukraine)</div>
                                </div>
                                <div id="wpgmza_marker_23" mid="23" mapid="2" class="wpgmaps_blist_row">
                                    <div class='wpgmza-basic-list-item wpgmza_div_marker' style='max-width: 14px; max-height: 14px;'><img src="wp-content/plugins/wp-google-maps//images/marker.png" style="" class="wpgmza_small_img" /></div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_title'> POLAND</div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_address'> (Poland)</div>
                                </div>
                                <div id="wpgmza_marker_22" mid="22" mapid="2" class="wpgmaps_blist_row">
                                    <div class='wpgmza-basic-list-item wpgmza_div_marker' style='max-width: 14px; max-height: 14px;'><img src="wp-content/plugins/wp-google-maps//images/marker.png" style="" class="wpgmza_small_img" /></div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_title'> NORWAY</div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_address'> (Norway)</div>
                                </div>
                                <div id="wpgmza_marker_21" mid="21" mapid="2" class="wpgmaps_blist_row">
                                    <div class='wpgmza-basic-list-item wpgmza_div_marker' style='max-width: 14px; max-height: 14px;'><img src="wp-content/plugins/wp-google-maps//images/marker.png" style="" class="wpgmza_small_img" /></div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_title'> BELGIUM</div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_address'> (Belgium)</div>
                                </div>
                                <div id="wpgmza_marker_20" mid="20" mapid="2" class="wpgmaps_blist_row">
                                    <div class='wpgmza-basic-list-item wpgmza_div_marker' style='max-width: 14px; max-height: 14px;'><img src="wp-content/plugins/wp-google-maps//images/marker.png" style="" class="wpgmza_small_img" /></div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_title'> THE NETHERLANDS</div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_address'> (Netherlands)</div>
                                </div>
                                <div id="wpgmza_marker_19" mid="19" mapid="2" class="wpgmaps_blist_row">
                                    <div class='wpgmza-basic-list-item wpgmza_div_marker' style='max-width: 14px; max-height: 14px;'><img src="wp-content/plugins/wp-google-maps//images/marker.png" style="" class="wpgmza_small_img" /></div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_title'> FRANCE</div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_address'> (France)</div>
                                </div>
                                <div id="wpgmza_marker_18" mid="18" mapid="2" class="wpgmaps_blist_row">
                                    <div class='wpgmza-basic-list-item wpgmza_div_marker' style='max-width: 14px; max-height: 14px;'><img src="wp-content/plugins/wp-google-maps//images/marker.png" style="" class="wpgmza_small_img" /></div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_title'> SPAIN</div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_address'> (Spain)</div>
                                </div>
                                <div id="wpgmza_marker_17" mid="17" mapid="2" class="wpgmaps_blist_row">
                                    <div class='wpgmza-basic-list-item wpgmza_div_marker' style='max-width: 14px; max-height: 14px;'><img src="wp-content/plugins/wp-google-maps//images/marker.png" style="" class="wpgmza_small_img" /></div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_title'> TAIWAN</div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_address'> (Taiwan)</div>
                                </div>
                                <div id="wpgmza_marker_16" mid="16" mapid="2" class="wpgmaps_blist_row">
                                    <div class='wpgmza-basic-list-item wpgmza_div_marker' style='max-width: 14px; max-height: 14px;'><img src="wp-content/plugins/wp-google-maps//images/marker.png" style="" class="wpgmza_small_img" /></div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_title'> KOREA</div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_address'> (Korea)</div>
                                </div>
                                <div id="wpgmza_marker_15" mid="15" mapid="2" class="wpgmaps_blist_row">
                                    <div class='wpgmza-basic-list-item wpgmza_div_marker' style='max-width: 14px; max-height: 14px;'><img src="wp-content/plugins/wp-google-maps//images/marker.png" style="" class="wpgmza_small_img" /></div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_title'> SOUTH AFRICA</div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_address'> (South Africa)</div>
                                </div>
                                <div id="wpgmza_marker_14" mid="14" mapid="2" class="wpgmaps_blist_row">
                                    <div class='wpgmza-basic-list-item wpgmza_div_marker' style='max-width: 14px; max-height: 14px;'><img src="wp-content/plugins/wp-google-maps//images/marker.png" style="" class="wpgmza_small_img" /></div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_title'> EGYPT</div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_address'> (Egypt)</div>
                                </div>
                                <div id="wpgmza_marker_13" mid="13" mapid="2" class="wpgmaps_blist_row">
                                    <div class='wpgmza-basic-list-item wpgmza_div_marker' style='max-width: 14px; max-height: 14px;'><img src="wp-content/plugins/wp-google-maps//images/marker.png" style="" class="wpgmza_small_img" /></div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_title'> ITALY</div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_address'> (Italy)</div>
                                </div>
                                <div id="wpgmza_marker_12" mid="12" mapid="2" class="wpgmaps_blist_row">
                                    <div class='wpgmza-basic-list-item wpgmza_div_marker' style='max-width: 14px; max-height: 14px;'><img src="wp-content/plugins/wp-google-maps//images/marker.png" style="" class="wpgmza_small_img" /></div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_title'> GERMANY</div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_address'> (Germany)</div>
                                </div>
                                <div id="wpgmza_marker_11" mid="11" mapid="2" class="wpgmaps_blist_row">
                                    <div class='wpgmza-basic-list-item wpgmza_div_marker' style='max-width: 14px; max-height: 14px;'><img src="wp-content/plugins/wp-google-maps//images/marker.png" style="" class="wpgmza_small_img" /></div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_title'> OMAN</div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_address'> (Oman)</div>
                                </div>
                                <div id="wpgmza_marker_10" mid="10" mapid="2" class="wpgmaps_blist_row">
                                    <div class='wpgmza-basic-list-item wpgmza_div_marker' style='max-width: 14px; max-height: 14px;'><img src="wp-content/plugins/wp-google-maps//images/marker.png" style="" class="wpgmza_small_img" /></div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_title'> BANGLADESH</div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_address'> (Bangladesh)</div>
                                </div>
                                <div id="wpgmza_marker_9" mid="9" mapid="2" class="wpgmaps_blist_row">
                                    <div class='wpgmza-basic-list-item wpgmza_div_marker' style='max-width: 14px; max-height: 14px;'><img src="wp-content/plugins/wp-google-maps//images/marker.png" style="" class="wpgmza_small_img" /></div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_title'> PAKISTAN</div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_address'> (Pakistan)</div>
                                </div>
                                <div id="wpgmza_marker_8" mid="8" mapid="2" class="wpgmaps_blist_row">
                                    <div class='wpgmza-basic-list-item wpgmza_div_marker' style='max-width: 14px; max-height: 14px;'><img src="wp-content/plugins/wp-google-maps//images/marker.png" style="" class="wpgmza_small_img" /></div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_title'> ISRAEL</div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_address'> (Israel)</div>
                                </div>
                                <div id="wpgmza_marker_7" mid="7" mapid="2" class="wpgmaps_blist_row">
                                    <div class='wpgmza-basic-list-item wpgmza_div_marker' style='max-width: 14px; max-height: 14px;'><img src="wp-content/plugins/wp-google-maps//images/marker.png" style="" class="wpgmza_small_img" /></div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_title'> CANADA</div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_address'> (Canada)</div>
                                </div>
                                <div id="wpgmza_marker_6" mid="6" mapid="2" class="wpgmaps_blist_row">
                                    <div class='wpgmza-basic-list-item wpgmza_div_marker' style='max-width: 14px; max-height: 14px;'><img src="wp-content/plugins/wp-google-maps//images/marker.png" style="" class="wpgmza_small_img" /></div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_title'> LATIN AMERICA</div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_address'> (Latin America)</div>
                                </div>
                                <div id="wpgmza_marker_5" mid="5" mapid="2" class="wpgmaps_blist_row">
                                    <div class='wpgmza-basic-list-item wpgmza_div_marker' style='max-width: 14px; max-height: 14px;'><img src="wp-content/plugins/wp-google-maps//images/marker.png" style="" class="wpgmza_small_img" /></div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_title'> USA</div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_address'> (United States)</div>
                                </div>
                                <div id="wpgmza_marker_4" mid="4" mapid="2" class="wpgmaps_blist_row">
                                    <div class='wpgmza-basic-list-item wpgmza_div_marker' style='max-width: 14px; max-height: 14px;'><img src="wp-content/plugins/wp-google-maps//images/marker.png" style="" class="wpgmza_small_img" /></div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_title'> UK</div>
                                    <div class='wpgmza-basic-list-item wpgmza_div_address'> (United Kingdom)</div>
                                </div>
                            </div>

                            <div style="display:block; width:100%;">

                                <div id="wpgmaps_directions_edit_2" style="display:none; width:500px; clear:both;" class="wpgmaps_directions_outer_div">
                                    <h2>Get Directions</h2>
                                    <div id="wpgmaps_directions_editbox_2">
                                        <table>
                                            <tr>
                                                <td>
                                                    <label for="wpgmza_dir_type_2">For</label>
                                                </td>
                                                <td>
                                                    <select id="wpgmza_dir_type_2" name="wpgmza_dir_type_2">
                                                        <option value="DRIVING" selected="selected">Driving</option>
                                                        <option value="WALKING">Walking</option>
                                                        <option value="BICYCLING">Bicycling</option>
                                                    </select>
                                                    &nbsp;
                                                    <a href="javascript:void(0);" mapid="2" id="wpgmza_show_options_2" onclick="wpgmza_show_options(2);" style="font-size:10px;">show options</a>
                                                    <a href="javascript:void(0);" mapid="2" id="wpgmza_hide_options_2" onclick="wpgmza_hide_options(2);" style="font-size:10px; display:none;">hide options</a>
                                                    <div style="display:none" id="wpgmza_options_box_2">
                                                        <input type="checkbox" id="wpgmza_tolls_2" name="wpgmza_tolls_2" value="tolls" />
                                                        <label for="wpgmza_tolls_2">Avoid Tolls</label>
                                                        <br />
                                                        <input type="checkbox" id="wpgmza_highways_2" name="wpgmza_highways_2" value="highways" />
                                                        <label for="wpgmza_highways_2">Avoid Highways</label>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr class='wpgmaps_from_row'>
                                                <td class='wpgmaps_from_td1'>
                                                    <label for="wpgmza_input_from_2">From</label>
                                                </td>
                                                <td width='90%' class='wpgmaps_from_td2'>
                                                    <input type="text" value="" id="wpgmza_input_from_2" style='width:80%' />
                                                </td>
                                            </tr>
                                            <tr class='wpgmaps_to_row'>
                                                <td class='wpgmaps_to_td1'>
                                                    <label for="wpgmza_input_to_2">To</label>
                                                </td>
                                                <td width='90%' class='wpgmaps_to_td2'>
                                                    <input type="text" value="" id="wpgmza_input_to_2" style='width:80%' />
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                </td>
                                                <td>
                                                    <input onclick="javascript:void(0);" class="wpgmaps_get_directions" id="2" type="button" value="Go" />
                                                </td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>

                                <div id="wpgmaps_directions_notification_2" style="display:none;">Fetching directions......</div>

                                <div id="wpgmaps_directions_reset_2" style="display:none;">
                                    <a href='javascript:void(0)' onclick='wpgmza_reset_directions(2);' id='wpgmaps_reset_directions' title='Reset directions'>Reset directions</a>
                                    <br />
                                    <a href='' id='wpgmaps_print_directions_2' title='Print directions'>Print directions</a>
                                </div>

                                <div id="directions_panel_2"></div>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
 <footer class="full-bg " id="footer">

            <div class="container">
                <div class="row">

                    <div class="col-sm-4  widget-cell" id="footer-widget-1">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">ABOUT</h3>
                            <div class="menu-overview-footer-container">
                                <ul id="menu-overview-footer" class="menu">
                                    <li id="menu-item-412" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-412"><a href="company-profile.php">Company Profile</a></li>
                                    <li id="menu-item-415" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-415"><a href="mission-values.php">Mission &#038; Values</a></li>
                                    <li id="menu-item-414" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-414"><a href="certificate-awards.php">Certificate &#038; Awards</a></li>
                                    <li id="menu-item-413" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-413"><a href="balaji-management-team.php">Management Team</a></li>
                                    <li id="menu-item-479" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-479"><a href="balaji-amines-history.php">History</a></li>
                                    <li id="menu-item-709" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-709"><a href="bal-presence.php">BAL&#8217;s Presence</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4  widget-cell">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">PRODUCTS</h3>
                            <div class="menu-overview-footer-1-container">
                                <ul id="menu-overview-footer-1" class="menu">
                                    <li id="menu-item-417" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-417"><a href="amines.php">Amines</a></li>
                                    <li id="menu-item-416" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-416"><a href="derivatives.php">Derivatives</a></li>
                                    <li id="menu-item-418" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-418"><a href="speciality-chemicals.php">Speciality Chemicals</a></li>
                                    <li id="menu-item-679" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-679"><a href="excipients.php">Pharma Excipients</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4  widget-cell">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">OTHERS</h3>
                            <div class="menu-footer3-container">
                                <ul id="menu-footer3" class="menu">
                                    <li id="menu-item-655" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-655"><a href="investor-relations.php">Investor Relations</a></li>
                                    <li id="menu-item-420" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-286 current_page_item menu-item-420 active"><a href="careers.php">Careers</a></li>
                                    <li id="menu-item-421" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-421"><a href="corporate-social-responsibility.php">Corporate Social Responsibility</a></li>
                                    <li id="menu-item-713" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-713"><a href="e-brochures.php">E-Brochure</a></li>
                                    <li id="menu-item-423" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-423"><a href="balaji-media.php">Media</a></li>
                                    <li id="menu-item-422" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-422"><a href="contact-us.php">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-1  widget-cell col-sm-offset-1">
                        <div class="widget widget_text">
                            <div class="textwidget"></div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="row">
                            <div class="col-sm-12" id="social-media-icons"></div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 col-sm-offset-6"></div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
		<div class="container-fluid">
            <div class="ddl-full-width-row row">
                <div class="col-sm-12 copyright-footer">
                    <p>copyright © balaji Amines 2025 Developed By <a href="http://katareinfo.com/">Katrare Informatics</a></p>
                </div>
            </div>
        </div>    </div>
    <!--</div>-->
    <!-- .container & canvas-->
    <script type="text/html" id="tmpl-wp-playlist-current-item">
        <# if ( data.image ) { #>
            <img src="{{ data.thumb.src }}" alt="" />
            <# } #>
                <div class="wp-playlist-caption">
                    <span class="wp-playlist-item-meta wp-playlist-item-title">&#8220;{{ data.title }}&#8221;</span>
                    <# if ( data.meta.album ) { #><span class="wp-playlist-item-meta wp-playlist-item-album">{{ data.meta.album }}</span>
                        <# } #>
                            <# if ( data.meta.artist ) { #><span class="wp-playlist-item-meta wp-playlist-item-artist">{{ data.meta.artist }}</span>
                                <# } #>
                </div>
    </script>
    <script type="text/html" id="tmpl-wp-playlist-item">
        <div class="wp-playlist-item">
            <a class="wp-playlist-caption" href="{{ data.src }}">
			{{ data.index ? ( data.index + '. ' ) : '' }}
			<# if ( data.caption ) { #>
				{{ data.caption }}
			<# } else { #>
				<span class="wp-playlist-item-title">&#8220;{{{ data.title }}}&#8221;</span>
				<# if ( data.artists && data.meta.artist ) { #>
				<span class="wp-playlist-item-artist"> &mdash; {{ data.meta.artist }}</span>
				<# } #>
			<# } #>
		</a>
            <# if ( data.meta.length_formatted ) { #>
                <div class="wp-playlist-item-length">{{ data.meta.length_formatted }}</div>
                <# } #>
        </div>
    </script>

    <script type="text/javascript">
        var gmapsJsHost = (("https:" == document.location.protocol) ? "https://" : "http://");
        document.write(unescape("%3Cscript src='" + gmapsJsHost + "maps.google.com/maps/api/js?v=3.26&language=en_US&libraries=places,visualization' type='text/javascript'%3E%3C/script%3E"));
    </script>

    <script type="text/javascript">
        wpgmaps_pro_nonce = 'bf8db3172c';
        wpgmaps_map_mashup = new Array();

        wpgmaps_plugurl = 'wp-content/plugins/wp-google-maps/';
        var marker_pull = '0';

        wpgmaps_markerurl = 'wp-content/uploads/wp-google-maps/';
        wpgmaps_lang_more_details = 'More details';
        wpgmaps_lang_get_dir = 'Get directions';
        wpgmaps_lang_my_location = 'My location';
        wpgmaps_lang_km_away = 'km away';
        wpgmaps_lang_m_away = 'miles away';
        wpgmaps_lang_directions = 'Directions';
        wpgmaps_lang_more_info = 'More details';
        wpgmaps_lang_error1 = 'Please fill out both the "from" and "to" fields';
        wpgmaps_lang_getting_location = 'Getting your current location address...';
        var wpgm_g_e = false;
        var wpgm_dt_sLengthMenu = 'Show _MENU_ entries';
        var wpgm_dt_sZeroRecords = 'Nothing found - sorry';
        var wpgm_dt_sInfo = 'Showing _START_ to _END_ of _TOTAL_ records';
        var wpgm_dt_sInfoEmpty = 'Showing 0 to 0 of 0 records';
        var wpgm_dt_sInfoFiltered = '(filtered from _MAX_ total records)';
        var wpgm_dt_sFirst = 'First';
        var wpgm_dt_sLast = 'Last';
        var wpgm_dt_sNext = 'Next';
        var wpgm_dt_sPrevious = 'Previous';
        var wpgm_dt_sSearch = 'Search';
        ajaxurl = 'wp-admin/admin-ajax.php';
    </script>
    <link rel='stylesheet' id='wpgmaps-style-pro-css' href='wp-content/plugins/wp-google-maps-pro/css/wpgmza_style_pro.css?ver=5.73' type='text/css' media='all' />
    <link rel='stylesheet' id='wpgmaps_datatables_style-css' href='wp-content/plugins/wp-google-maps-pro/css/data_table_front.css?ver=5.73' type='text/css' media='all' />
    <link rel='stylesheet' id='wpgmaps_datatables_responsive-style-css' href='//cdn.datatables.net/responsive/1.0.4/css/dataTables.responsive.css?ver=5.73' type='text/css' media='all' />
    <script type='text/javascript' src='wp-content/themes/toolset-bootstrap/bootstrap3/js/bootstrap.min.js?ver=3.3.4'></script>
    <script type='text/javascript' src='wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='wp-includes/js/jquery/ui/datepicker.min.js?ver=1.11.4'></script>
    <script type='text/javascript'>
        jQuery(document).ready(function(jQuery) {
            jQuery.datepicker.setDefaults({
                "closeText": "Close",
                "currentText": "Today",
                "monthNames": ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                "monthNamesShort": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                "nextText": "Next",
                "prevText": "Previous",
                "dayNames": ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                "dayNamesShort": ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                "dayNamesMin": ["S", "M", "T", "W", "T", "F", "S"],
                "dateFormat": "MM d, yy",
                "firstDay": 1,
                "isRTL": false
            });
        });
    </script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var mejsL10n = {
            "language": "en-US",
            "strings": {
                "Close": "Close",
                "Fullscreen": "Fullscreen",
                "Turn off Fullscreen": "Turn off Fullscreen",
                "Go Fullscreen": "Go Fullscreen",
                "Download File": "Download File",
                "Download Video": "Download Video",
                "Play": "Play",
                "Pause": "Pause",
                "Captions\/Subtitles": "Captions\/Subtitles",
                "None": "None",
                "Time Slider": "Time Slider",
                "Skip back %1 seconds": "Skip back %1 seconds",
                "Video Player": "Video Player",
                "Audio Player": "Audio Player",
                "Volume Slider": "Volume Slider",
                "Mute Toggle": "Mute Toggle",
                "Unmute": "Unmute",
                "Mute": "Mute",
                "Use Up\/Down Arrow keys to increase or decrease volume.": "Use Up\/Down Arrow keys to increase or decrease volume.",
                "Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.": "Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds."
            }
        };
        var _wpmejsSettings = {
            "pluginPath": "\/wp-includes\/js\/mediaelement\/"
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='wp-includes/js/mediaelement/mediaelement-and-player.min.js?ver=2.22.0'></script>
    <script type='text/javascript' src='wp-includes/js/mediaelement/wp-mediaelement.min.js?ver=4.7.4'></script>
    <script type='text/javascript' src='wp-includes/js/underscore.min.js?ver=1.8.3'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var _wpUtilSettings = {
            "ajax": {
                "url": "\/wp-admin\/admin-ajax.php"
            }
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='wp-includes/js/wp-util.min.js?ver=4.7.4'></script>
    <script type='text/javascript' src='wp-includes/js/backbone.min.js?ver=1.2.3'></script>
    <script type='text/javascript' src='wp-includes/js/mediaelement/wp-playlist.min.js?ver=4.7.4'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var wpv_pagination_local = {
            "front_ajaxurl": "http:\/\/www.balajiamines.com\/wp-admin\/admin-ajax.php",
            "ajax_pagination_url": "http:\/\/www.balajiamines.com\/wpv-ajax-pagination\/",
            "calendar_image": "http:\/\/www.balajiamines.com\/wp-content\/plugins\/wp-views\/embedded\/res\/img\/calendar.gif",
            "calendar_text": "Select date",
            "datepicker_min_date": null,
            "datepicker_max_date": null
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='wp-content/plugins/wp-views/embedded/res/js/wpv-pagination-embedded.js?ver=1.10'></script>
    <script type='text/javascript' src='wp-includes/js/wp-embed.min.js?ver=4.7.4'></script>
    <script type='text/javascript' src='wp-content/plugins/wp-google-maps-pro/js/jquery.dataTables.min.js?ver=4.7.4'></script>
    <script type='text/javascript' src='wp-content/plugins/wp-google-maps-pro/js/dataTables.responsive.js?ver=4.7.4'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var wpgmaps_localize = {
            "2": {
                "id": "2",
                "map_title": "Map-Presence",
                "map_width": "100",
                "map_height": "550",
                "map_start_lat": "37.415064",
                "map_start_lng": "-4.822660",
                "map_start_location": "37.41506358215238,-4.822660499999989",
                "map_start_zoom": "2",
                "default_marker": "0",
                "type": "1",
                "alignment": "2",
                "directions_enabled": "1",
                "styling_enabled": "0",
                "styling_json": "",
                "active": "0",
                "kml": "",
                "bicycle": "2",
                "traffic": "2",
                "dbox": "1",
                "dbox_width": "500",
                "listmarkers": "0",
                "listmarkers_advanced": "0",
                "filterbycat": "0",
                "ugm_enabled": "0",
                "ugm_category_enabled": "0",
                "fusion": "",
                "map_width_type": "%",
                "map_height_type": "px",
                "mass_marker_support": "0",
                "ugm_access": "0",
                "order_markers_by": "1",
                "order_markers_choice": "2",
                "show_user_location": "2",
                "default_to": "",
                "other_settings": {
                    "store_locator_enabled": 2,
                    "wpgmza_store_locator_restrict": "",
                    "store_locator_distance": 2,
                    "store_locator_bounce": 1,
                    "store_locator_hide_before_search": 2,
                    "store_locator_use_their_location": 2,
                    "store_locator_name_search": 2,
                    "store_locator_category": 2,
                    "store_locator_query_string": "ZIP \/ Address:",
                    "store_locator_name_string": "Title \/ Description:",
                    "wpgmza_dbox_width_type": "px",
                    "map_max_zoom": "1",
                    "sl_stroke_color": "FF0000",
                    "sl_stroke_opacity": "0.25",
                    "sl_fill_color": "FF0000",
                    "sl_fill_opacity": "0.15",
                    "click_open_link": 2,
                    "weather_layer": 2,
                    "weather_layer_temp_type": 1,
                    "cloud_layer": 2,
                    "transport_layer": 2,
                    "wpgmza_iw_type": "",
                    "list_markers_by": "4",
                    "push_in_map": "",
                    "push_in_map_placement": "9",
                    "wpgmza_push_in_map_width": "",
                    "wpgmza_push_in_map_height": ""
                },
                "total_markers": 23
            }
        };
        var wpgmaps_localize_mashup_ids = null;
        var wpgmaps_localize_marker_data = {
            "2": {
                "4": {
                    "map_id": "2",
                    "marker_id": "4",
                    "title": "UK",
                    "address": "United Kingdom",
                    "desc": "",
                    "pic": "",
                    "icon": "",
                    "linkd": "",
                    "lat": "55.378051",
                    "lng": "-3.43597299999999",
                    "anim": "0",
                    "retina": "0",
                    "category": "0",
                    "infoopen": "0",
                    "other_data": ""
                },
                "5": {
                    "map_id": "2",
                    "marker_id": "5",
                    "title": "USA",
                    "address": "United States",
                    "desc": "",
                    "pic": "",
                    "icon": "",
                    "linkd": "",
                    "lat": "37.09024",
                    "lng": "-95.71289100000001",
                    "anim": "0",
                    "retina": "0",
                    "category": "0",
                    "infoopen": "0",
                    "other_data": ""
                },
                "6": {
                    "map_id": "2",
                    "marker_id": "6",
                    "title": "LATIN AMERICA",
                    "address": "Latin America",
                    "desc": "",
                    "pic": "",
                    "icon": "",
                    "linkd": "",
                    "lat": "-8.783195",
                    "lng": "-55.49147700000003",
                    "anim": "0",
                    "retina": "0",
                    "category": "0",
                    "infoopen": "0",
                    "other_data": ""
                },
                "7": {
                    "map_id": "2",
                    "marker_id": "7",
                    "title": "CANADA",
                    "address": "Canada",
                    "desc": "",
                    "pic": "",
                    "icon": "",
                    "linkd": "",
                    "lat": "56.130366",
                    "lng": "-106.34677099999999",
                    "anim": "0",
                    "retina": "0",
                    "category": "0",
                    "infoopen": "0",
                    "other_data": ""
                },
                "8": {
                    "map_id": "2",
                    "marker_id": "8",
                    "title": "ISRAEL",
                    "address": "Israel",
                    "desc": "",
                    "pic": "",
                    "icon": "",
                    "linkd": "",
                    "lat": "31.046051",
                    "lng": "34.85161199999993",
                    "anim": "0",
                    "retina": "0",
                    "category": "0",
                    "infoopen": "0",
                    "other_data": ""
                },
                "9": {
                    "map_id": "2",
                    "marker_id": "9",
                    "title": "PAKISTAN",
                    "address": "Pakistan",
                    "desc": "",
                    "pic": "",
                    "icon": "",
                    "linkd": "",
                    "lat": "30.375321",
                    "lng": "69.34511599999996",
                    "anim": "0",
                    "retina": "0",
                    "category": "0",
                    "infoopen": "0",
                    "other_data": ""
                },
                "10": {
                    "map_id": "2",
                    "marker_id": "10",
                    "title": "BANGLADESH",
                    "address": "Bangladesh",
                    "desc": "",
                    "pic": "",
                    "icon": "",
                    "linkd": "",
                    "lat": "23.684994",
                    "lng": "90.35633099999995",
                    "anim": "0",
                    "retina": "0",
                    "category": "0",
                    "infoopen": "0",
                    "other_data": ""
                },
                "11": {
                    "map_id": "2",
                    "marker_id": "11",
                    "title": "OMAN",
                    "address": "Oman",
                    "desc": "",
                    "pic": "",
                    "icon": "",
                    "linkd": "",
                    "lat": "21.512583",
                    "lng": "55.923254999999926",
                    "anim": "0",
                    "retina": "0",
                    "category": "0",
                    "infoopen": "0",
                    "other_data": ""
                },
                "12": {
                    "map_id": "2",
                    "marker_id": "12",
                    "title": "GERMANY",
                    "address": "Germany",
                    "desc": "",
                    "pic": "",
                    "icon": "",
                    "linkd": "",
                    "lat": "51.165691",
                    "lng": "10.451526000000058",
                    "anim": "0",
                    "retina": "0",
                    "category": "0",
                    "infoopen": "0",
                    "other_data": ""
                },
                "13": {
                    "map_id": "2",
                    "marker_id": "13",
                    "title": "ITALY",
                    "address": "Italy",
                    "desc": "",
                    "pic": "",
                    "icon": "",
                    "linkd": "",
                    "lat": "41.87194",
                    "lng": "12.567379999999957",
                    "anim": "0",
                    "retina": "0",
                    "category": "0",
                    "infoopen": "0",
                    "other_data": ""
                },
                "14": {
                    "map_id": "2",
                    "marker_id": "14",
                    "title": "EGYPT",
                    "address": "Egypt",
                    "desc": "",
                    "pic": "",
                    "icon": "",
                    "linkd": "",
                    "lat": "26.820553",
                    "lng": "30.802498000000014",
                    "anim": "0",
                    "retina": "0",
                    "category": "0",
                    "infoopen": "0",
                    "other_data": ""
                },
                "15": {
                    "map_id": "2",
                    "marker_id": "15",
                    "title": "SOUTH AFRICA",
                    "address": "South Africa",
                    "desc": "",
                    "pic": "",
                    "icon": "",
                    "linkd": "",
                    "lat": "-30.559482",
                    "lng": "22.937505999999985",
                    "anim": "0",
                    "retina": "0",
                    "category": "0",
                    "infoopen": "0",
                    "other_data": ""
                },
                "16": {
                    "map_id": "2",
                    "marker_id": "16",
                    "title": "KOREA",
                    "address": "Korea",
                    "desc": "",
                    "pic": "",
                    "icon": "",
                    "linkd": "",
                    "lat": "37.66399759999999",
                    "lng": "127.97845849999999",
                    "anim": "0",
                    "retina": "0",
                    "category": "0",
                    "infoopen": "0",
                    "other_data": ""
                },
                "17": {
                    "map_id": "2",
                    "marker_id": "17",
                    "title": "TAIWAN",
                    "address": "Taiwan",
                    "desc": "",
                    "pic": "",
                    "icon": "",
                    "linkd": "",
                    "lat": "23.69781",
                    "lng": "120.96051499999999",
                    "anim": "0",
                    "retina": "0",
                    "category": "0",
                    "infoopen": "0",
                    "other_data": ""
                },
                "18": {
                    "map_id": "2",
                    "marker_id": "18",
                    "title": "SPAIN",
                    "address": "Spain",
                    "desc": "",
                    "pic": "",
                    "icon": "",
                    "linkd": "",
                    "lat": "40.46366700000001",
                    "lng": "-3.7492200000000366",
                    "anim": "0",
                    "retina": "0",
                    "category": "0",
                    "infoopen": "0",
                    "other_data": ""
                },
                "19": {
                    "map_id": "2",
                    "marker_id": "19",
                    "title": "FRANCE",
                    "address": "France",
                    "desc": "",
                    "pic": "",
                    "icon": "",
                    "linkd": "",
                    "lat": "46.227638",
                    "lng": "2.213749000000007",
                    "anim": "0",
                    "retina": "0",
                    "category": "0",
                    "infoopen": "0",
                    "other_data": ""
                },
                "20": {
                    "map_id": "2",
                    "marker_id": "20",
                    "title": "THE NETHERLANDS",
                    "address": "Netherlands",
                    "desc": "",
                    "pic": "",
                    "icon": "",
                    "linkd": "",
                    "lat": "52.132633",
                    "lng": "5.2912659999999505",
                    "anim": "0",
                    "retina": "0",
                    "category": "0",
                    "infoopen": "0",
                    "other_data": ""
                },
                "21": {
                    "map_id": "2",
                    "marker_id": "21",
                    "title": "BELGIUM",
                    "address": "Belgium",
                    "desc": "",
                    "pic": "",
                    "icon": "",
                    "linkd": "",
                    "lat": "50.503887",
                    "lng": "4.4699359999999615",
                    "anim": "0",
                    "retina": "0",
                    "category": "0",
                    "infoopen": "0",
                    "other_data": ""
                },
                "22": {
                    "map_id": "2",
                    "marker_id": "22",
                    "title": "NORWAY",
                    "address": "Norway",
                    "desc": "",
                    "pic": "",
                    "icon": "",
                    "linkd": "",
                    "lat": "60.47202399999999",
                    "lng": "8.46894599999996",
                    "anim": "0",
                    "retina": "0",
                    "category": "0",
                    "infoopen": "0",
                    "other_data": ""
                },
                "23": {
                    "map_id": "2",
                    "marker_id": "23",
                    "title": "POLAND",
                    "address": "Poland",
                    "desc": "",
                    "pic": "",
                    "icon": "",
                    "linkd": "",
                    "lat": "51.919438",
                    "lng": "19.14513599999998",
                    "anim": "0",
                    "retina": "0",
                    "category": "0",
                    "infoopen": "0",
                    "other_data": ""
                },
                "24": {
                    "map_id": "2",
                    "marker_id": "24",
                    "title": "UKRAINE",
                    "address": "Ukraine",
                    "desc": "",
                    "pic": "",
                    "icon": "",
                    "linkd": "",
                    "lat": "48.379433",
                    "lng": "31.165579999999977",
                    "anim": "0",
                    "retina": "0",
                    "category": "0",
                    "infoopen": "0",
                    "other_data": ""
                },
                "25": {
                    "map_id": "2",
                    "marker_id": "25",
                    "title": "MEXICO",
                    "address": "Mexico",
                    "desc": "",
                    "pic": "",
                    "icon": "",
                    "linkd": "",
                    "lat": "23.634501",
                    "lng": "-102.55278399999997",
                    "anim": "0",
                    "retina": "0",
                    "category": "0",
                    "infoopen": "0",
                    "other_data": ""
                },
                "26": {
                    "map_id": "2",
                    "marker_id": "26",
                    "title": "BRAZIL",
                    "address": "Brazil",
                    "desc": "",
                    "pic": "",
                    "icon": "",
                    "linkd": "",
                    "lat": "-14.235004",
                    "lng": "-51.92527999999999",
                    "anim": "0",
                    "retina": "0",
                    "category": "0",
                    "infoopen": "0",
                    "other_data": ""
                }
            }
        };
        var wpgmaps_localize_cat_ids = {
            "2": "all"
        };
        var wpgmaps_localize_map_types = {
            "2": ""
        };
        var wpgmaps_localize_global_settings = {
            "wpgmza_settings_image_resizing": "yes",
            "wpgmza_settings_image_width": "",
            "wpgmza_settings_image_height": "",
            "wpgmza_settings_infowindow_width": "200",
            "wpgmza_settings_infowindow_link_text": "More details",
            "wpgmza_settings_map_scroll": "yes",
            "wpgmza_settings_map_striptags": "0",
            "wpgmza_settings_ugm_autoapprove": "0",
            "wpgmza_settings_ugm_email_new_marker": "0",
            "wpgmza_settings_ugm_email_address": "prasad@mediatree.co.in",
            "wpgmza_custom_css": "",
            "wpgmza_settings_carousel_markerlist_description": "yes",
            "wpgmza_settings_carousel_markerlist_resize_image": "yes",
            "wpgmza_settings_carousel_markerlist_theme": "sky",
            "wpgmza_default_items": "10",
            "carousel_items": "5",
            "carousel_autoplay": "5000",
            "carousel_lazyload": "yes",
            "carousel_autoheight": "yes",
            "carousel_navigation": "yes",
            "wpgmza_settings_filterbycat_type": "1",
            "wpgmza_settings_map_open_marker_by": "1",
            "wpgmza_api_version": "3.26",
            "wpgmza_settings_access_level": "manage_options",
            "wpgmza_settings_retina_width": "31",
            "wpgmza_settings_retina_height": "45",
            "wpgmza_settings_marker_pull": "0",
            "wpgmza_iw_type": "0",
            "wpgmza_settings_carousel_markerlist_image": "",
            "wpgmza_settings_carousel_markerlist_icon": "",
            "wpgmza_settings_carousel_markerlist_title": "",
            "wpgmza_settings_carousel_markerlist_address": "",
            "wpgmza_settings_carousel_markerlist_directions": "",
            "wpgmza_settings_carousel_markerlist_link": "",
            "wpgmza_settings_use_timthumb": "yes",
            "carousel_pagination": "",
            "list_markers_by": ""
        };
        var wpgmaps_localize_polygon_settings = [];
        var wpgmaps_localize_polyline_settings = [];
        var wpgmaps_localize_heatmap_settings = [];
        /* ]]> */
    </script>
    <script type='text/javascript' src='wp-content/plugins/wp-google-maps-pro/js/core.js?ver=5.73p'></script>
    <script>
        jQuery(window).scroll(function() {
            if (jQuery(document).scrollTop() > 50) {
                jQuery('header').addClass('shrink');
            } else {
                jQuery('header').removeClass('shrink');
            }
        });
        /*Youtube video*/

        jQuery('.js-lazyYT').lazyYT();
        /** Stop playing youtube video when page scrolls */

        jQuery(document).on('scroll', function() {
            var scrollTop = jQuery(window).scrollTop();
            if (scrollTop > pos.top + 315) {
                player.stopVideo();
            }
        })
    </script>
    <script>
        /* moving object */
        jQuery('.marquee').marquee({
            //speed in milliseconds of the marquee
            duration: 6000,
            //gap in pixels between the tickers
            gap: 1500,
            //time in milliseconds before the marquee will start animating
            delayBeforeStart: 0,
            //'left' or 'right'
            direction: 'right',
            //true or false - should the marquee be duplicated to show an effect of continues flow
            duplicated: true
        });
    </script>
    <script>
        jQuery(document).ready(function() {

            /* Apply fancybox to multiple items */

            jQuery("a.balaji-products").fancybox({
                'transitionIn': 'elastic',
                'transitionOut': 'elastic',
                'speedIn': 600,
                'speedOut': 200,
                'overlayShow': false
            });

            jQuery('.member-mug-shot').on('click', function() {
                jQuery('.collapse').collapse('hide');
            })

        });
    </script>
    <script>
        (function(jQuery) {
            jQuery(document).ready(function() {
                jQuery(".video-button").click(function() {
                    jQuery(".video-embed").css({
                        "opacity": "1",
                        "display": "block"
                    });
                    jQuery(".video-embed")[0].src += "&autoplay=1";
                    jQuery(this).unbind("click");
                });
            });
        })(jQuery)
    </script>
    <script>
        jQuery(document).ready(function() {

            jQuery('.fancybox').fancybox({
                beforeShow: function() {
                    this.title = jQuery(this.element).data("caption");
                }
            });

            jQuery("a#single_image-popup").fancybox();

        });
    </script>
    <script>
        jQuery(window).load(function() {
            jQuery('#single_image-popup').fancybox({
                beforeLoad: function() {
                    this.title = jQuery(this.element).find('img').attr('alt');
                }

            });

            jQuery('#single_image-popup').fancybox({
                'titleFromAlt': true,
                'titlePosition': 'inside'

            });

            jQuery("a#single_image-popup").trigger('click');
        });
    </script>
    <script>
        function myFunction() {
            window.print();
        }
    </script>
</body>
</html>