<!DOCTYPE html>
<html lang="en-US" class="no-js">
<head>
    <meta charset="UTF-8" />
		<meta name="author" content="Balaji Amines" />
	<meta name="keywords" content=" balaji , balaji amines, balaji amines solapur, Chemical Manufacturers in India, Chemical Manufacturers India, Industrial Chemicals Manufacturers, Industrial Chemicals Manufacturers in India Chemical manufacturing company in india, Chemical manufacturing company in Solapur, Chemical manufacturing company, methyl, Chemical Manufacturer,hydrochloride derivatives, industrial chemicals manufacturers, industrial chemicals suppliers, industrial chemicals india, industrial chemicals exporters, industrial chemicals manufacturer, industrial chemicals supplier, industrial chemicals exporter, industrial chemicals from india, industrial chemicals wholesale, industrial chemicals in india">
	<meta name="description"  content="Manufacturer of methyl and ethyl amines and their amide and hydrochloride derivatives, located in India.  Chemical manufacturing company in india">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Balaji &ndash; Contact Us</title>
    <style type="text/css">
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 .07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
    <link rel='stylesheet' id='formidable-css' href='wp-content/uploads/formidable/css/formidablepro.css?ver=2.03.03' type='text/css' media='all' />
    <link rel='stylesheet' id='wp_ddl_layout_fe_css-css' href='wp-content/uploads/ddl-layouts-tmp/d41d8cd98f00b204e9800998ecf8427e.css?ver=1.3.2' type='text/css' media='screen' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3/css/bootstrap.min.css?ver=3.3.4' type='text/css' media='all' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_theme_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3/css/bootstrap-theme.min.css' type='text/css' media='all' />
    <link rel='stylesheet' id='toolset-bootstrap-theme-style-css' href='wp-content/themes/toolset-bootstrap/style.css?ver=1.8' type='text/css' media='all' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_adjustment_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3_adjustment.css' type='text/css' media='all' />
    <link rel='stylesheet' id='menu-cells-front-end-css' href='wp-content/plugins/layouts/resources/css/cell-menu-css.css?ver=4.7.3' type='text/css' media='screen' />
    <link rel='stylesheet' id='ddl-front-end-css' href='wp-content/plugins/layouts/resources/css/ddl-front-end.css?ver=4.7.3' type='text/css' media='screen' />
    <link rel='stylesheet' id='toolset-common-css' href='wp-content/plugins/layouts/toolset/toolset-common/res/css/toolset-common.css?ver=4.7.3' type='text/css' media='screen' />
    <link rel='stylesheet' id='wptoolset-field-datepicker-css' href='wp-content/plugins/wp-views/embedded/common/toolset-forms/css/wpt-jquery-ui/datepicker.css?ver=1.10' type='text/css' media='all' />
    <link rel='stylesheet' id='mediaelement-css' href='wp-includes/js/mediaelement/mediaelementplayer.min.css?ver=2.22.0' type='text/css' media='all' />
    <link rel='stylesheet' id='wp-mediaelement-css' href='wp-includes/js/mediaelement/wp-mediaelement.min.css?ver=4.7.3' type='text/css' media='all' />
    <link rel='stylesheet' id='views-pagination-style-css' href='wp-content/plugins/wp-views/embedded/res/css/wpv-pagination.css?ver=1.10' type='text/css' media='all' />
    <script type='text/javascript' src='wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
    <script type='text/javascript' src='wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
    <script type='text/javascript' src='wp-content/plugins/layouts/resources/js/ddl-layouts-frontend.js?ver=1.3.2'></script>
    <style type="text/css">
        .recentcomments a {
            display: inline !important;
            padding: 0 !important;
            margin: 0 !important;
        }
    </style>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/owl.carousel.css">
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/owl.theme.css">
    <script src="wp-content/themes/toolset-bootstrap/js/owl.carousel.js"></script>
    <script type="text/javascript" src="wp-content/themes/toolset-bootstrap/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/fancybox/jquery.fancybox-1.3.4.css" type="text/css" media="screen" />
    <link href='https://fonts.googleapis.com/css?family=Khand:400,300,500,600,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,100italic,100,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link rel='stylesheet' href="wp-content/themes/toolset-bootstrap/css/mediatree.css">
    <link rel='stylesheet' media="print" href="wp-content/themes/toolset-bootstrap/css/custom-print.css">
    <link rel='stylesheet' href="wp-content/themes/toolset-bootstrap/css/zara.css">
    <link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>
    <link href="wp-content/themes/toolset-bootstrap/css/jasny-bootstrap.min.css" rel="stylesheet" media="screen">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.matchHeight.js"></script>
    <script src="wp-content/themes/toolset-bootstrap/js/jasny-bootstrap.min.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/flexslider.css" type="text/css">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.flexslider.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.matchHeight-min.js" type="text/javascript"></script>
    <script type="text/javascript" src="wp-content/themes/toolset-bootstrap/lazyyt/lazyYT.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/lazyyt/lazyYT.css">
    <script type='text/javascript' src='//cdn.jsdelivr.net/jquery.marquee/1.3.1/jquery.marquee.min.js'></script>
</head>
<body class="page-template page-template-page-layouts page-template-page-layouts-php page page-id-213">
        <div class="navmenu navmenu-default navmenu-fixed-right">
        <ul id="menu-menu-1" class="nav navmenu-nav">
            <li id="menu-item-20" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-2 current_page_item menu-item-20 active"><a href="index.php">Homepage</a></li>
            <li id="menu-item-656" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-656"><a href="#">About us</a>
                <ul class="sub-menu">
                    <li id="menu-item-267" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-267"><a href="company-profile.php">Company Profile</a></li>
                    <li id="menu-item-261" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-261"><a href="mission-values.php">Mission &#038; Values</a></li>
                    <li id="menu-item-280" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-280"><a href="certificate-awards.php">Certificate &#038; Awards</a></li>
                    <li id="menu-item-348" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-348"><a href="balaji-management-team.php">Management Team</a></li>
                    <li id="menu-item-339" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-339"><a href="balaji-amines-history.php">History</a></li>
                    <li id="menu-item-710" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-710"><a href="bal-presence.php">BAL&#8217;s Presence</a></li>
                </ul>
            </li>
            <li id="menu-item-400" class="menu-item menu-item-type-post_type_archive menu-item-object-product menu-item-has-children menu-item-400"><a href="category.php">Products</a>
                <ul class="sub-menu">
                    <li id="menu-item-658" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-658"><a href="amines.php">Amines</a></li>
                    <li id="menu-item-657" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-657"><a href="derivatives.php">Derivatives</a></li>
                    <li id="menu-item-659" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-659"><a href="speciality-chemicals.php">Speciality Chemicals</a></li>
                    <li id="menu-item-678" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-678"><a href="excipients.php">Pharma Excipients</a></li>
                </ul>
            </li>
            <li id="menu-item-534" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-534"><a href="investor-relations.php">Investor Relations</a></li>
            <li id="menu-item-290" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-290"><a href="careers.php">Careers</a></li>
            <li id="menu-item-299" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-299"><a href="corporate-social-responsibility.php">Corporate Social Responsibility</a></li>
            <li id="menu-item-282" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-282"><a href="contact-us.php">Contact Us</a></li>
            <li id="menu-item-307" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-307"><a href="balaji-media.php">Media</a></li>
            <li id="menu-item-711" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-711"><a href="e-brochures.php">E-Brochure</a></li>
        </ul>
    </div>        <!-- Off Canvas Menu Ends -->
        <div class="canvas">
            <header class="full-bg black-bg" id="homepage-header">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-1" id="off-canvas-button">
                            <div class="navbar navbar-default">
                                <button type="button" class="navbar-toggle" data-toggle="offcanvas" data-recalc="false" data-target=".navmenu" data-canvas=".canvas">
                                    <br />
                                    <span class="icon-bar"></span>
                                    <br />
                                    <span class="icon-bar"></span>
                                    <br />
                                    <span class="icon-bar"></span>
                                    <br />
                                </button>
                            </div>
                        </div>
                        <div class="col-sm-4 col-sm-offset-3" id="homepage-logo">
                            <p>
                            <p>
                                <a href=""><img src="wp-content/uploads/2015/10/balaji_logo.png" alt="Balaji Almines" class="aligncenter size-full img-responsive"></a>
                            </p>
                        </div>
                    </div>
                </div>
            </header>
            <div class="container-fluid">
                <div class="ddl-full-width-row row">
                    <div class="col-sm-12 featured-thumbnail">
                        <div class="thumbnail">
                            <img src="wp-content/uploads/2015/10/banner-contact-us.jpg">
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-sm-4 page-title-div text-center col-sm-offset-4">
                        <h1>CONTACT US</h1>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="ddl-full-width-row row contact-us-tagline">
                    <div class="col-sm-10 col-sm-offset-1">
                        <p style="text-align: center;">For further details on our Products and Services and for other Business Inquiries, contact us at,</p>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="ddl-full-width-row row" id="contact-us">
                    <div class="col-sm-5 heading-color col-sm-offset-1">
                        <h2>Registered office:</h2>
                        <h3>BALAJI&nbsp;AMINES LIMITED .</h3>
                        <p>Balaji Towers,
                            <br /> No. 9/1A/1, Hotgi Road,
                            <br /> Asara Chowk, Solapur,
                            <br /> Maharashtra , India -413224.
                            <br /> CIN: L24132MH1988PLC049387
                            <br /> Phones:&nbsp;
                            <br /> 0091-217-2451500 | 0091-217-2451522 (Sales)
                            <br /> 0091-217-2451528 (Exports)
                            <br /> Email: info@balajiamines.com | mktg@balajiamines.com</p>
                    </div>
                    <div class="col-sm-5 heading-color">
                        <h2>Administrative Office:</h2>
                        <h3>BALAJI&nbsp;AMINES LIMITED .</h3>
<p>Balaji Bhawan,
<br />Plot No. 47, Kavuri Hills,
<br />Behind Jubilee Ridge Hotel,
<br />Madhapur, Hyderabad
<br />Telangana, India - 500 033
<br />Phone No. 040-49871200
<br />Email: infohyd@balajiamines.com | unit2mktg@balajiamines.com
                        </p>
                    </div>
                </div>
            </div>
           
            <div class="container">
                <div class="row contact-us-page">

                    <div class="col-sm-12 heading-color">
                        <h2>Manufacturing Sites:</h2>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row contact-us-page">

                    <div class="col-sm-3 heading-color">
                        <h3>UNIT I:</h3>
                        <p>Tamalwadi village – 413623, Tuljapur,
                            <br /> Dist: Dharashiv, Maharashtra,
                            <br /> INDIA.
                        </p>
                        <h3>Phones:</h3>
                        <!-- 
                        <p>0091-2471-265013
                            <br /> 0091-2471-265014
                            <br /> 0091-2471-265015
                        </p> -->
                        <h3>Email:</h3>
                        <p>factoryoffice@balajiamines.in
                            <br /> works1@balajiamines.in
                        </p>
                    </div>
                    <div class="col-sm-3 heading-color">
                        <h3>UNIT II:</h3>
                        <p>Plots No: 4 &amp; 5,
                            <br /> Near A.P.TRANSCO
                            <br /> IDA, Bollaram, Hyderabad.
                            <br /> INDIA
                        </p>
                        <h3>Email:</h3>
                        <p>works2@balajiamines.in</p>
                    </div>
                    <div class="col-sm-3 heading-color">
                        <h3>UNIT III:</h3>
                        <p>E-7, M.I.D.C., Chincholi,
                            <br /> Taq. : Mohol,
                            <br /> Dist. : Solapur,
                            <br /> Maharashtra, INDIA.</p>
                              <h3>Phone :</h3>
                      <!--
                        <p>0091-217-2357051</p> -->
                        <h3>Email:</h3>
                        <p>unit3works@balajiamines.in</p>
                    </div>
                    <div class="col-sm-3 heading-color">
                        <h3>UNIT IV:</h3>
                        <p>F-104, M.I.D.C. Chincholi,
                            <br /> Taq. : Mohol,
                            <br /> Dist. : Solapur,
                            <br /> Maharashtra, INDIA.</p>
                        <h3>Phone :</h3>
                      <!--  <p>0091-217-2357051</p> -->
                        <h3>Email:</h3>
                        <p>unit4works@balajiamines.in</p>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row contact-us-page">

                    <div class="col-sm-12 heading-color">
                        <h2>Sales:</h2>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row heading-color contact-us-page">

                    <div class="col-sm-4 heading-color">
                        <h3>DOMESTIC:</h3>
                        <h3>Email:</h3>
                        <p>mktg@balajiamines.com</p>
                        <h3>Telephone:</h3>
                        <p>0217 &#8211; 2451 522</p>
                    </div>
                    <div class="col-sm-4 heading-color">
                        <h3>INTERNATIONAL:</h3>
                        <h3>Email:</h3>
                        <p>info@balajiamines.com
                            <br /> exports@balajiamines.com
                        </p>
                        <h3>Telephone:</h3>
                        <p>0217 &#8211; 2451 528</p>
                    </div>
                    <div class="col-sm-4 heading-color">
                        <h3>HUMAN RESOURCE DEVELOPMENT:</h3>
                        <h3>Email:</h3>
                        <p>hr@balajiamines.com</p>
                    </div>
                </div>
            </div>
 <footer class="full-bg " id="footer">

            <div class="container">
                <div class="row">

                    <div class="col-sm-4  widget-cell" id="footer-widget-1">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">ABOUT</h3>
                            <div class="menu-overview-footer-container">
                                <ul id="menu-overview-footer" class="menu">
                                    <li id="menu-item-412" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-412"><a href="company-profile.php">Company Profile</a></li>
                                    <li id="menu-item-415" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-415"><a href="mission-values.php">Mission &#038; Values</a></li>
                                    <li id="menu-item-414" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-414"><a href="certificate-awards.php">Certificate &#038; Awards</a></li>
                                    <li id="menu-item-413" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-413"><a href="balaji-management-team.php">Management Team</a></li>
                                    <li id="menu-item-479" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-479"><a href="balaji-amines-history.php">History</a></li>
                                    <li id="menu-item-709" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-709"><a href="bal-presence.php">BAL&#8217;s Presence</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4  widget-cell">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">PRODUCTS</h3>
                            <div class="menu-overview-footer-1-container">
                                <ul id="menu-overview-footer-1" class="menu">
                                    <li id="menu-item-417" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-417"><a href="amines.php">Amines</a></li>
                                    <li id="menu-item-416" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-416"><a href="derivatives.php">Derivatives</a></li>
                                    <li id="menu-item-418" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-418"><a href="speciality-chemicals.php">Speciality Chemicals</a></li>
                                    <li id="menu-item-679" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-679"><a href="excipients.php">Pharma Excipients</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4  widget-cell">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">OTHERS</h3>
                            <div class="menu-footer3-container">
                                <ul id="menu-footer3" class="menu">
                                    <li id="menu-item-655" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-655"><a href="investor-relations.php">Investor Relations</a></li>
                                    <li id="menu-item-420" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-286 current_page_item menu-item-420 active"><a href="careers.php">Careers</a></li>
                                    <li id="menu-item-421" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-421"><a href="corporate-social-responsibility.php">Corporate Social Responsibility</a></li>
                                    <li id="menu-item-713" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-713"><a href="e-brochures.php">E-Brochure</a></li>
                                    <li id="menu-item-423" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-423"><a href="balaji-media.php">Media</a></li>
                                    <li id="menu-item-422" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-422"><a href="contact-us.php">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-1  widget-cell col-sm-offset-1">
                        <div class="widget widget_text">
                            <div class="textwidget"></div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="row">
                            <div class="col-sm-12" id="social-media-icons"></div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 col-sm-offset-6"></div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
		<div class="container-fluid">
            <div class="ddl-full-width-row row">
                <div class="col-sm-12 copyright-footer">
                    <p>copyright © balaji Amines 2025 Developed By <a href="http://katareinfo.com/">Katrare Informatics</a></p>
                </div>
            </div>
        </div>        </div>
        <script type='text/javascript' src='wp-content/themes/toolset-bootstrap/bootstrap3/js/bootstrap.min.js?ver=3.3.4'></script>
        <script type='text/javascript' src='wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
        <script type='text/javascript' src='wp-includes/js/jquery/ui/datepicker.min.js?ver=1.11.4'></script>
        <script type='text/javascript' src='wp-includes/js/mediaelement/mediaelement-and-player.min.js?ver=2.22.0'></script>
        <script type='text/javascript' src='wp-includes/js/mediaelement/wp-mediaelement.min.js?ver=4.7.3'></script>
        <script type='text/javascript' src='wp-includes/js/underscore.min.js?ver=1.8.3'></script>
        <script type='text/javascript' src='wp-includes/js/wp-util.min.js?ver=4.7.3'></script>
        <script type='text/javascript' src='wp-includes/js/backbone.min.js?ver=1.2.3'></script>
        <script type='text/javascript' src='wp-includes/js/mediaelement/wp-playlist.min.js?ver=4.7.3'></script>
        <script type='text/javascript' src='wp-content/plugins/wp-views/embedded/res/js/wpv-pagination-embedded.js?ver=1.10'></script>
        <script type='text/javascript' src='wp-includes/js/wp-embed.min.js?ver=4.7.3'></script>
        <script>
            jQuery(window).scroll(function() {
                if (jQuery(document).scrollTop() > 50) {
                    jQuery('header').addClass('shrink');
                } else {
                    jQuery('header').removeClass('shrink');
                }
            });
            jQuery('.js-lazyYT').lazyYT();

            /** Stop playing youtube video when page scrolls */

            jQuery(document).on('scroll', function() {
                var scrollTop = jQuery(window).scrollTop();
                if (scrollTop > pos.top + 315) {
                    player.stopVideo();
                }
            })
        </script>
        <script>
            /* moving object */
            jQuery('.marquee').marquee({
                //speed in milliseconds of the marquee
                duration: 6000,
                //gap in pixels between the tickers
                gap: 1500,
                //time in milliseconds before the marquee will start animating
                delayBeforeStart: 0,
                //'left' or 'right'
                direction: 'right',
                //true or false - should the marquee be duplicated to show an effect of continues flow
                duplicated: true
            });
        </script>
        <script>
            jQuery(document).ready(function() {
                /* Apply fancybox to multiple items */
                jQuery("a.balaji-products").fancybox({
                    'transitionIn': 'elastic',
                    'transitionOut': 'elastic',
                    'speedIn': 600,
                    'speedOut': 200,
                    'overlayShow': false
                });
                jQuery('.member-mug-shot').on('click', function() {
                    jQuery('.collapse').collapse('hide');
                })
            });
        </script>
        <script>
            (function(jQuery) {
                jQuery(document).ready(function() {
                    jQuery(".video-button").click(function() {
                        jQuery(".video-embed").css({
                            "opacity": "1",
                            "display": "block"
                        });
                        jQuery(".video-embed")[0].src += "&autoplay=1";
                        jQuery(this).unbind("click");
                    });
                });
            })(jQuery)
        </script>
        <script>
            jQuery(document).ready(function() {

                jQuery('.fancybox').fancybox({
                    beforeShow: function() {
                        this.title = jQuery(this.element).data("caption");
                    }
                });

                jQuery("a#single_image-popup").fancybox();

            });
        </script>
        <script>
            jQuery(window).load(function() {
                jQuery('#single_image-popup').fancybox({
                    beforeLoad: function() {
                        this.title = jQuery(this.element).find('img').attr('alt');
                    }

                });

                jQuery('#single_image-popup').fancybox({
                    'titleFromAlt': true,
                    'titlePosition': 'inside'

                });

                jQuery("a#single_image-popup").trigger('click');
            });
        </script>
        <script>
            function myFunction() {
                window.print();
            }
        </script>
</body>
</html>