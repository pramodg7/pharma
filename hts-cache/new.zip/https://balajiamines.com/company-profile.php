<!DOCTYPE html>
<html lang="en-US" class="no-js">
<!--<![endif]-->

<head>
    <meta charset="UTF-8" />
		<meta name="author" content="Balaji Amines" />
	<meta name="keywords" content=" balaji , balaji amines, balaji amines solapur, Chemical Manufacturers in India, Chemical Manufacturers India, Industrial Chemicals Manufacturers, Industrial Chemicals Manufacturers in India Chemical manufacturing company in india, Chemical manufacturing company in Solapur, Chemical manufacturing company, methyl, Chemical Manufacturer,hydrochloride derivatives, industrial chemicals manufacturers, industrial chemicals suppliers, industrial chemicals india, industrial chemicals exporters, industrial chemicals manufacturer, industrial chemicals supplier, industrial chemicals exporter, industrial chemicals from india, industrial chemicals wholesale, industrial chemicals in india">
	<meta name="description"  content="Manufacturer of methyl and ethyl amines and their amide and hydrochloride derivatives, located in India.  Chemical manufacturing company in india">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Balaji &ndash; Company Profile</title>
    <style type="text/css">
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 .07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
    <link rel='stylesheet' id='formidable-css' href='wp-content/uploads/formidable/css/formidablepro.css?ver=2.0.13' type='text/css' media='all' />
    <link rel='stylesheet' id='wp_ddl_layout_fe_css-css' href='wp-content/uploads/ddl-layouts-tmp/d41d8cd98f00b204e9800998ecf8427e.css?ver=1.3.2' type='text/css' media='screen' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3/css/bootstrap.min.css?ver=3.3.4' type='text/css' media='all' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_theme_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3/css/bootstrap-theme.min.css' type='text/css' media='all' />
    <link rel='stylesheet' id='toolset-bootstrap-theme-style-css' href='wp-content/themes/toolset-bootstrap/style.css?ver=1.8' type='text/css' media='all' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_adjustment_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3_adjustment.css' type='text/css' media='all' />
    <link rel='stylesheet' id='menu-cells-front-end-css' href='wp-content/plugins/layouts/resources/css/cell-menu-css.css?ver=4.7.2' type='text/css' media='screen' />
    <link rel='stylesheet' id='ddl-front-end-css' href='wp-content/plugins/layouts/resources/css/ddl-front-end.css?ver=4.7.2' type='text/css' media='screen' />
    <link rel='stylesheet' id='toolset-common-css' href='wp-content/plugins/layouts/toolset/toolset-common/res/css/toolset-common.css?ver=4.7.2' type='text/css' media='screen' />
    <link rel='stylesheet' id='wptoolset-field-datepicker-css' href='wp-content/plugins/wp-views/embedded/common/toolset-forms/css/wpt-jquery-ui/datepicker.css?ver=1.10' type='text/css' media='all' />
    <link rel='stylesheet' id='mediaelement-css' href='wp-includes/js/mediaelement/mediaelementplayer.min.css?ver=2.22.0' type='text/css' media='all' />
    <link rel='stylesheet' id='wp-mediaelement-css' href='wp-includes/js/mediaelement/wp-mediaelement.min.css?ver=4.7.2' type='text/css' media='all' />
    <link rel='stylesheet' id='views-pagination-style-css' href='wp-content/plugins/wp-views/embedded/res/css/wpv-pagination.css?ver=1.10' type='text/css' media='all' />
    <script type='text/javascript' src='wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
    <script type='text/javascript' src='wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>

    <script type='text/javascript' src='wp-content/plugins/layouts/resources/js/ddl-layouts-frontend.js?ver=1.3.2'></script>
  <style type="text/css">
        .recentcomments a {
            display: inline !important;
            padding: 0 !important;
            margin: 0 !important;
        }
    </style>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/owl.carousel.css">
    <!-- Default Theme -->
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/owl.theme.css">
    <!-- Include js plugin -->
    <script src="wp-content/themes/toolset-bootstrap/js/owl.carousel.js"></script>
    <!--Fancy box -->
    <script type="text/javascript" src="wp-content/themes/toolset-bootstrap/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/fancybox/jquery.fancybox-1.3.4.css" type="text/css" media="screen" />
    <link href='https://fonts.googleapis.com/css?family=Khand:400,300,500,600,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,100italic,100,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link rel='stylesheet' href="wp-content/themes/toolset-bootstrap/css/mediatree.css">
    <link rel='stylesheet' media="print" href="wp-content/themes/toolset-bootstrap/css/custom-print.css">

    <link rel='stylesheet' href="wp-content/themes/toolset-bootstrap/css/zara.css">
    <link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>
    <link href="wp-content/themes/toolset-bootstrap/css/jasny-bootstrap.min.css" rel="stylesheet" media="screen">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.matchHeight.js"></script>

    <script src="wp-content/themes/toolset-bootstrap/js/jasny-bootstrap.min.js"></script>

    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/flexslider.css" type="text/css">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.flexslider.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.matchHeight-min.js" type="text/javascript"></script>
    <script type="text/javascript" src="wp-content/themes/toolset-bootstrap/lazyyt/lazyYT.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/lazyyt/lazyYT.css">
    <script type='text/javascript' src='//cdn.jsdelivr.net/jquery.marquee/1.3.1/jquery.marquee.min.js'></script>
</head>
<body class="page-template page-template-page-layouts page-template-page-layouts-php page page-id-259">
        <div class="navmenu navmenu-default navmenu-fixed-right">
        <ul id="menu-menu-1" class="nav navmenu-nav">
            <li id="menu-item-20" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-2 current_page_item menu-item-20 active"><a href="index.php">Homepage</a></li>
            <li id="menu-item-656" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-656"><a href="#">About us</a>
                <ul class="sub-menu">
                    <li id="menu-item-267" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-267"><a href="company-profile.php">Company Profile</a></li>
                    <li id="menu-item-261" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-261"><a href="mission-values.php">Mission &#038; Values</a></li>
                    <li id="menu-item-280" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-280"><a href="certificate-awards.php">Certificate &#038; Awards</a></li>
                    <li id="menu-item-348" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-348"><a href="balaji-management-team.php">Management Team</a></li>
                    <li id="menu-item-339" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-339"><a href="balaji-amines-history.php">History</a></li>
                    <li id="menu-item-710" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-710"><a href="bal-presence.php">BAL&#8217;s Presence</a></li>
                </ul>
            </li>
            <li id="menu-item-400" class="menu-item menu-item-type-post_type_archive menu-item-object-product menu-item-has-children menu-item-400"><a href="category.php">Products</a>
                <ul class="sub-menu">
                    <li id="menu-item-658" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-658"><a href="amines.php">Amines</a></li>
                    <li id="menu-item-657" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-657"><a href="derivatives.php">Derivatives</a></li>
                    <li id="menu-item-659" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-659"><a href="speciality-chemicals.php">Speciality Chemicals</a></li>
                    <li id="menu-item-678" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-678"><a href="excipients.php">Pharma Excipients</a></li>
                </ul>
            </li>
            <li id="menu-item-534" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-534"><a href="investor-relations.php">Investor Relations</a></li>
            <li id="menu-item-290" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-290"><a href="careers.php">Careers</a></li>
            <li id="menu-item-299" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-299"><a href="corporate-social-responsibility.php">Corporate Social Responsibility</a></li>
            <li id="menu-item-282" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-282"><a href="contact-us.php">Contact Us</a></li>
            <li id="menu-item-307" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-307"><a href="balaji-media.php">Media</a></li>
            <li id="menu-item-711" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-711"><a href="e-brochures.php">E-Brochure</a></li>
        </ul>
    </div>        <!-- Off Canvas Menu Ends -->
        <div class="canvas">
            <!--<div class="container">-->
            <header class="full-bg black-bg" id="homepage-header">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-1" id="off-canvas-button">
                            <div class="navbar navbar-default">
                                <button type="button" class="navbar-toggle" data-toggle="offcanvas" data-recalc="false" data-target=".navmenu" data-canvas=".canvas">
                                    <br />
                                    <span class="icon-bar"></span>
                                    <br />
                                    <span class="icon-bar"></span>
                                    <br />
                                    <span class="icon-bar"></span>
                                    <br />
                                </button>
                            </div>
                        </div>
                        <div class="col-sm-4 col-sm-offset-3" id="homepage-logo">
                            <p>
                             <p>
                                <a href=""><img src="wp-content/uploads/2015/10/balaji_logo.png" alt="Balaji Almines" class="aligncenter size-full img-responsive"></a>
                            </p>
                        </div>
                    </div>
                </div>
            </header>
            <div class="container-fluid">
                <div class="ddl-full-width-row row">
                    <div class="col-sm-12 page-featured-image">
                        <div class="thumbnail">
                            <img src="wp-content/uploads/2015/10/company-profile-banner1.jpg">
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">

                    <div class="col-sm-4 page-title-div text-center col-sm-offset-4">
                        <h1>COMPANY PROFILE</h1>
                    </div>
                </div>
            </div>
            <div class="full-bg full-white-section">

                <div class="container">
                    <div class="row">

                        <div class="col-sm-12">
                            <div class="row">
                                <div class="col-sm-12 text-center" id="about-quote">
                                   <p>Balaji Amines Ltd., INDIA, an ISO 9001:2015, ISO 14001:2015, ISO 45001:2018 certified company, specialised in manufacturing Methylamines, Ethylamines, Derivatives of Specialty Chemicals and Pharma Excipients. These have been the main products, we also have facilities for the manufacture of derivatives, which are down stream products for various Pharma /Pesticide industries apart from user specific requirements.
                                        <br>
                                        <br> Balaji Amines Limited (BAL), one of the leading manufacturers of Aliphatic Amines in India was set up in the year 1988 to cater to the growing requirements of value based Specialty Chemicals. BAL commenced manufacture of Methyl Amines in the year 1989 and subsequently added facilities for manufacture of Ethyl Amines and other derivatives of Methyl Amines and Ethyl Amines.
                                        <br>
                                        <br> BAL has been consistently adding capacities and fine tuning process to provide quality products at lowest cost to the customers. World over, Amine technology is a closely guarded process with only a few handful companies having access to such technology. BAL for the first time in India tested on an indigenously developed technology and developed it further over a period of time.
                                        <br>
                                        <br> Today, BAL‘s products are accepted in international markets and have gained the distinct export quality status, which makes it one of the few companies in India having the potential to match the stringent international quality standards for which we have been awarded ISO 9001:2015, ISO 14001:2015, ISO 45001:2018 Certification apart from appreciation and continuous orders from global majors for our product range.

                                    </p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12 company-image">
                                    <div class="thumbnail">
                                        <img src="wp-content/uploads/2015/10/company-profile_01.jpg">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12" id="about-quote1">
                                    <!--Our fully equipped, state-of-the-art, computerised controlled plant produces primary products (mentioned above) as well as their derivatives. The latter are refined and processed products which are used in various pharmacy or pesticidal industries. We pride ourselves in using innovative technology and advanced processing which in-turn helps us to provide customers with quality products at affordable, competitive prices. Our dedication to Research and Development has helped us earn the tag of A-1 quality manufacturers. With advanced thinking and early + smart adoption of aboriginal technology Balaji Amines has managed to flourish in international as well as domestic markets and earn respect + loyalty.-->
                                    <p>BAL`s state-of-the-art manufacturing facility is located at Tamalwadi Village, near Solapur (Maharashtra State, India) The facility is fully equipped with latest technology like digital computerized controlled systems, which facilitates the control of operations from the control room in addition, BAL possesses an excellent R&amp;D facilities and laboratory, which helps in conducting basic research and also to fine tune the process.</p>
                                </div>
                            </div>
                            <div class="row" id="company-sec-row">
                                <div class="col-sm-6 company-image">
                                    <div class="thumbnail">
                                        <img src="wp-content/uploads/2015/10/company-profile_02.jpg">
                                    </div>
                                </div>
                                <div class="col-sm-6 company-image">
                                    <div class="thumbnail">
                                        <img src="wp-content/uploads/2015/10/company-profile_03.jpg">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
 <footer class="full-bg " id="footer">

            <div class="container">
                <div class="row">

                    <div class="col-sm-4  widget-cell" id="footer-widget-1">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">ABOUT</h3>
                            <div class="menu-overview-footer-container">
                                <ul id="menu-overview-footer" class="menu">
                                    <li id="menu-item-412" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-412"><a href="company-profile.php">Company Profile</a></li>
                                    <li id="menu-item-415" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-415"><a href="mission-values.php">Mission &#038; Values</a></li>
                                    <li id="menu-item-414" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-414"><a href="certificate-awards.php">Certificate &#038; Awards</a></li>
                                    <li id="menu-item-413" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-413"><a href="balaji-management-team.php">Management Team</a></li>
                                    <li id="menu-item-479" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-479"><a href="balaji-amines-history.php">History</a></li>
                                    <li id="menu-item-709" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-709"><a href="bal-presence.php">BAL&#8217;s Presence</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4  widget-cell">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">PRODUCTS</h3>
                            <div class="menu-overview-footer-1-container">
                                <ul id="menu-overview-footer-1" class="menu">
                                    <li id="menu-item-417" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-417"><a href="amines.php">Amines</a></li>
                                    <li id="menu-item-416" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-416"><a href="derivatives.php">Derivatives</a></li>
                                    <li id="menu-item-418" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-418"><a href="speciality-chemicals.php">Speciality Chemicals</a></li>
                                    <li id="menu-item-679" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-679"><a href="excipients.php">Pharma Excipients</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4  widget-cell">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">OTHERS</h3>
                            <div class="menu-footer3-container">
                                <ul id="menu-footer3" class="menu">
                                    <li id="menu-item-655" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-655"><a href="investor-relations.php">Investor Relations</a></li>
                                    <li id="menu-item-420" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-286 current_page_item menu-item-420 active"><a href="careers.php">Careers</a></li>
                                    <li id="menu-item-421" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-421"><a href="corporate-social-responsibility.php">Corporate Social Responsibility</a></li>
                                    <li id="menu-item-713" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-713"><a href="e-brochures.php">E-Brochure</a></li>
                                    <li id="menu-item-423" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-423"><a href="balaji-media.php">Media</a></li>
                                    <li id="menu-item-422" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-422"><a href="contact-us.php">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-1  widget-cell col-sm-offset-1">
                        <div class="widget widget_text">
                            <div class="textwidget"></div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="row">
                            <div class="col-sm-12" id="social-media-icons"></div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 col-sm-offset-6"></div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
		<div class="container-fluid">
            <div class="ddl-full-width-row row">
                <div class="col-sm-12 copyright-footer">
                    <p>copyright © balaji Amines 2025 Developed By <a href="http://katareinfo.com/">Katrare Informatics</a></p>
                </div>
            </div>
        </div>
        </div>
        <!--</div>-->
        <!-- .container & canvas-->

        <script type="text/html" id="tmpl-wp-playlist-current-item">
            <# if ( data.image ) { #>
                <img src="{{ data.thumb.src }}" alt="" />
                <# } #>
                    <div class="wp-playlist-caption">
                        <span class="wp-playlist-item-meta wp-playlist-item-title">&#8220;{{ data.title }}&#8221;</span>
                        <# if ( data.meta.album ) { #><span class="wp-playlist-item-meta wp-playlist-item-album">{{ data.meta.album }}</span>
                            <# } #>
                                <# if ( data.meta.artist ) { #><span class="wp-playlist-item-meta wp-playlist-item-artist">{{ data.meta.artist }}</span>
                                    <# } #>
                    </div>
        </script>

        <script type='text/javascript' src='wp-content/themes/toolset-bootstrap/bootstrap3/js/bootstrap.min.js?ver=3.3.4'></script>
        <script type='text/javascript' src='wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
        <script type='text/javascript' src='wp-includes/js/jquery/ui/datepicker.min.js?ver=1.11.4'></script>
        <script type='text/javascript'>
            jQuery(document).ready(function(jQuery) {
                jQuery.datepicker.setDefaults({
                    "closeText": "Close",
                    "currentText": "Today",
                    "monthNames": ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                    "monthNamesShort": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                    "nextText": "Next",
                    "prevText": "Previous",
                    "dayNames": ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                    "dayNamesShort": ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                    "dayNamesMin": ["S", "M", "T", "W", "T", "F", "S"],
                    "dateFormat": "MM d, yy",
                    "firstDay": 1,
                    "isRTL": false
                });
            });
        </script>

        <script type='text/javascript' src='wp-includes/js/mediaelement/mediaelement-and-player.min.js?ver=2.22.0'></script>
        <script type='text/javascript' src='wp-includes/js/mediaelement/wp-mediaelement.min.js?ver=4.7.2'></script>
        <script type='text/javascript' src='wp-includes/js/underscore.min.js?ver=1.8.3'></script>
        <script type='text/javascript'>
            /* <![CDATA[ */
            var _wpUtilSettings = {
                "ajax": {
                    "url": "\/wp-admin\/admin-ajax.php"
                }
            };
            var _wpUtilSettings = {
                "ajax": {
                    "url": "\/wp-admin\/admin-ajax.php"
                }
            };
            /* ]]> */
        </script>
        <script type='text/javascript' src='wp-includes/js/wp-util.min.js?ver=4.7.2'></script>
        <script type='text/javascript' src='wp-includes/js/backbone.min.js?ver=1.2.3'></script>
        <script type='text/javascript' src='wp-includes/js/mediaelement/wp-playlist.min.js?ver=4.7.2'></script>
        <script type='text/javascript'>
            /* <![CDATA[ */
            var wpv_pagination_local = {
                "front_ajaxurl": "http:\/\/www.balajiamines.in\/wp-admin\/admin-ajax.php",
                "ajax_pagination_url": "http:\/\/www.balajiamines.in\/wpv-ajax-pagination\/",
                "calendar_image": "http:\/\/www.balajiamines.in\/wp-content\/plugins\/wp-views\/embedded\/res\/img\/calendar.gif",
                "calendar_text": "Select date",
                "datepicker_min_date": null,
                "datepicker_max_date": null
            };
            /* ]]> */
        </script>
        <script type='text/javascript' src='wp-content/plugins/wp-views/embedded/res/js/wpv-pagination-embedded.js?ver=1.10'></script>
        <script type='text/javascript' src='wp-includes/js/wp-embed.min.js?ver=4.7.2'></script>

        <script>
            jQuery(window).scroll(function() {
                if (jQuery(document).scrollTop() > 50) {
                    jQuery('header').addClass('shrink');
                } else {
                    jQuery('header').removeClass('shrink');
                }
            });

            /*Youtube video*/

            jQuery('.js-lazyYT').lazyYT();

            /** Stop playing youtube video when page scrolls */

            jQuery(document).on('scroll', function() {
                var scrollTop = jQuery(window).scrollTop();
                if (scrollTop > pos.top + 315) {
                    player.stopVideo();
                }
            })
        </script>
        <script>
            /* moving object */
            jQuery('.marquee').marquee({
                //speed in milliseconds of the marquee
                duration: 6000,
                //gap in pixels between the tickers
                gap: 1500,
                //time in milliseconds before the marquee will start animating
                delayBeforeStart: 0,
                //'left' or 'right'
                direction: 'right',
                //true or false - should the marquee be duplicated to show an effect of continues flow
                duplicated: true
            });
        </script>

        <script>
            jQuery(document).ready(function() {

                /* Apply fancybox to multiple items */

                jQuery("a.balaji-products").fancybox({
                    'transitionIn': 'elastic',
                    'transitionOut': 'elastic',
                    'speedIn': 600,
                    'speedOut': 200,
                    'overlayShow': false
                });

                jQuery('.member-mug-shot').on('click', function() {
                    jQuery('.collapse').collapse('hide');
                })

            });
        </script>
        <script>
            (function(jQuery) {
                jQuery(document).ready(function() {
                    jQuery(".video-button").click(function() {
                        jQuery(".video-embed").css({
                            "opacity": "1",
                            "display": "block"
                        });
                        jQuery(".video-embed")[0].src += "&autoplay=1";
                        jQuery(this).unbind("click");
                    });
                });
            })(jQuery)
        </script>
        <script>
            jQuery(document).ready(function() {

                jQuery('.fancybox').fancybox({
                    beforeShow: function() {
                        this.title = jQuery(this.element).data("caption");
                    }
                });

                jQuery("a#single_image-popup").fancybox();

            });
        </script>

        <script>
            jQuery(window).load(function() {
                jQuery('#single_image-popup').fancybox({
                    beforeLoad: function() {
                        this.title = jQuery(this.element).find('img').attr('alt');
                    }

                });

                jQuery('#single_image-popup').fancybox({
                    'titleFromAlt': true,
                    'titlePosition': 'inside'

                });

                jQuery("a#single_image-popup").trigger('click');
            });
        </script>
        <script>
            function myFunction() {
                window.print();
            }
        </script>
</body>

</html>