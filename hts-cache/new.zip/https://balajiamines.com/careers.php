<!DOCTYPE html>
<html lang="en-US" class="no-js">
<head>
    <meta charset="UTF-8" />
		<meta name="author" content="Balaji Amines" />
	<meta name="keywords" content=" balaji , balaji amines, balaji amines solapur, Chemical Manufacturers in India, Chemical Manufacturers India, Industrial Chemicals Manufacturers, Industrial Chemicals Manufacturers in India Chemical manufacturing company in india, Chemical manufacturing company in Solapur, Chemical manufacturing company, methyl, Chemical Manufacturer,hydrochloride derivatives, industrial chemicals manufacturers, industrial chemicals suppliers, industrial chemicals india, industrial chemicals exporters, industrial chemicals manufacturer, industrial chemicals supplier, industrial chemicals exporter, industrial chemicals from india, industrial chemicals wholesale, industrial chemicals in india">
	<meta name="description"  content="Manufacturer of methyl and ethyl amines and their amide and hydrochloride derivatives, located in India.  Chemical manufacturing company in india">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Balaji &ndash; Careers</title>
    <link rel="shortcut icon" href="wp-content/themes/toolset-bootstrap/favicon.ico">
    <style type="text/css">
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 .07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
    <link rel='stylesheet' id='formidable-css' href='wp-content/uploads/formidable/css/formidablepro.css?ver=2.03.03' type='text/css' media='all' />
    <link rel='stylesheet' id='wp_ddl_layout_fe_css-css' href='wp-content/uploads/ddl-layouts-tmp/d41d8cd98f00b204e9800998ecf8427e.css?ver=1.3.2' type='text/css' media='screen' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3/css/bootstrap.min.css?ver=3.3.4' type='text/css' media='all' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_theme_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3/css/bootstrap-theme.min.css' type='text/css' media='all' />
    <link rel='stylesheet' id='toolset-bootstrap-theme-style-css' href='wp-content/themes/toolset-bootstrap/style.css?ver=1.8' type='text/css' media='all' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_adjustment_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3_adjustment.css' type='text/css' media='all' />
    <link rel='stylesheet' id='menu-cells-front-end-css' href='wp-content/plugins/layouts/resources/css/cell-menu-css.css?ver=4.7.3' type='text/css' media='screen' />
    <link rel='stylesheet' id='ddl-front-end-css' href='wp-content/plugins/layouts/resources/css/ddl-front-end.css?ver=4.7.3' type='text/css' media='screen' />
    <link rel='stylesheet' id='toolset-common-css' href='wp-content/plugins/layouts/toolset/toolset-common/res/css/toolset-common.css?ver=4.7.3' type='text/css' media='screen' />
    <link rel='stylesheet' id='wptoolset-field-datepicker-css' href='wp-content/plugins/wp-views/embedded/common/toolset-forms/css/wpt-jquery-ui/datepicker.css?ver=1.10' type='text/css' media='all' />
    <link rel='stylesheet' id='mediaelement-css' href='wp-includes/js/mediaelement/mediaelementplayer.min.css?ver=2.22.0' type='text/css' media='all' />
    <link rel='stylesheet' id='wp-mediaelement-css' href='wp-includes/js/mediaelement/wp-mediaelement.min.css?ver=4.7.3' type='text/css' media='all' />
    <link rel='stylesheet' id='views-pagination-style-css' href='wp-content/plugins/wp-views/embedded/res/css/wpv-pagination.css?ver=1.10' type='text/css' media='all' />
    <script type='text/javascript' src='wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
    <script type='text/javascript' src='wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
    <script type='text/javascript' src='wp-content/plugins/layouts/resources/js/ddl-layouts-frontend.js?ver=1.3.2'></script>
    <style type="text/css">
        .recentcomments a {
            display: inline !important;
            padding: 0 !important;
            margin: 0 !important;
        }
    </style>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/owl.carousel.css">
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/owl.theme.css">
    <script src="wp-content/themes/toolset-bootstrap/js/owl.carousel.js"></script>
    <script type="text/javascript" src="wp-content/themes/toolset-bootstrap/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/fancybox/jquery.fancybox-1.3.4.css" type="text/css" media="screen" />
    <link href='https://fonts.googleapis.com/css?family=Khand:400,300,500,600,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,100italic,100,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link rel='stylesheet' href="wp-content/themes/toolset-bootstrap/css/mediatree.css">
    <link rel='stylesheet' media="print" href="wp-content/themes/toolset-bootstrap/css/custom-print.css">

    <link rel='stylesheet' href="wp-content/themes/toolset-bootstrap/css/zara.css">
    <link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>
    <link href="wp-content/themes/toolset-bootstrap/css/jasny-bootstrap.min.css" rel="stylesheet" media="screen">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.matchHeight.js"></script>
    <script src="wp-content/themes/toolset-bootstrap/js/jasny-bootstrap.min.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/flexslider.css" type="text/css">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.flexslider.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.matchHeight-min.js" type="text/javascript"></script>
    <script type="text/javascript" src="wp-content/themes/toolset-bootstrap/lazyyt/lazyYT.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/lazyyt/lazyYT.css">
    <script type='text/javascript' src='//cdn.jsdelivr.net/jquery.marquee/1.3.1/jquery.marquee.min.js'></script>

</head>

<body class="page-template page-template-page-layouts page-template-page-layouts-php page page-id-286 page-parent">
    <!-- Off Canvas Menu Starts -->
        <div class="navmenu navmenu-default navmenu-fixed-right">
        <ul id="menu-menu-1" class="nav navmenu-nav">
            <li id="menu-item-20" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-2 current_page_item menu-item-20 active"><a href="index.php">Homepage</a></li>
            <li id="menu-item-656" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-656"><a href="#">About us</a>
                <ul class="sub-menu">
                    <li id="menu-item-267" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-267"><a href="company-profile.php">Company Profile</a></li>
                    <li id="menu-item-261" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-261"><a href="mission-values.php">Mission &#038; Values</a></li>
                    <li id="menu-item-280" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-280"><a href="certificate-awards.php">Certificate &#038; Awards</a></li>
                    <li id="menu-item-348" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-348"><a href="balaji-management-team.php">Management Team</a></li>
                    <li id="menu-item-339" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-339"><a href="balaji-amines-history.php">History</a></li>
                    <li id="menu-item-710" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-710"><a href="bal-presence.php">BAL&#8217;s Presence</a></li>
                </ul>
            </li>
            <li id="menu-item-400" class="menu-item menu-item-type-post_type_archive menu-item-object-product menu-item-has-children menu-item-400"><a href="category.php">Products</a>
                <ul class="sub-menu">
                    <li id="menu-item-658" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-658"><a href="amines.php">Amines</a></li>
                    <li id="menu-item-657" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-657"><a href="derivatives.php">Derivatives</a></li>
                    <li id="menu-item-659" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-659"><a href="speciality-chemicals.php">Speciality Chemicals</a></li>
                    <li id="menu-item-678" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-678"><a href="excipients.php">Pharma Excipients</a></li>
                </ul>
            </li>
            <li id="menu-item-534" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-534"><a href="investor-relations.php">Investor Relations</a></li>
            <li id="menu-item-290" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-290"><a href="careers.php">Careers</a></li>
            <li id="menu-item-299" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-299"><a href="corporate-social-responsibility.php">Corporate Social Responsibility</a></li>
            <li id="menu-item-282" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-282"><a href="contact-us.php">Contact Us</a></li>
            <li id="menu-item-307" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-307"><a href="balaji-media.php">Media</a></li>
            <li id="menu-item-711" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-711"><a href="e-brochures.php">E-Brochure</a></li>
        </ul>
    </div>    <!-- Off Canvas Menu Ends -->
    <div class="canvas">
        <!--<div class="container">-->
        <header class="full-bg black-bg" id="homepage-header">
            <div class="container">
                <div class="row">
                    <div class="col-sm-1" id="off-canvas-button">
                        <div class="navbar navbar-default">
                            <button type="button" class="navbar-toggle" data-toggle="offcanvas" data-recalc="false" data-target=".navmenu" data-canvas=".canvas">
                                <br />
                                <span class="icon-bar"></span>
                                <br />
                                <span class="icon-bar"></span>
                                <br />
                                <span class="icon-bar"></span>
                                <br />
                            </button>
                        </div>
                    </div>
                    <div class="col-sm-4 col-sm-offset-3" id="homepage-logo">
                        <p>
                        <p>
                            <a href="#"><img src="wp-content/uploads/2015/10/balaji_logo.png" alt="Balaji Almines" class="aligncenter size-full img-responsive"></a>
                        </p>
                    </div>
                </div>
            </div>
        </header>
        <div class="container-fluid">
            <div class="ddl-full-width-row row">
                <div class="col-sm-12 featured-thumbnail">
                    <div class="thumbnail">
                        <img src="wp-content/uploads/2015/10/careers_banner.jpg">
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">

                <div class="col-sm-4 page-title-div text-center col-sm-offset-4">
                    <h1>CAREERS</h1>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row" id="balaji-hero">

                <div class="col-sm-12 heading-color careers-content">
                    <p>Find out if our Vacancies match what you are looking for,Interested candidates may apply with complete details at <a href="mailto:hr@balajiamines.com">hr@balajiamines.com</a></p>
                    <h2>Work Culture :</h2>
                    <p>To meet the high benchmarks we set ourselves at Balaji Amines, we are in constant need of skilled people who can take our company to the next level. Following this thought process, we currently employ over 1200 people who have been specifically handpicked for their knowledge, skill set and diligence. We have always firmly believed that our strength lies in the talent that we can attract, retain and develop so that we are successful in building an aggressive, growth-driven company.</p>
                    <p>To fine-tune our processes in our plants we have created numerous teams and provided leadership for the same. These well-complied teams and their respective team leaders are authorized to establish internal teams for different departments like Design, Detailed Engineering, Process Control, Services and Procurement, to name a few. We follow this hierarchy in every new plant and appoint an in-house team leader who has all the knowledge and capability to provide solutions to any kind of problems.</p>
                    <p>At BAL, we concentrate on both team learning as well as individual learning and we encourage inter-departmental engagement. Also, The Design and Delivery of Training and Development (T&amp;D) programs are an inherent part of our Business Objectives and People Development programs.</p>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">

                <div class="col-sm-12">

                    <div class="jobs-title">
                        <h2>Current Job Openings:</h2></div>
                    <div class="panel-group balaji-accordian" id="accordion" role="tablist" aria-multiselectable="false">
                        <!-- wpv-loop-start -->
                        <div class="panel panel-default">
                            <!-- Job Heading Pane Starts -->
                            <div class="panel-heading" role="tab" id="job-71">
                                <h4 class="panel-title">
        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse-71" aria-expanded="false" aria-controls="collapse-71">
         Instrumentation Engineer        </a>
      </h4>
                            </div>
                            <!-- Job Heading Pane Ends -->
                            <!-- Job Content Pane Starts  -->
                            <div id="collapse-71" class="panel-collapse collapse " role="tabpanel" aria-labelledby="job-71">
                                <div class="panel-body">
                                    <!--Job description-->
                                    <div class="row">
                                        <div class="col-md-3">Job Description:</div>
                                        <div class="col-md-9">
                                            <p>Operate, maintain, and troubleshoot DCS panels, DG Sets, Transformers and field instruments.
Supervise day-to-day instrumentation and control maintenance activities.
Perform preventive and breakdown maintenance for all instrumentation and electrical systems.
Carry out Root Cause Analysis for failures and implement corrective actions.
Maintain and calibrate instruments like control valves, transmitters, Weighing Machines, flow/level/pressure/temperature meters.
Execute plant start-up, shutdown, and handle emergencies independently.
Prepare and maintain SOPs for instrument calibration and maintenance.
Ensure compliance with legal metrology and licensing related to plant instruments.</p>
                                        </div>
                                    </div>
                                    <!-- Locations -->
                                    <div class="row">
                                        <div class="col-md-3">Location:</div>
                                        <div class="col-md-9">MIDC CHINCHOLI Solapur	</div>
                                    </div>
                                    <!-- Designation -->
                                    <div class="row">
                                        <div class="col-md-3">Designation:</div>
                                        <div class="col-md-9">Instrumentation Engineer</div>
                                    </div>
                                    <!-- Qualification -->
                                    <div class="row">
                                        <div class="col-md-3">Qualification:</div>
                                        <div class="col-md-9">Diploma - Instrumentation / Electronics / E& TC etc.</div>
                                    </div>

                                    <!-- Skills -->
                                    <div class="row">
                                        <div class="col-md-3">Skills:</div>
                                        <div class="col-md-9">Hands-on knowledge of DCS, DG Sets, ESD systems, and field instruments.</div>
                                    </div>

                                    <!-- Experience -->
                                    <div class="row">
                                        <div class="col-md-3">Experience:</div>
                                        <div class="col-md-9">1 to 4 years </div>
                                    </div>

                                    <!-- No. of Positions -->
                                    <div class="row">
                                        <div class="col-md-3">No. of Positions:</div>
                                        <div class="col-md-9">2</div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12"><a class="iframe" href="mailto:hr@balajiamines.com">apply with complete details at hr@balajiamines.com</a></div>
                                    </div>

                                </div>
                            </div>

                            <!-- Job Content Pane Ends -->

                        </div>
						
	                        <div class="panel panel-default">
                            <!-- Job Heading Pane Starts -->
                            <div class="panel-heading" role="tab" id="job-72">
                                <h4 class="panel-title">
        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse-72" aria-expanded="false" aria-controls="collapse-72">
         ETP Operator        </a>
      </h4>
                            </div>
                            <!-- Job Heading Pane Ends -->
                            <!-- Job Content Pane Starts  -->
                            <div id="collapse-72" class="panel-collapse collapse " role="tabpanel" aria-labelledby="job-72">
                                <div class="panel-body">
                                    <!--Job description-->
                                    <div class="row">
                                        <div class="col-md-3">Job Description:</div>
                                        <div class="col-md-9">
                                            <p>•	Operate and monitor all units of the Effluent Treatment Plant (aeration tank, clarifier, fil-ter press, sludge drying bed, etc.). and disposal of liquid and gaseous industrial waste.
•	Conduct routine checks of pH, TDS, COD, BOD, MLSS, and other key wastewater pa-rameters.
•	Record daily readings and maintain a logbook of plant operations.
•	Ensure timely dosing of chemicals like coagulants, flocculants, neutralizing agents, etc.
•	Start and stop pumps, blowers, agitators, and other equipment as per operational require-ments.
•	Coordinate with the laboratory for analysis of effluent samples and maintain records ac-cordingly.
•	Conduct backwashing and cleaning of filters and maintain overall hygiene of the plant.
•	Perform minor maintenance and troubleshoot issues with ETP machinery.
•	Follow SOPs and safety guidelines to avoid any accidents or environmental violations.
•	Report deviations or abnormalities immediately to the supervisor.
•	Assist during audits and inspections by statutory authorities like the Pollution Control Board (PCB)</p>
                                        </div>
                                    </div>
                                    <!-- Locations -->
                                    <div class="row">
                                        <div class="col-md-3">Location:</div>
                                        <div class="col-md-9">Unit - 1 Tamalwadi  and MIDC Chincholi Solapur	</div>
                                    </div>
                                    <!-- Designation -->
                                    <div class="row">
                                        <div class="col-md-3">Designation:</div>
                                        <div class="col-md-9">ETP Operator</div>
                                    </div>
                                    <!-- Qualification -->
                                    <div class="row">
                                        <div class="col-md-3">Qualification:</div>
                                        <div class="col-md-9">B.Sc / M.Sc Chemistry /  Diploma in Chemical / Environmental Engineering or relevant field</div>
                                    </div>

                                    <!-- Skills -->
                                    <div class="row">
                                        <div class="col-md-3">Skills:</div>
                                        <div class="col-md-9">Knowledge of ETP processes (primary, secondary, tertiary treatment) and Basic understanding of pollution control norms (MPCB)
</div>
                                    </div>

                                    <!-- Experience -->
                                    <div class="row">
                                        <div class="col-md-3">Experience:</div>
                                        <div class="col-md-9">2 to 5 years </div>
                                    </div>

                                    <!-- No. of Positions -->
                                    <div class="row">
                                        <div class="col-md-3">No. of Positions:</div>
                                        <div class="col-md-9">2</div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12"><a class="iframe" href="mailto:hr@balajiamines.com">apply with complete details at hr@balajiamines.com</a></div>
                                    </div>

                                </div>
                            </div>

                            <!-- Job Content Pane Ends -->

                        </div>
						
	                        <div class="panel panel-default">
                            <!-- Job Heading Pane Starts -->
                            <div class="panel-heading" role="tab" id="job-73">
                                <h4 class="panel-title">
        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse-73" aria-expanded="false" aria-controls="collapse-73">
         Panel Operator - Production        </a>
      </h4>
                            </div>
                            <!-- Job Heading Pane Ends -->
                            <!-- Job Content Pane Starts  -->
                            <div id="collapse-73" class="panel-collapse collapse " role="tabpanel" aria-labelledby="job-73">
                                <div class="panel-body">
                                    <!--Job description-->
                                    <div class="row">
                                        <div class="col-md-3">Job Description:</div>
                                        <div class="col-md-9">
                                            <p>The DCS Panel Operator is responsible for the safe, efficient, and reliable operation of plant processes through a Distributed Control System (DCS) in a hazardous chemicals manufacturing environment. The role requires continuous monitoring of process parameters, prompt response to alarms, and close coordination with field operators to ensure smooth operations in compliance with safety and environmental standards</p>
                                        </div>
                                    </div>
                                    <!-- Locations -->
                                    <div class="row">
                                        <div class="col-md-3">Location:</div>
                                        <div class="col-md-9">MIDC CHINCHOLI Solapur	</div>
                                    </div>
                                    <!-- Designation -->
                                    <div class="row">
                                        <div class="col-md-3">Designation:</div>
                                        <div class="col-md-9">Panel Operator - Production</div>
                                    </div>
                                    <!-- Qualification -->
                                    <div class="row">
                                        <div class="col-md-3">Qualification:</div>
                                        <div class="col-md-9">Diploma / B.Sc. in Chemical Engineering / Chemistry or related field</div>
                                    </div>

                                    <!-- Skills -->
                                    <div class="row">
                                        <div class="col-md-3">Skills:</div>
                                        <div class="col-md-9">DCS, Continuous Process Plant Operation, Chemicals Manufacturing</div>
                                    </div>

                                    <!-- Experience -->
                                    <div class="row">
                                        <div class="col-md-3">Experience:</div>
                                        <div class="col-md-9">2 to 4 years of experience in a continuous chemical plant, preferably involving highly hazardous chemicals. Hands on experience in DCS operation .</div>
                                    </div>

                                    <!-- No. of Positions -->
                                    <div class="row">
                                        <div class="col-md-3">No. of Positions:</div>
                                        <div class="col-md-9">4</div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12"><a class="iframe" href="mailto:hr@balajiamines.com">apply with complete details at hr@balajiamines.com</a></div>
                                    </div>

                                </div>
                            </div>

                            <!-- Job Content Pane Ends -->

                        </div>
						
	                        <div class="panel panel-default">
                            <!-- Job Heading Pane Starts -->
                            <div class="panel-heading" role="tab" id="job-74">
                                <h4 class="panel-title">
        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse-74" aria-expanded="false" aria-controls="collapse-74">
         Field Operator, (B.Sc - Chemistry is mandatory)         </a>
      </h4>
                            </div>
                            <!-- Job Heading Pane Ends -->
                            <!-- Job Content Pane Starts  -->
                            <div id="collapse-74" class="panel-collapse collapse " role="tabpanel" aria-labelledby="job-74">
                                <div class="panel-body">
                                    <!--Job description-->
                                    <div class="row">
                                        <div class="col-md-3">Job Description:</div>
                                        <div class="col-md-9">
                                            <p>Monitor process parameters and ensure adherence to defined operating ranges, Carry out regular field checks and record observations as per log sheet formats. Maintain cleanliness and housekeeping in the assigned work area. Report equipment faults, process deviations, or unsafe conditions to the shift in-charge promptly.</p>
                                        </div>
                                    </div>
                                    <!-- Locations -->
                                    <div class="row">
                                        <div class="col-md-3">Location:</div>
                                        <div class="col-md-9">Solapur, MIDC CHINCHOLI	</div>
                                    </div>
                                    <!-- Designation -->
                                    <div class="row">
                                        <div class="col-md-3">Designation:</div>
                                        <div class="col-md-9">Field Operator, (B.Sc - Chemistry is mandatory) </div>
                                    </div>
                                    <!-- Qualification -->
                                    <div class="row">
                                        <div class="col-md-3">Qualification:</div>
                                        <div class="col-md-9">B.Sc (Chemistry Mandatory)</div>
                                    </div>

                                    <!-- Skills -->
                                    <div class="row">
                                        <div class="col-md-3">Skills:</div>
                                        <div class="col-md-9">Understanding of chemical processes and unit operations</div>
                                    </div>

                                    <!-- Experience -->
                                    <div class="row">
                                        <div class="col-md-3">Experience:</div>
                                        <div class="col-md-9">0-2 years (Freshers and experienced candidates are welcome)</div>
                                    </div>

                                    <!-- No. of Positions -->
                                    <div class="row">
                                        <div class="col-md-3">No. of Positions:</div>
                                        <div class="col-md-9">6</div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12"><a class="iframe" href="mailto:hr@balajiamines.com">apply with complete details at hr@balajiamines.com</a></div>
                                    </div>

                                </div>
                            </div>

                            <!-- Job Content Pane Ends -->

                        </div>
						
	                        <div class="panel panel-default">
                            <!-- Job Heading Pane Starts -->
                            <div class="panel-heading" role="tab" id="job-75">
                                <h4 class="panel-title">
        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse-75" aria-expanded="false" aria-controls="collapse-75">
         Environment Officer        </a>
      </h4>
                            </div>
                            <!-- Job Heading Pane Ends -->
                            <!-- Job Content Pane Starts  -->
                            <div id="collapse-75" class="panel-collapse collapse " role="tabpanel" aria-labelledby="job-75">
                                <div class="panel-body">
                                    <!--Job description-->
                                    <div class="row">
                                        <div class="col-md-3">Job Description:</div>
                                        <div class="col-md-9">
                                            <p>We are looking for a Masters in Environmental Science with hands-on experience in the chemicals industry. This role will manage end-to-end environmental compliance, including statutory permits (CTE, CTO, Hazardous Waste), Environmental Impact Assessments (EIA/EC), audits (ISO 14001 & 45001), and hazardous/solid waste management. this role will involve liaising with government authorities, supervising emissions monitoring (OCEMS), preparing compliance reports, and ensuring our operations meet the highest environmental standards</p>
                                        </div>
                                    </div>
                                    <!-- Locations -->
                                    <div class="row">
                                        <div class="col-md-3">Location:</div>
                                        <div class="col-md-9">Solapur	</div>
                                    </div>
                                    <!-- Designation -->
                                    <div class="row">
                                        <div class="col-md-3">Designation:</div>
                                        <div class="col-md-9">Environment Officer</div>
                                    </div>
                                    <!-- Qualification -->
                                    <div class="row">
                                        <div class="col-md-3">Qualification:</div>
                                        <div class="col-md-9">Master’s in Environmental Science with 2 to 3 years’ experience in the chemicals industry</div>
                                    </div>

                                    <!-- Skills -->
                                    <div class="row">
                                        <div class="col-md-3">Skills:</div>
                                        <div class="col-md-9">Statutory permits (CTE, CTO/CCA), Hazardous and Solid Waste Management, Audits, Familiarity with environmental laws, MPCB, CPCB, and MoEF/SEIAA guidelines.</div>
                                    </div>

                                    <!-- Experience -->
                                    <div class="row">
                                        <div class="col-md-3">Experience:</div>
                                        <div class="col-md-9">2 to 3 years’ experience in the chemicals industry.</div>
                                    </div>

                                    <!-- No. of Positions -->
                                    <div class="row">
                                        <div class="col-md-3">No. of Positions:</div>
                                        <div class="col-md-9">2</div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12"><a class="iframe" href="mailto:hr@balajiamines.com">apply with complete details at hr@balajiamines.com</a></div>
                                    </div>

                                </div>
                            </div>

                            <!-- Job Content Pane Ends -->

                        </div>
						
	                        <div class="panel panel-default">
                            <!-- Job Heading Pane Starts -->
                            <div class="panel-heading" role="tab" id="job-76">
                                <h4 class="panel-title">
        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse-76" aria-expanded="false" aria-controls="collapse-76">
         Security Guard        </a>
      </h4>
                            </div>
                            <!-- Job Heading Pane Ends -->
                            <!-- Job Content Pane Starts  -->
                            <div id="collapse-76" class="panel-collapse collapse " role="tabpanel" aria-labelledby="job-76">
                                <div class="panel-body">
                                    <!--Job description-->
                                    <div class="row">
                                        <div class="col-md-3">Job Description:</div>
                                        <div class="col-md-9">
                                            <p>Patrolling premises, monitoring & controlling access, and responding to alarms or emergencies, ensuring the safety of people and property, preventing theft and  damage, and maintaining security logs.</p>
                                        </div>
                                    </div>
                                    <!-- Locations -->
                                    <div class="row">
                                        <div class="col-md-3">Location:</div>
                                        <div class="col-md-9">Solapur	</div>
                                    </div>
                                    <!-- Designation -->
                                    <div class="row">
                                        <div class="col-md-3">Designation:</div>
                                        <div class="col-md-9">Security Guard</div>
                                    </div>
                                    <!-- Qualification -->
                                    <div class="row">
                                        <div class="col-md-3">Qualification:</div>
                                        <div class="col-md-9">Graduation -not mandatory</div>
                                    </div>

                                    <!-- Skills -->
                                    <div class="row">
                                        <div class="col-md-3">Skills:</div>
                                        <div class="col-md-9">Patrolling, Security work</div>
                                    </div>

                                    <!-- Experience -->
                                    <div class="row">
                                        <div class="col-md-3">Experience:</div>
                                        <div class="col-md-9">1-3 years</div>
                                    </div>

                                    <!-- No. of Positions -->
                                    <div class="row">
                                        <div class="col-md-3">No. of Positions:</div>
                                        <div class="col-md-9">4</div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12"><a class="iframe" href="mailto:hr@balajiamines.com">apply with complete details at hr@balajiamines.com</a></div>
                                    </div>

                                </div>
                            </div>

                            <!-- Job Content Pane Ends -->

                        </div>
						
	                        <div class="panel panel-default">
                            <!-- Job Heading Pane Starts -->
                            <div class="panel-heading" role="tab" id="job-77">
                                <h4 class="panel-title">
        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse-77" aria-expanded="false" aria-controls="collapse-77">
         Helper        </a>
      </h4>
                            </div>
                            <!-- Job Heading Pane Ends -->
                            <!-- Job Content Pane Starts  -->
                            <div id="collapse-77" class="panel-collapse collapse " role="tabpanel" aria-labelledby="job-77">
                                <div class="panel-body">
                                    <!--Job description-->
                                    <div class="row">
                                        <div class="col-md-3">Job Description:</div>
                                        <div class="col-md-9">
                                            <p>Assisting in production / laboratory tasks, performing general maintenance and housekeeping work, and adhering to safety protocols. </p>
                                        </div>
                                    </div>
                                    <!-- Locations -->
                                    <div class="row">
                                        <div class="col-md-3">Location:</div>
                                        <div class="col-md-9">Solapur	</div>
                                    </div>
                                    <!-- Designation -->
                                    <div class="row">
                                        <div class="col-md-3">Designation:</div>
                                        <div class="col-md-9">Helper</div>
                                    </div>
                                    <!-- Qualification -->
                                    <div class="row">
                                        <div class="col-md-3">Qualification:</div>
                                        <div class="col-md-9">10th Class - not mandatory</div>
                                    </div>

                                    <!-- Skills -->
                                    <div class="row">
                                        <div class="col-md-3">Skills:</div>
                                        <div class="col-md-9">Follow instructions</div>
                                    </div>

                                    <!-- Experience -->
                                    <div class="row">
                                        <div class="col-md-3">Experience:</div>
                                        <div class="col-md-9">0-1 year</div>
                                    </div>

                                    <!-- No. of Positions -->
                                    <div class="row">
                                        <div class="col-md-3">No. of Positions:</div>
                                        <div class="col-md-9">4</div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12"><a class="iframe" href="mailto:hr@balajiamines.com">apply with complete details at hr@balajiamines.com</a></div>
                                    </div>

                                </div>
                            </div>

                            <!-- Job Content Pane Ends -->

                        </div>
						
							



                        
                    </div>
                </div>
            </div>
        </div>
        <footer class="full-bg " id="footer">

            <div class="container">
                <div class="row">

                    <div class="col-sm-4  widget-cell" id="footer-widget-1">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">ABOUT</h3>
                            <div class="menu-overview-footer-container">
                                <ul id="menu-overview-footer" class="menu">
                                    <li id="menu-item-412" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-412"><a href="company-profile.php">Company Profile</a></li>
                                    <li id="menu-item-415" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-415"><a href="mission-values.php">Mission &#038; Values</a></li>
                                    <li id="menu-item-414" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-414"><a href="certificate-awards.php">Certificate &#038; Awards</a></li>
                                    <li id="menu-item-413" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-413"><a href="balaji-management-team.php">Management Team</a></li>
                                    <li id="menu-item-479" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-479"><a href="balaji-amines-history.php">History</a></li>
                                    <li id="menu-item-709" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-709"><a href="bal-presence.php">BAL&#8217;s Presence</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4  widget-cell">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">PRODUCTS</h3>
                            <div class="menu-overview-footer-1-container">
                                <ul id="menu-overview-footer-1" class="menu">
                                    <li id="menu-item-417" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-417"><a href="amines.php">Amines</a></li>
                                    <li id="menu-item-416" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-416"><a href="derivatives.php">Derivatives</a></li>
                                    <li id="menu-item-418" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-418"><a href="speciality-chemicals.php">Speciality Chemicals</a></li>
                                    <li id="menu-item-679" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-679"><a href="excipients.php">Pharma Excipients</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4  widget-cell">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">OTHERS</h3>
                            <div class="menu-footer3-container">
                                <ul id="menu-footer3" class="menu">
                                    <li id="menu-item-655" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-655"><a href="investor-relations.php">Investor Relations</a></li>
                                    <li id="menu-item-420" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-286 current_page_item menu-item-420 active"><a href="careers.php">Careers</a></li>
                                    <li id="menu-item-421" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-421"><a href="corporate-social-responsibility.php">Corporate Social Responsibility</a></li>
                                    <li id="menu-item-713" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-713"><a href="e-brochures.php">E-Brochure</a></li>
                                    <li id="menu-item-423" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-423"><a href="balaji-media.php">Media</a></li>
                                    <li id="menu-item-422" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-422"><a href="contact-us.php">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-1  widget-cell col-sm-offset-1">
                        <div class="widget widget_text">
                            <div class="textwidget"></div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="row">
                            <div class="col-sm-12" id="social-media-icons"></div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 col-sm-offset-6"></div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
		<div class="container-fluid">
            <div class="ddl-full-width-row row">
                <div class="col-sm-12 copyright-footer">
                    <p>copyright © balaji Amines 2025 Developed By <a href="http://katareinfo.com/">Katrare Informatics</a></p>
                </div>
            </div>
        </div>    </div>
    <style type="text/css" media="screen">
        /* ----------------------------------------- */
        /* View: Job Opening Listing - start */
        /* ----------------------------------------- */
        
        .balaji-accordian > .panel-default {
            border-radius: 0px !important;
        }
        /* ----------------------------------------- */
        /* View: Job Opening Listing - end */
        /* ----------------------------------------- */
    </style>
    <script type='text/javascript' src='wp-content/themes/toolset-bootstrap/bootstrap3/js/bootstrap.min.js?ver=3.3.4'></script>
    <script type='text/javascript' src='wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='wp-includes/js/jquery/ui/datepicker.min.js?ver=1.11.4'></script>

    <script type='text/javascript' src='wp-includes/js/mediaelement/mediaelement-and-player.min.js?ver=2.22.0'></script>
    <script type='text/javascript' src='wp-includes/js/mediaelement/wp-mediaelement.min.js?ver=4.7.3'></script>
    <script type='text/javascript' src='wp-includes/js/underscore.min.js?ver=1.8.3'></script>

    <script type='text/javascript' src='wp-includes/js/wp-util.min.js?ver=4.7.3'></script>
    <script type='text/javascript' src='wp-includes/js/backbone.min.js?ver=1.2.3'></script>
    <script type='text/javascript' src='wp-includes/js/mediaelement/wp-playlist.min.js?ver=4.7.3'></script>

    <script type='text/javascript' src='wp-content/plugins/wp-views/embedded/res/js/wpv-pagination-embedded.js?ver=1.10'></script>
    <script type='text/javascript' src='wp-includes/js/wp-embed.min.js?ver=4.7.3'></script>

    <script type="text/javascript">
        //-----------------------------------------
        // View: Job Opening Listing - start
        //-----------------------------------------
        jQuery("a.iframe").fancybox();
        //-----------------------------------------
        // View: Job Opening Listing - end
        //-----------------------------------------
    </script>

    <script>
        jQuery(window).scroll(function() {
            if (jQuery(document).scrollTop() > 50) {
                jQuery('header').addClass('shrink');
            } else {
                jQuery('header').removeClass('shrink');
            }
        });

        /*Youtube video*/

        jQuery('.js-lazyYT').lazyYT();

        /** Stop playing youtube video when page scrolls */

        jQuery(document).on('scroll', function() {
            var scrollTop = jQuery(window).scrollTop();
            if (scrollTop > pos.top + 315) {
                player.stopVideo();
            }
        })
    </script>
    <script>
        /* moving object */
        jQuery('.marquee').marquee({
            //speed in milliseconds of the marquee
            duration: 6000,
            //gap in pixels between the tickers
            gap: 1500,
            //time in milliseconds before the marquee will start animating
            delayBeforeStart: 0,
            //'left' or 'right'
            direction: 'right',
            //true or false - should the marquee be duplicated to show an effect of continues flow
            duplicated: true
        });
    </script>
    <script>
        jQuery(document).ready(function() {

            /* Apply fancybox to multiple items */

            jQuery("a.balaji-products").fancybox({
                'transitionIn': 'elastic',
                'transitionOut': 'elastic',
                'speedIn': 600,
                'speedOut': 200,
                'overlayShow': false
            });

            jQuery('.member-mug-shot').on('click', function() {
                jQuery('.collapse').collapse('hide');
            })

        });
    </script>
    <script>
        (function(jQuery) {
            jQuery(document).ready(function() {
                jQuery(".video-button").click(function() {
                    jQuery(".video-embed").css({
                        "opacity": "1",
                        "display": "block"
                    });
                    jQuery(".video-embed")[0].src += "&autoplay=1";
                    jQuery(this).unbind("click");
                });
            });
        })(jQuery)
    </script>
    <script>
        jQuery(document).ready(function() {

            jQuery('.fancybox').fancybox({
                beforeShow: function() {
                    this.title = jQuery(this.element).data("caption");
                }
            });

            jQuery("a#single_image-popup").fancybox();

        });
    </script>
    <script>
        jQuery(window).load(function() {
            jQuery('#single_image-popup').fancybox({
                beforeLoad: function() {
                    this.title = jQuery(this.element).find('img').attr('alt');
                }

            });

            jQuery('#single_image-popup').fancybox({
                'titleFromAlt': true,
                'titlePosition': 'inside'

            });

            jQuery("a#single_image-popup").trigger('click');
        });
    </script>
    <script>
        function myFunction() {
            window.print();
        }
    </script>
</body>

</html>