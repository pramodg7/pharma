<!DOCTYPE html>
<html lang="en-US" class="no-js">
<head>
    <meta charset="UTF-8" />
	<meta name="author" content="Balaji Amines" />
	<meta name="keywords" content=" balaji , balaji amines, balaji amines solapur, Chemical Manufacturers in India, Chemical Manufacturers India, Industrial Chemicals Manufacturers, Industrial Chemicals Manufacturers in India Chemical manufacturing company in india, Chemical manufacturing company in Solapur, Chemical manufacturing company, methyl, Chemical Manufacturer,hydrochloride derivatives, industrial chemicals manufacturers, industrial chemicals suppliers, industrial chemicals india, industrial chemicals exporters, industrial chemicals manufacturer, industrial chemicals supplier, industrial chemicals exporter, industrial chemicals from india, industrial chemicals wholesale, industrial chemicals in india">
	<meta name="description"  content="Manufacturer of methyl and ethyl amines and their amide and hydrochloride derivatives, located in India.  Chemical manufacturing company in india">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Balaji &ndash; Certificate &#038; Awards</title>
    <link rel="shortcut icon" href="wp-content/themes/toolset-bootstrap/favicon.ico">
    <script type="text/javascript">
        window._wpemojiSettings = {
            "baseUrl": "https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/72x72\/",
            "ext": ".png",
            "svgUrl": "https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/svg\/",
            "svgExt": ".svg",
            "source": {
                "concatemoji": "http:\/\/www.balajiamines.in\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.7.3"
            }
        };
        ! function(a, b, c) {
            function d(a) {
                var b, c, d, e, f = String.fromCharCode;
                if (!k || !k.fillText) return !1;
                switch (k.clearRect(0, 0, j.width, j.height), k.textBaseline = "top", k.font = "600 32px Arial", a) {
                    case "flag":
                        return k.fillText(f(55356, 56826, 55356, 56819), 0, 0), !(j.toDataURL().length < 3e3) && (k.clearRect(0, 0, j.width, j.height), k.fillText(f(55356, 57331, 65039, 8205, 55356, 57096), 0, 0), b = j.toDataURL(), k.clearRect(0, 0, j.width, j.height), k.fillText(f(55356, 57331, 55356, 57096), 0, 0), c = j.toDataURL(), b !== c);
                    case "emoji4":
                        return k.fillText(f(55357, 56425, 55356, 57341, 8205, 55357, 56507), 0, 0), d = j.toDataURL(), k.clearRect(0, 0, j.width, j.height), k.fillText(f(55357, 56425, 55356, 57341, 55357, 56507), 0, 0), e = j.toDataURL(), d !== e
                }
                return !1
            }

            function e(a) {
                var c = b.createElement("script");
                c.src = a, c.defer = c.type = "text/javascript", b.getElementsByTagName("head")[0].appendChild(c)
            }
            var f, g, h, i, j = b.createElement("canvas"),
                k = j.getContext && j.getContext("2d");
            for (i = Array("flag", "emoji4"), c.supports = {
                    everything: !0,
                    everythingExceptFlag: !0
                }, h = 0; h < i.length; h++) c.supports[i[h]] = d(i[h]), c.supports.everything = c.supports.everything && c.supports[i[h]], "flag" !== i[h] && (c.supports.everythingExceptFlag = c.supports.everythingExceptFlag && c.supports[i[h]]);
            c.supports.everythingExceptFlag = c.supports.everythingExceptFlag && !c.supports.flag, c.DOMReady = !1, c.readyCallback = function() {
                c.DOMReady = !0
            }, c.supports.everything || (g = function() {
                c.readyCallback()
            }, b.addEventListener ? (b.addEventListener("DOMContentLoaded", g, !1), a.addEventListener("load", g, !1)) : (a.attachEvent("onload", g), b.attachEvent("onreadystatechange", function() {
                "complete" === b.readyState && c.readyCallback()
            })), f = c.source || {}, f.concatemoji ? e(f.concatemoji) : f.wpemoji && f.twemoji && (e(f.twemoji), e(f.wpemoji)))
        }(window, document, window._wpemojiSettings);
    </script>
    <style type="text/css">
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 .07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
		table {
  border-collapse: separate;
  border-spacing: 0;
}
th,
td {
  padding: 5px 5px !important;
}
thead {
  background: #13237a;
  color: #fff;
}
th {
  font-weight: bold;
}
tbody tr:nth-child(even) {
  background: #f0f0f2;
}
td {
  border-bottom: 1px solid #cecfd5;
  border-right: 1px solid #cecfd5;
}
td:first-child {
  border-left: 1px solid #cecfd5;
}
.btn {
    display: inline-block;
    padding: 0px 5px !important;
    margin-bottom: 0;
    font-size: 14px;
    font-weight: 400;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 4px;
}
.btn-success {
    background-color: #046a0d;
    border-color: #046a0d;
    color: #FFFFFF;
}
    </style>
    <link rel='stylesheet' id='formidable-css' href='wp-content/uploads/formidable/css/formidablepro.css?ver=2.03.03' type='text/css' media='all' />
    <link rel='stylesheet' id='wp_ddl_layout_fe_css-css' href='wp-content/uploads/ddl-layouts-tmp/d41d8cd98f00b204e9800998ecf8427e.css?ver=1.3.2' type='text/css' media='screen' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3/css/bootstrap.min.css?ver=3.3.4' type='text/css' media='all' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_theme_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3/css/bootstrap-theme.min.css' type='text/css' media='all' />
    <link rel='stylesheet' id='toolset-bootstrap-theme-style-css' href='wp-content/themes/toolset-bootstrap/style.css?ver=1.8' type='text/css' media='all' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_adjustment_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3_adjustment.css' type='text/css' media='all' />
    <link rel='stylesheet' id='menu-cells-front-end-css' href='wp-content/plugins/layouts/resources/css/cell-menu-css.css?ver=4.7.3' type='text/css' media='screen' />
    <link rel='stylesheet' id='ddl-front-end-css' href='wp-content/plugins/layouts/resources/css/ddl-front-end.css?ver=4.7.3' type='text/css' media='screen' />
    <link rel='stylesheet' id='toolset-common-css' href='wp-content/plugins/layouts/toolset/toolset-common/res/css/toolset-common.css?ver=4.7.3' type='text/css' media='screen' />
    <link rel='stylesheet' id='wptoolset-field-datepicker-css' href='wp-content/plugins/wp-views/embedded/common/toolset-forms/css/wpt-jquery-ui/datepicker.css?ver=1.10' type='text/css' media='all' />
    <link rel='stylesheet' id='mediaelement-css' href='wp-includes/js/mediaelement/mediaelementplayer.min.css?ver=2.22.0' type='text/css' media='all' />
    <link rel='stylesheet' id='wp-mediaelement-css' href='wp-includes/js/mediaelement/wp-mediaelement.min.css?ver=4.7.3' type='text/css' media='all' />
    <link rel='stylesheet' id='views-pagination-style-css' href='wp-content/plugins/wp-views/embedded/res/css/wpv-pagination.css?ver=1.10' type='text/css' media='all' />
    <script type='text/javascript' src='wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
    <script type='text/javascript' src='wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var DDLayout_fe_settings = {
            "DDL_JS": {
                "css_framework": "bootstrap-3",
                "DEBUG": false
            }
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='wp-content/plugins/layouts/resources/js/ddl-layouts-frontend.js?ver=1.3.2'></script>
 <style type="text/css">
        .recentcomments a {
            display: inline !important;
            padding: 0 !important;
            margin: 0 !important;
        }
    </style>
	<link rel="stylesheet" href="css/lightbox.css">
	<script src="js/lightbox.js"></script>
	<link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/owl.carousel.css">
	<link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/owl.theme.css">
	<script src="wp-content/themes/toolset-bootstrap/js/owl.carousel.js"></script>
	<script type="text/javascript" src="wp-content/themes/toolset-bootstrap/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/fancybox/jquery.fancybox-1.3.4.css" type="text/css" media="screen" />
	<link href='https://fonts.googleapis.com/css?family=Khand:400,300,500,600,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,100italic,100,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link rel='stylesheet' href="wp-content/themes/toolset-bootstrap/css/mediatree.css">
    <link rel='stylesheet' media="print" href="wp-content/themes/toolset-bootstrap/css/custom-print.css">
    <link rel='stylesheet' href="wp-content/themes/toolset-bootstrap/css/zara.css">
    <link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>
    <link href="wp-content/themes/toolset-bootstrap/css/jasny-bootstrap.min.css" rel="stylesheet" media="screen">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.matchHeight.js"></script>
    <script src="wp-content/themes/toolset-bootstrap/js/jasny-bootstrap.min.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/flexslider.css" type="text/css">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.flexslider.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.matchHeight-min.js" type="text/javascript"></script>
    <script type="text/javascript" src="wp-content/themes/toolset-bootstrap/lazyyt/lazyYT.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/lazyyt/lazyYT.css">
    <script type='text/javascript' src='//cdn.jsdelivr.net/jquery.marquee/1.3.1/jquery.marquee.min.js'></script>
</head>
<body class="page-template page-template-page-layouts page-template-page-layouts-php page page-id-231">
    <!-- Off Canvas Menu Starts -->
    <div class="navmenu navmenu-default navmenu-fixed-right">
        <ul id="menu-menu-1" class="nav navmenu-nav">
            <li id="menu-item-20" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-2 current_page_item menu-item-20 active"><a href="index.php">Homepage</a></li>
            <li id="menu-item-656" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-656"><a href="#">About us</a>
                <ul class="sub-menu">
                    <li id="menu-item-267" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-267"><a href="company-profile.php">Company Profile</a></li>
                    <li id="menu-item-261" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-261"><a href="mission-values.php">Mission &#038; Values</a></li>
                    <li id="menu-item-280" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-280"><a href="certificate-awards.php">Certificate &#038; Awards</a></li>
                    <li id="menu-item-348" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-348"><a href="balaji-management-team.php">Management Team</a></li>
                    <li id="menu-item-339" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-339"><a href="balaji-amines-history.php">History</a></li>
                    <li id="menu-item-710" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-710"><a href="bal-presence.php">BAL&#8217;s Presence</a></li>
                </ul>
            </li>
            <li id="menu-item-400" class="menu-item menu-item-type-post_type_archive menu-item-object-product menu-item-has-children menu-item-400"><a href="category.php">Products</a>
                <ul class="sub-menu">
                    <li id="menu-item-658" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-658"><a href="amines.php">Amines</a></li>
                    <li id="menu-item-657" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-657"><a href="derivatives.php">Derivatives</a></li>
                    <li id="menu-item-659" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-659"><a href="speciality-chemicals.php">Speciality Chemicals</a></li>
                    <li id="menu-item-678" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-678"><a href="excipients.php">Pharma Excipients</a></li>
                </ul>
            </li>
            <li id="menu-item-534" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-534"><a href="investor-relations.php">Investor Relations</a></li>
            <li id="menu-item-290" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-290"><a href="careers.php">Careers</a></li>
            <li id="menu-item-299" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-299"><a href="corporate-social-responsibility.php">Corporate Social Responsibility</a></li>
            <li id="menu-item-282" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-282"><a href="contact-us.php">Contact Us</a></li>
            <li id="menu-item-307" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-307"><a href="balaji-media.php">Media</a></li>
            <li id="menu-item-711" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-711"><a href="e-brochures.php">E-Brochure</a></li>
        </ul>
    </div>    <!-- Off Canvas Menu Ends -->
    <div class="canvas">
        <!--<div class="container">-->
        <header class="full-bg black-bg" id="homepage-header">
            <div class="container">
                <div class="row">
                    <div class="col-sm-1" id="off-canvas-button">
                        <div class="navbar navbar-default">
                            <button type="button" class="navbar-toggle" data-toggle="offcanvas" data-recalc="false" data-target=".navmenu" data-canvas=".canvas">
                                <br />
                                <span class="icon-bar"></span>
                                <br />
                                <span class="icon-bar"></span>
                                <br />
                                <span class="icon-bar"></span>
                                <br />
                            </button>
                        </div>
                    </div>
                    <div class="col-sm-4 col-sm-offset-3" id="homepage-logo">
                        <p>
                            <!--<a href="http://www.balajiamines.in/"><img src="wp-content/uploads/2015/09/modernxd-logo.png" alt="Modern XD" class="aligncenter size-full img-responsive"  ></a>--></p>
                        <p>
                            <a href=""><img src="wp-content/uploads/2015/10/balaji_logo.png" alt="Balaji Almines" class="aligncenter size-full img-responsive"></a>
                        </p>
                    </div>
                </div>
            </div>
        </header>
        <div class="container-fluid">
            <div class="ddl-full-width-row row">
                <div class="col-sm-12 featured-thumbnail">
                    <div class="thumbnail">
                        <img src="wp-content/uploads/2015/10/banner1.jpg">
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">

                <div class="col-sm-4 page-title-div text-center col-sm-offset-4" id="technical-support-title">
                    <h1>CERTIFICATE &amp; AWARDS</h1>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row report-row-wrapper">

                <div class="col-sm-12 report-download heading-color">
                  
<div class="row" id="company-sec-row">
                                <div style="position: relative; overflow: hidden; height: 502px; " class="col-sm-4 company-image" >
								<div style="width: 332px; height: 262.24px; position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
								 <div class="thumbnail" >
                                        <a class="btn " style="    border: 5px solid #13237a;" href="awards/350_1506061616.jpg" data-lightbox="roadtrip"><img  src="awards/350_1506061616.jpg"></a>
                                    </div>
									<h5>WHO GMP Certificate</h5>
                                </div>
								</div>
	                                <div style="position: relative; overflow: hidden; height: 502px; " class="col-sm-4 company-image" >
								<div style="width: 332px; height: 262.24px; position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
								 <div class="thumbnail" >
                                        <a class="btn " style="    border: 5px solid #13237a;" href="awards/350_1506061649.jpg" data-lightbox="roadtrip"><img  src="awards/350_1506061649.jpg"></a>
                                    </div>
									<h5>REACH Pre-Registration</h5>
                                </div>
								</div>
	                                <div style="position: relative; overflow: hidden; height: 502px; " class="col-sm-4 company-image" >
								<div style="width: 332px; height: 262.24px; position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
								 <div class="thumbnail" >
                                        <a class="btn " style="    border: 5px solid #13237a;" href="awards/350_1506061674.jpg" data-lightbox="roadtrip"><img  src="awards/350_1506061674.jpg"></a>
                                    </div>
									<h5>Certificate of Merit – CHEMEXCIL</h5>
                                </div>
								</div>
	                                <div style="position: relative; overflow: hidden; height: 502px; " class="col-sm-4 company-image" >
								<div style="width: 332px; height: 262.24px; position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
								 <div class="thumbnail" >
                                        <a class="btn " style="    border: 5px solid #13237a;" href="awards/350_1506061697.jpg" data-lightbox="roadtrip"><img  src="awards/350_1506061697.jpg"></a>
                                    </div>
									<h5>First Award – CHEMEXCIL</h5>
                                </div>
								</div>
	                                <div style="position: relative; overflow: hidden; height: 502px; " class="col-sm-4 company-image" >
								<div style="width: 332px; height: 262.24px; position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
								 <div class="thumbnail" >
                                        <a class="btn " style="    border: 5px solid #13237a;" href="awards/350_1506061730.jpg" data-lightbox="roadtrip"><img  src="awards/350_1506061730.jpg"></a>
                                    </div>
									<h5>Niryat Shree Award by FIEO</h5>
                                </div>
								</div>
	                                <div style="position: relative; overflow: hidden; height: 502px; " class="col-sm-4 company-image" >
								<div style="width: 332px; height: 262.24px; position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
								 <div class="thumbnail" >
                                        <a class="btn " style="    border: 5px solid #13237a;" href="awards/350_1543294995.jpg" data-lightbox="roadtrip"><img  src="awards/350_1543294995.jpg"></a>
                                    </div>
									<h5>Product Innovator of the Year in Chemicals - 2018</h5>
                                </div>
								</div>
	                                <div style="position: relative; overflow: hidden; height: 502px; " class="col-sm-4 company-image" >
								<div style="width: 332px; height: 262.24px; position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
								 <div class="thumbnail" >
                                        <a class="btn " style="    border: 5px solid #13237a;" href="awards/350_1637911201.jpg" data-lightbox="roadtrip"><img  src="awards/350_1637911201.jpg"></a>
                                    </div>
									<h5>Excellence in Speciality Chemicals Award by FICCI - 2021</h5>
                                </div>
								</div>
	                                <div style="position: relative; overflow: hidden; height: 502px; " class="col-sm-4 company-image" >
								<div style="width: 332px; height: 262.24px; position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
								 <div class="thumbnail" >
                                        <a class="btn " style="    border: 5px solid #13237a;" href="awards/350_1654510684.jpg" data-lightbox="roadtrip"><img  src="awards/350_1654510684.jpg"></a>
                                    </div>
									<h5>R & D Unit</h5>
                                </div>
								</div>
	                                <div style="position: relative; overflow: hidden; height: 502px; " class="col-sm-4 company-image" >
								<div style="width: 332px; height: 262.24px; position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
								 <div class="thumbnail" >
                                        <a class="btn " style="    border: 5px solid #13237a;" href="awards/350_1654513259.jpg" data-lightbox="roadtrip"><img  src="awards/350_1654513259.jpg"></a>
                                    </div>
									<h5>ISO 9001 : 2015 Certificate</h5>
                                </div>
								</div>
	                                <div style="position: relative; overflow: hidden; height: 502px; " class="col-sm-4 company-image" >
								<div style="width: 332px; height: 262.24px; position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
								 <div class="thumbnail" >
                                        <a class="btn " style="    border: 5px solid #13237a;" href="awards/350_1690979646.jpg" data-lightbox="roadtrip"><img  src="awards/350_1690979646.jpg"></a>
                                    </div>
									<h5>'Company of the Year' Award by FICCI - 2023</h5>
                                </div>
								</div>
	                                <div style="position: relative; overflow: hidden; height: 502px; " class="col-sm-4 company-image" >
								<div style="width: 332px; height: 262.24px; position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
								 <div class="thumbnail" >
                                        <a class="btn " style="    border: 5px solid #13237a;" href="awards/350_1706780286.png" data-lightbox="roadtrip"><img  src="awards/350_1706780286.png"></a>
                                    </div>
									<h5>3 Star Export House</h5>
                                </div>
								</div>
	                                <div style="position: relative; overflow: hidden; height: 502px; " class="col-sm-4 company-image" >
								<div style="width: 332px; height: 262.24px; position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
								 <div class="thumbnail" >
                                        <a class="btn " style="    border: 5px solid #13237a;" href="awards/350_1719653248.jpg" data-lightbox="roadtrip"><img  src="awards/350_1719653248.jpg"></a>
                                    </div>
									<h5>Winner of the "India Risk Management Awards" - ESG by CNBC India</h5>
                                </div>
								</div>
	                                <div style="position: relative; overflow: hidden; height: 502px; " class="col-sm-4 company-image" >
								<div style="width: 332px; height: 262.24px; position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
								 <div class="thumbnail" >
                                        <a class="btn " style="    border: 5px solid #13237a;" href="awards/350_1729254624.jpg" data-lightbox="roadtrip"><img  src="awards/350_1729254624.jpg"></a>
                                    </div>
									<h5>ISO 14001 : 2015 Certificate</h5>
                                </div>
								</div>
	                                <div style="position: relative; overflow: hidden; height: 502px; " class="col-sm-4 company-image" >
								<div style="width: 332px; height: 262.24px; position: absolute; left: 0px; top: 0px; transform: translate3d(0px, 0px, 0px);">
								 <div class="thumbnail" >
                                        <a class="btn " style="    border: 5px solid #13237a;" href="awards/350_1729254664.jpg" data-lightbox="roadtrip"><img  src="awards/350_1729254664.jpg"></a>
                                    </div>
									<h5>ISO 45001 : 2018 Certificate</h5>
                                </div>
								</div>
	                            </div>
                    </div>
                
            </div>
        </div>
 <footer class="full-bg " id="footer">

            <div class="container">
                <div class="row">

                    <div class="col-sm-4  widget-cell" id="footer-widget-1">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">ABOUT</h3>
                            <div class="menu-overview-footer-container">
                                <ul id="menu-overview-footer" class="menu">
                                    <li id="menu-item-412" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-412"><a href="company-profile.php">Company Profile</a></li>
                                    <li id="menu-item-415" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-415"><a href="mission-values.php">Mission &#038; Values</a></li>
                                    <li id="menu-item-414" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-414"><a href="certificate-awards.php">Certificate &#038; Awards</a></li>
                                    <li id="menu-item-413" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-413"><a href="balaji-management-team.php">Management Team</a></li>
                                    <li id="menu-item-479" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-479"><a href="balaji-amines-history.php">History</a></li>
                                    <li id="menu-item-709" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-709"><a href="bal-presence.php">BAL&#8217;s Presence</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4  widget-cell">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">PRODUCTS</h3>
                            <div class="menu-overview-footer-1-container">
                                <ul id="menu-overview-footer-1" class="menu">
                                    <li id="menu-item-417" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-417"><a href="amines.php">Amines</a></li>
                                    <li id="menu-item-416" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-416"><a href="derivatives.php">Derivatives</a></li>
                                    <li id="menu-item-418" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-418"><a href="speciality-chemicals.php">Speciality Chemicals</a></li>
                                    <li id="menu-item-679" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-679"><a href="excipients.php">Pharma Excipients</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4  widget-cell">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">OTHERS</h3>
                            <div class="menu-footer3-container">
                                <ul id="menu-footer3" class="menu">
                                    <li id="menu-item-655" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-655"><a href="investor-relations.php">Investor Relations</a></li>
                                    <li id="menu-item-420" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-286 current_page_item menu-item-420 active"><a href="careers.php">Careers</a></li>
                                    <li id="menu-item-421" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-421"><a href="corporate-social-responsibility.php">Corporate Social Responsibility</a></li>
                                    <li id="menu-item-713" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-713"><a href="e-brochures.php">E-Brochure</a></li>
                                    <li id="menu-item-423" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-423"><a href="balaji-media.php">Media</a></li>
                                    <li id="menu-item-422" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-422"><a href="contact-us.php">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-1  widget-cell col-sm-offset-1">
                        <div class="widget widget_text">
                            <div class="textwidget"></div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="row">
                            <div class="col-sm-12" id="social-media-icons"></div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 col-sm-offset-6"></div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
		<div class="container-fluid">
            <div class="ddl-full-width-row row">
                <div class="col-sm-12 copyright-footer">
                    <p>copyright © balaji Amines 2025 Developed By <a href="http://katareinfo.com/">Katrare Informatics</a></p>
                </div>
            </div>
        </div></div>
    <script type='text/javascript' src='wp-content/themes/toolset-bootstrap/bootstrap3/js/bootstrap.min.js?ver=3.3.4'></script>
    <script type='text/javascript' src='wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='wp-includes/js/jquery/ui/datepicker.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='wp-includes/js/mediaelement/mediaelement-and-player.min.js?ver=2.22.0'></script>
    <script type='text/javascript' src='wp-includes/js/mediaelement/wp-mediaelement.min.js?ver=4.7.3'></script>
    <script type='text/javascript' src='wp-includes/js/underscore.min.js?ver=1.8.3'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var _wpUtilSettings = {
            "ajax": {
                "url": "\/wp-admin\/admin-ajax.php"
            }
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='wp-includes/js/wp-util.min.js?ver=4.7.3'></script>
    <script type='text/javascript' src='wp-includes/js/backbone.min.js?ver=1.2.3'></script>
    <script type='text/javascript' src='wp-includes/js/mediaelement/wp-playlist.min.js?ver=4.7.3'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var wpv_pagination_local = {
            "front_ajaxurl": "\/wp-admin\/admin-ajax.php",
            "ajax_pagination_url": "\/wpv-ajax-pagination\/",
            "calendar_image": "\/wp-content\/plugins\/wp-views\/embedded\/res\/img\/calendar.gif",
            "calendar_text": "Select date",
            "datepicker_min_date": null,
            "datepicker_max_date": null
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='wp-content/plugins/wp-views/embedded/res/js/wpv-pagination-embedded.js?ver=1.10'></script>
    <script type='text/javascript' src='wp-includes/js/wp-embed.min.js?ver=4.7.3'></script>
    <script type="text/javascript">
        //-----------------------------------------
        // View: Certificates and awards - start
        //-----------------------------------------
        jQuery(window).load(function() {
            jQuery('#slider-cert').flexslider({
                animation: "slide",
                controlNav: false,
                animationLoop: false,
                slideshow: false,
                prevText: "",
                nextText: "",
                itemWidth: 311,
                maxItems: 1,
                sync: "#product-carousel"
            });

            jQuery("a.certificate-images").fancybox();

        });
        //-----------------------------------------
        // View: Certificates and awards - end
        //-----------------------------------------
    </script>
    <script>
        jQuery(window).scroll(function() {
            if (jQuery(document).scrollTop() > 50) {
                jQuery('header').addClass('shrink');
            } else {
                jQuery('header').removeClass('shrink');
            }
        });

        /*Youtube video*/

        jQuery('.js-lazyYT').lazyYT();

        /** Stop playing youtube video when page scrolls */

        jQuery(document).on('scroll', function() {
            var scrollTop = jQuery(window).scrollTop();
            if (scrollTop > pos.top + 315) {
                player.stopVideo();
            }
        })
    </script>
    <script>
        /* moving object */
        jQuery('.marquee').marquee({
            //speed in milliseconds of the marquee
            duration: 6000,
            //gap in pixels between the tickers
            gap: 1500,
            //time in milliseconds before the marquee will start animating
            delayBeforeStart: 0,
            //'left' or 'right'
            direction: 'right',
            //true or false - should the marquee be duplicated to show an effect of continues flow
            duplicated: true
        });
    </script>
    <script>
        jQuery(document).ready(function() {

            /* Apply fancybox to multiple items */

            jQuery("a.balaji-products").fancybox({
                'transitionIn': 'elastic',
                'transitionOut': 'elastic',
                'speedIn': 600,
                'speedOut': 200,
                'overlayShow': false
            });

            jQuery('.member-mug-shot').on('click', function() {
                jQuery('.collapse').collapse('hide');
            })

        });
    </script>
    <script>
        (function(jQuery) {
            jQuery(document).ready(function() {
                jQuery(".video-button").click(function() {
                    jQuery(".video-embed").css({
                        "opacity": "1",
                        "display": "block"
                    });
                    jQuery(".video-embed")[0].src += "&autoplay=1";
                    jQuery(this).unbind("click");
                });
            });
        })(jQuery)
    </script>
    <script>
        jQuery(document).ready(function() {

            jQuery('.fancybox').fancybox({
                beforeShow: function() {
                    this.title = jQuery(this.element).data("caption");
                }
            });

            jQuery("a#single_image-popup").fancybox();

        });
    </script>
    <script>
        jQuery(window).load(function() {
            jQuery('#single_image-popup').fancybox({
                beforeLoad: function() {
                    this.title = jQuery(this.element).find('img').attr('alt');
                }

            });

            jQuery('#single_image-popup').fancybox({
                'titleFromAlt': true,
                'titlePosition': 'inside'

            });

            jQuery("a#single_image-popup").trigger('click');
        });
    </script>
    <script>
        function myFunction() {
            window.print();
        }
    </script>
</body>

</html>