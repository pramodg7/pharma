<!DOCTYPE html>
<html lang="en-US" class="no-js">
<head>
    <meta charset="UTF-8" />
		<meta name="author" content="Balaji Amines" />
	<meta name="keywords" content=" balaji , balaji amines, balaji amines solapur, Chemical Manufacturers in India, Chemical Manufacturers India, Industrial Chemicals Manufacturers, Industrial Chemicals Manufacturers in India Chemical manufacturing company in india, Chemical manufacturing company in Solapur, Chemical manufacturing company, methyl, Chemical Manufacturer,hydrochloride derivatives, industrial chemicals manufacturers, industrial chemicals suppliers, industrial chemicals india, industrial chemicals exporters, industrial chemicals manufacturer, industrial chemicals supplier, industrial chemicals exporter, industrial chemicals from india, industrial chemicals wholesale, industrial chemicals in india">
	<meta name="description"  content="Manufacturer of methyl and ethyl amines and their amide and hydrochloride derivatives, located in India.  Chemical manufacturing company in india">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Balaji &ndash; Products</title>
    <link rel="shortcut icon" href="wp-content/themes/toolset-bootstrap/favicon.ico">
    <script type="text/javascript">
        window._wpemojiSettings = {
            "baseUrl": "https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/72x72\/",
            "ext": ".png",
            "svgUrl": "https:\/\/s.w.org\/images\/core\/emoji\/2.2.1\/svg\/",
            "svgExt": ".svg",
            "source": {
                "concatemoji": "http:\/\/www.balajiamines.in\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.7.3"
            }
        };
        ! function(a, b, c) {
            function d(a) {
                var b, c, d, e, f = String.fromCharCode;
                if (!k || !k.fillText) return !1;
                switch (k.clearRect(0, 0, j.width, j.height), k.textBaseline = "top", k.font = "600 32px Arial", a) {
                    case "flag":
                        return k.fillText(f(55356, 56826, 55356, 56819), 0, 0), !(j.toDataURL().length < 3e3) && (k.clearRect(0, 0, j.width, j.height), k.fillText(f(55356, 57331, 65039, 8205, 55356, 57096), 0, 0), b = j.toDataURL(), k.clearRect(0, 0, j.width, j.height), k.fillText(f(55356, 57331, 55356, 57096), 0, 0), c = j.toDataURL(), b !== c);
                    case "emoji4":
                        return k.fillText(f(55357, 56425, 55356, 57341, 8205, 55357, 56507), 0, 0), d = j.toDataURL(), k.clearRect(0, 0, j.width, j.height), k.fillText(f(55357, 56425, 55356, 57341, 55357, 56507), 0, 0), e = j.toDataURL(), d !== e
                }
                return !1
            }

            function e(a) {
                var c = b.createElement("script");
                c.src = a, c.defer = c.type = "text/javascript", b.getElementsByTagName("head")[0].appendChild(c)
            }
            var f, g, h, i, j = b.createElement("canvas"),
                k = j.getContext && j.getContext("2d");
            for (i = Array("flag", "emoji4"), c.supports = {
                    everything: !0,
                    everythingExceptFlag: !0
                }, h = 0; h < i.length; h++) c.supports[i[h]] = d(i[h]), c.supports.everything = c.supports.everything && c.supports[i[h]], "flag" !== i[h] && (c.supports.everythingExceptFlag = c.supports.everythingExceptFlag && c.supports[i[h]]);
            c.supports.everythingExceptFlag = c.supports.everythingExceptFlag && !c.supports.flag, c.DOMReady = !1, c.readyCallback = function() {
                c.DOMReady = !0
            }, c.supports.everything || (g = function() {
                c.readyCallback()
            }, b.addEventListener ? (b.addEventListener("DOMContentLoaded", g, !1), a.addEventListener("load", g, !1)) : (a.attachEvent("onload", g), b.attachEvent("onreadystatechange", function() {
                "complete" === b.readyState && c.readyCallback()
            })), f = c.source || {}, f.concatemoji ? e(f.concatemoji) : f.wpemoji && f.twemoji && (e(f.twemoji), e(f.wpemoji)))
        }(window, document, window._wpemojiSettings);
    </script>
    <style type="text/css">
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 .07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
		table {
  border-collapse: separate;
  border-spacing: 0;
}
th,
td {
  padding: 5px 5px !important;
}
thead {
  background: #13237a;
  color: #fff;
}
th {
  font-weight: bold;
}
tbody tr:nth-child(even) {
  background: #f0f0f2;
}
td {
  border-bottom: 1px solid #cecfd5;
  border-right: 1px solid #cecfd5;
}
td:first-child {
  border-left: 1px solid #cecfd5;
}
.btn {
    display: inline-block;
    padding: 0px 5px !important;
    margin-bottom: 0;
    font-size: 14px;
    font-weight: 400;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    background-image: none;
    border: 1px solid transparent;
    border-radius: 4px;
}
.btn-success {
    background-color: #046a0d;
    border-color: #046a0d;
    color: #FFFFFF;
}
    </style>
    <link rel='stylesheet' id='formidable-css' href='wp-content/uploads/formidable/css/formidablepro.css?ver=2.03.03' type='text/css' media='all' />
    <link rel='stylesheet' id='wp_ddl_layout_fe_css-css' href='wp-content/uploads/ddl-layouts-tmp/d41d8cd98f00b204e9800998ecf8427e.css?ver=1.3.2' type='text/css' media='screen' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3/css/bootstrap.min.css?ver=3.3.4' type='text/css' media='all' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_theme_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3/css/bootstrap-theme.min.css' type='text/css' media='all' />
    <link rel='stylesheet' id='toolset-bootstrap-theme-style-css' href='wp-content/themes/toolset-bootstrap/style.css?ver=1.8' type='text/css' media='all' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_adjustment_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3_adjustment.css' type='text/css' media='all' />
    <link rel='stylesheet' id='menu-cells-front-end-css' href='wp-content/plugins/layouts/resources/css/cell-menu-css.css?ver=4.7.3' type='text/css' media='screen' />
    <link rel='stylesheet' id='ddl-front-end-css' href='wp-content/plugins/layouts/resources/css/ddl-front-end.css?ver=4.7.3' type='text/css' media='screen' />
    <link rel='stylesheet' id='toolset-common-css' href='wp-content/plugins/layouts/toolset/toolset-common/res/css/toolset-common.css?ver=4.7.3' type='text/css' media='screen' />
    <link rel='stylesheet' id='wptoolset-field-datepicker-css' href='wp-content/plugins/wp-views/embedded/common/toolset-forms/css/wpt-jquery-ui/datepicker.css?ver=1.10' type='text/css' media='all' />
    <link rel='stylesheet' id='mediaelement-css' href='wp-includes/js/mediaelement/mediaelementplayer.min.css?ver=2.22.0' type='text/css' media='all' />
    <link rel='stylesheet' id='wp-mediaelement-css' href='wp-includes/js/mediaelement/wp-mediaelement.min.css?ver=4.7.3' type='text/css' media='all' />
    <link rel='stylesheet' id='views-pagination-style-css' href='wp-content/plugins/wp-views/embedded/res/css/wpv-pagination.css?ver=1.10' type='text/css' media='all' />
    <script type='text/javascript' src='wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
    <script type='text/javascript' src='wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var DDLayout_fe_settings = {
            "DDL_JS": {
                "css_framework": "bootstrap-3",
                "DEBUG": false
            }
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='wp-content/plugins/layouts/resources/js/ddl-layouts-frontend.js?ver=1.3.2'></script>
 <style type="text/css">
        .recentcomments a {
            display: inline !important;
            padding: 0 !important;
            margin: 0 !important;
        }
    </style>
	<link rel="stylesheet" href="css/lightbox.css">
	<script src="js/lightbox.js"></script>
	<link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/owl.carousel.css">
	<link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/owl.theme.css">
	<script src="wp-content/themes/toolset-bootstrap/js/owl.carousel.js"></script>
	<script type="text/javascript" src="wp-content/themes/toolset-bootstrap/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/fancybox/jquery.fancybox-1.3.4.css" type="text/css" media="screen" />
	<link href='https://fonts.googleapis.com/css?family=Khand:400,300,500,600,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,100italic,100,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link rel='stylesheet' href="wp-content/themes/toolset-bootstrap/css/mediatree.css">
    <link rel='stylesheet' media="print" href="wp-content/themes/toolset-bootstrap/css/custom-print.css">
    <link rel='stylesheet' href="wp-content/themes/toolset-bootstrap/css/zara.css">
    <link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>
    <link href="wp-content/themes/toolset-bootstrap/css/jasny-bootstrap.min.css" rel="stylesheet" media="screen">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.matchHeight.js"></script>
    <script src="wp-content/themes/toolset-bootstrap/js/jasny-bootstrap.min.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/flexslider.css" type="text/css">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.flexslider.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.matchHeight-min.js" type="text/javascript"></script>
    <script type="text/javascript" src="wp-content/themes/toolset-bootstrap/lazyyt/lazyYT.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/lazyyt/lazyYT.css">
    <script type='text/javascript' src='//cdn.jsdelivr.net/jquery.marquee/1.3.1/jquery.marquee.min.js'></script>
</head>
<body class="page-template page-template-page-layouts page-template-page-layouts-php page page-id-480">
    <div class="navmenu navmenu-default navmenu-fixed-right">
        <ul id="menu-menu-1" class="nav navmenu-nav">
            <li id="menu-item-20" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-2 current_page_item menu-item-20 active"><a href="index.php">Homepage</a></li>
            <li id="menu-item-656" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-656"><a href="#">About us</a>
                <ul class="sub-menu">
                    <li id="menu-item-267" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-267"><a href="company-profile.php">Company Profile</a></li>
                    <li id="menu-item-261" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-261"><a href="mission-values.php">Mission &#038; Values</a></li>
                    <li id="menu-item-280" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-280"><a href="certificate-awards.php">Certificate &#038; Awards</a></li>
                    <li id="menu-item-348" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-348"><a href="balaji-management-team.php">Management Team</a></li>
                    <li id="menu-item-339" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-339"><a href="balaji-amines-history.php">History</a></li>
                    <li id="menu-item-710" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-710"><a href="bal-presence.php">BAL&#8217;s Presence</a></li>
                </ul>
            </li>
            <li id="menu-item-400" class="menu-item menu-item-type-post_type_archive menu-item-object-product menu-item-has-children menu-item-400"><a href="category.php">Products</a>
                <ul class="sub-menu">
                    <li id="menu-item-658" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-658"><a href="amines.php">Amines</a></li>
                    <li id="menu-item-657" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-657"><a href="derivatives.php">Derivatives</a></li>
                    <li id="menu-item-659" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-659"><a href="speciality-chemicals.php">Speciality Chemicals</a></li>
                    <li id="menu-item-678" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-678"><a href="excipients.php">Pharma Excipients</a></li>
                </ul>
            </li>
            <li id="menu-item-534" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-534"><a href="investor-relations.php">Investor Relations</a></li>
            <li id="menu-item-290" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-290"><a href="careers.php">Careers</a></li>
            <li id="menu-item-299" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-299"><a href="corporate-social-responsibility.php">Corporate Social Responsibility</a></li>
            <li id="menu-item-282" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-282"><a href="contact-us.php">Contact Us</a></li>
            <li id="menu-item-307" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-307"><a href="balaji-media.php">Media</a></li>
            <li id="menu-item-711" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-711"><a href="e-brochures.php">E-Brochure</a></li>
        </ul>
    </div><div class="canvas">
 <header class="full-bg black-bg" id="homepage-header">
<div class="container">
                <div class="row">
                    <div class="col-sm-1" id="off-canvas-button">
                        <div class="navbar navbar-default">
                            <button type="button" class="navbar-toggle" data-toggle="offcanvas" data-recalc="false" data-target=".navmenu" data-canvas=".canvas">
                                <br />
                                <span class="icon-bar"></span>
                                <br />
                                <span class="icon-bar"></span>
                                <br />
                                <span class="icon-bar"></span>
                                <br />
                            </button>
                        </div>
                    </div>
                    <div class="col-sm-4 col-sm-offset-3" id="homepage-logo">
                        <p>
                            <a href=""><img src="wp-content/uploads/2015/10/balaji_logo.png" alt="Balaji Almines" class="aligncenter size-full img-responsive"></a>
                        </p>
                    </div>
                </div>
            </div>
        </header>
        <div class="container-fluid">
            <div class="ddl-full-width-row row">
                <div class="col-sm-12 featured-thumbnail">
                    <div class="thumbnail">
                        <img src="wp-content/uploads/2015/10/financials-banner.jpg">
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">

               <div class="col-sm-8 page-title-div text-center col-sm-offset-2">
                    <h1>CORPORATE SOCIAL RESPONSIBILITY</h1>
                </div>
            </div>
        </div>
		<div class="container">
            <div class="row">
                <div class="col-sm-12 csr-content">
                    <p>CSR is tool to aid an organization’s mission as well as serve as guide to what the company reserve for its consumers. The Company is committed to contribute towards the society at large by CSR means in the field of education, healthcare and livelihood for the general upliftment of the economically weaker sections of the Society. One of the primary responsibility of the Company is to give back something to the society and contribute a bit in the development our country. As a socially sound company we have taken many positive initiatives towards the betterment of the society. Broadly, the social activities of the Company emphasizes in education, healthcare and community services as set out below:</p>
                    <ul>
                        <li><h3>EDUCATION</h3></br>
The Company’s contribution in the field of education includes contribution to Solapur, Osmanabad and Medak district area educational institutions. The Company provides notebooks, library books, benches, desks, water filters R/O system, Toilet blocks, laboratory equipments, fund for construction of school building and other required furniture. Beside this we also provide projectors and computers to act as a catalyst for developing e-learning process in schools and scholarships for needy students etc.

The Company on regular basis sponsor district level and international conferences, educational lectures, seminars, etc. 

We also encourage sports education by providing help to children who are preparing for state or national level sports. 
</li>
                        <li><h3>HEALTHCARE</h3></br>

The Company provides Donation to the patients for medical treatments to cater to the need for medical and healthcare services. We also have health units to provide medical facilities to emergency patients and for the needy section of the public and the Company organize regular free Health Camps (including eye / dental checkups) in remote, inaccessible areas.

For healthcare the Company also distributes dustbins, toilet blocks around the Solapur district and Osmanabad for better health and hygiene of the rural public.
 
Apart from providing other facilities for rural people, during scarcity period to mitigate the water shortages in Solapur and Osmanabad Districts, the Company has done distribution of water tanks of permanent nature (i.e. RCC tanks) of 3000 Litres or other Capacity and provided water through for the livestock in some of the villages.  
</li>
                        <li><h3>COMMUNITY SERVICE</h3></br>

The Company Contribute to the orphanages situated in and around Solapur which provides the financial support and looks after the maintenance of the homeless people by way of financial support for their general upliftment.

The Company has donated the wheelchairs for Senior citizens at Solpaur Railway Station.
</li>
                        <li><h3>CONSERVATION OF NATURAL RESOURCES</h3></br>

The Maharashtra government in India has launched a water conservation scheme named “Jalyukt Shivar Abhiyan” to make Maharashtra a drought-free state.

As a part of conservation of natural resources, we have undertaken Jalyukt Shivar Abhiyaan. The key aim of Jalyukta Shivar Abhiyan is to establish belief in a farmer that “every drop of rainwater is owned by me and it should percolate in my land”.

Keeping this view in mind company has started this mission by way of  deepening and widening of Nallas (drainage system) since 2015 and completed the work in 27 villages and helped in creating a storage to the tune of 300 TCM (30 Crores Liters).
</li>
                        <li><h3>RURAL DEVELOPMENT</h3></br>

The Company has extended the help in establishing Ekalavya Centre for organic agriculture Research and Training Centre at Gungurti, Tandur Mandal, Vikarabad District.

As a part of smart village development, the company has been providing infrastructure facilities by way of construction of Roads, providing cement poles, Street Lights, and Surface drainage facilities to various villages.

To promote the “Swatch Bharat Abhiyan” the Company has contributed by way of supplying Garbage containers to Solapur and Osmanabad District.

The Company has also provided Containers and dumper placer for waste management of to Municipal Corporation of Solapur/Osmanabad/Medak. 

The Company shall always strive to achieve the well being of the society in which it operates other neighboring communities and the nation at large.
</li>    
</ul>
</div>
</div>
</div>
        <div class="container">
            <div class="row report-row-wrapper">

                <div class="col-sm-12 report-download heading-color">
                  
<div class="row" id="company-sec-row">
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1673697472.jpg" data-lightbox="roadtrip"><img src="csr/350_1673697472.jpg"></a>
                                    </div>
									<h5>PAINTING OF SPEAKING IMAGES ON WALL AT Z.P.PRIMARY CENTRAL SCHOOL, SURATGAONDT. 03.12.2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1673697460.jpg" data-lightbox="roadtrip"><img src="csr/350_1673697460.jpg"></a>
                                    </div>
									<h5>PAINTING OF SPEAKING IMAGES ON WALL AT Z.P.PRIMARY CENTRAL SCHOOL, SURATGAONDT. 03.12.2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1673697430.jpg" data-lightbox="roadtrip"><img src="csr/350_1673697430.jpg"></a>
                                    </div>
									<h5>INSTALLED 500 LPH RO PLANT AT GANESH NAIK PRIMARY SCHOOL, VIJAPUR ROAD, SOLAPUR DT. 03.01.2023</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1673697422.jpg" data-lightbox="roadtrip"><img src="csr/350_1673697422.jpg"></a>
                                    </div>
									<h5>INSTALLED 500 LPH RO PLANT AT GANESH NAIK PRIMARY SCHOOL, VIJAPUR ROAD, SOLAPUR DT. 03.01.2023</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1673697401.jpg" data-lightbox="roadtrip"><img src="csr/350_1673697401.jpg"></a>
                                    </div>
									<h5>DONATED  BI PAP MACHINE  - 4 NOS TO JAGDALE MAMA HOSPITAL BARSHI DIST SOLAPUR DT. 02.01.2023</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1673697391.jpg" data-lightbox="roadtrip"><img src="csr/350_1673697391.jpg"></a>
                                    </div>
									<h5>DONATED  BI PAP MACHINE  - 4 NOS TO JAGDALE MAMA HOSPITAL BARSHI DIST SOLAPUR DT. 02.01.2023</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1673697369.jpg" data-lightbox="roadtrip"><img src="csr/350_1673697369.jpg"></a>
                                    </div>
									<h5>DISTRIBUTED GARDEN BENCHES - 20 NOS TO MOHOL NAGARPARISHAD, MOHOL DT. 11.11.2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1673697341.jpg" data-lightbox="roadtrip"><img src="csr/350_1673697341.jpg"></a>
                                    </div>
									<h5>CONSTRUCTED TOILET BLOCK AT Z.P.PRIMARY SCHOOL, AMBIKA NAGAR, BALE DT. 22.12.2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1673697320.jpg" data-lightbox="roadtrip"><img src="csr/350_1673697320.jpg"></a>
                                    </div>
									<h5>CONSTRUCTED 2 CLASSROOM AT KAI.TATYASAHEB GURUSIDHAPPA AAMALE PRASHALA, DONGAON DT. 26.11.2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1673697311.jpg" data-lightbox="roadtrip"><img src="csr/350_1673697311.jpg"></a>
                                    </div>
									<h5>CONSTRUCTED 2 CLASSROOM AT KAI.TATYASAHEB GURUSIDHAPPA AAMALE PRASHALA, DONGAON DT. 26.11.2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1673697284.jpg" data-lightbox="roadtrip"><img src="csr/350_1673697284.jpg"></a>
                                    </div>
									<h5>BAL has provided 1134 detailed village maps to Land & Revenue Dept., Solapur DT. 01.08.2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1673697230.jpg" data-lightbox="roadtrip"><img src="csr/350_1673697230.jpg"></a>
                                    </div>
									<h5>BAL has provided 1134 detailed village maps to Land & Revenue Dept., Solapur DT. 01.08.2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1665391205.jpg" data-lightbox="roadtrip"><img src="csr/350_1665391205.jpg"></a>
                                    </div>
									<h5>RECEIVED MAHATMA AWARD FOR CONTRIBUTION TOWARDS SOCIETY DT 01 OCTOBER  2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1665391121.jpg" data-lightbox="roadtrip"><img src="csr/350_1665391121.jpg"></a>
                                    </div>
									<h5>RECEIVED MAHATMA AWARD FOR CONTRIBUTION TOWARDS SOCIETY DT 01 OCT 22</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1665391107.jpg" data-lightbox="roadtrip"><img src="csr/350_1665391107.jpg"></a>
                                    </div>
									<h5>RECEIVED MAHATMA AWARD FOR CONTRIBUTION TOWARDS SOCIETY DT 01 OCT 2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1665391092.jpg" data-lightbox="roadtrip"><img src="csr/350_1665391092.jpg"></a>
                                    </div>
									<h5>SETTING UP WENDING CARTS TO EMPOWER UNEMPLOYED YOUTH DT 12 AUG 2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1665391077.jpg" data-lightbox="roadtrip"><img src="csr/350_1665391077.jpg"></a>
                                    </div>
									<h5>SETTING UP SEWING MACHINES TO EMPOWER UNEMPLOYED WOMENS DT 12 AUG 2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1665391059.jpg" data-lightbox="roadtrip"><img src="csr/350_1665391059.jpg"></a>
                                    </div>
									<h5>SETTING UP AATA CHAKKI TO EMPOWER UNEMPLOYED WOMENS DT 12 AUG 2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1665391038.jpg" data-lightbox="roadtrip"><img src="csr/350_1665391038.jpg"></a>
                                    </div>
									<h5>ENCOURAGING SPORTS PLAYER TO PARTICIPATE IN INTERNATIONAL LEVEL SPORTS DT 16 SEPT 22</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1665391019.jpg" data-lightbox="roadtrip"><img src="csr/350_1665391019.jpg"></a>
                                    </div>
									<h5>ENCOURAGING SPORTS PLAYER TO PARTICIPATE IN INTERNATIONAL LEVEL SPORTS DT 16 SEPT 2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1665390993.jpg" data-lightbox="roadtrip"><img src="csr/350_1665390993.jpg"></a>
                                    </div>
									<h5>DONATED HEARING AID DEVICE TO SONALI HOTKAR AND SANTOSH SONGEWALE DT 12 AUG 2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1665390975.jpg" data-lightbox="roadtrip"><img src="csr/350_1665390975.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF SCHOOL MATERIAL  NOTE BOOKS  COMPASS BOX SCHOOL BAGS  TO DIGITAL MEDIA REPORTER ASSOCIATION SOLAPUR  DT 07 JULY 2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1665390938.jpg" data-lightbox="roadtrip"><img src="csr/350_1665390938.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF OXYGEN CONCENTRATOR 12 NOS TO TALUKA AROGYA ADHIKARI TULJAPUR DT 22 JUNE 2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1665390915.jpg" data-lightbox="roadtrip"><img src="csr/350_1665390915.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF COATS WITH MATRESSES AND SANITARY NAPKIN INCINERATOR  TO RENUKAMATA LADIES HOSTEL SOLAPUR DT 12 AUG 2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1665390882.jpg" data-lightbox="roadtrip"><img src="csr/350_1665390882.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF ARCHERY EQUIPMENT TO CHATRAPATI SHIVAJI NIGHT COLLEGE SOLAPUR  DT 12 AUG 2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1665390863.jpg" data-lightbox="roadtrip"><img src="csr/350_1665390863.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF  CYCLES  TO SHANTAI ANATHASHRAM  SOLAPUR DT 12 AUG 2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1665390847.jpg" data-lightbox="roadtrip"><img src="csr/350_1665390847.jpg"></a>
                                    </div>
									<h5>DISTRIBUTED PVC RAINSUITES  150 NOS TO POLICE STATION TULJAPUR DT 06 OCT 2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1665390829.jpg" data-lightbox="roadtrip"><img src="csr/350_1665390829.jpg"></a>
                                    </div>
									<h5>CONSTRUCTED LADIES AND GENTS TOILE BLCOK AT SHREE RAMANAND MAHARAJ VIDYAMANDIR KAJALA OSMANABAD  DT 27 SEPT 2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1665390791.jpg" data-lightbox="roadtrip"><img src="csr/350_1665390791.jpg"></a>
                                    </div>
									<h5>CONSTRUCTED OF SECURITY GAURD ROOM AT SRPF CAMP SOREGAON SOLAPUR DT 25 AUG 2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1665390376.jpg" data-lightbox="roadtrip"><img src="csr/350_1665390376.jpg"></a>
                                    </div>
									<h5>CONSTRUCTED LADIES AND GENTS TOILE BLCOK AT INNOVATIVE SCHOOL ANKOLI TAL MOHOL DIST SOLAPUR DT 03 SEPT 2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1656671246.jpg" data-lightbox="roadtrip"><img src="csr/350_1656671246.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF SCHOOL EQUIPMENTS TO 10 VARIOUS SCHOOLS OF OSMANABAD DISTRICT ON 22.06.2022.</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1656671184.jpg" data-lightbox="roadtrip"><img src="csr/350_1656671184.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF SCHOOL EQUIPMENTS TO 10 VARIOUS SCHOOLS OF OSMANABAD DISTRICT ON 22.06.2022.</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1656669990.jpg" data-lightbox="roadtrip"><img src="csr/350_1656669990.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF ZPPS SAMBHAJINAGAR, JALKOT  ON 22.06.2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1656669943.jpg" data-lightbox="roadtrip"><img src="csr/350_1656669943.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF SMART TV TO Z.P.PRIMARY SCHOOL, VAGDARI DIST.OSMANABAD ON . 22.06.2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1656669908.jpg" data-lightbox="roadtrip"><img src="csr/350_1656669908.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF SMART BOARD & PROJECTOR  TO  Z.P.PRIMARY SCHOOL, TAMALWADI DIST.OSMANABAD  ON. 22.06.2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1656669870.jpg" data-lightbox="roadtrip"><img src="csr/350_1656669870.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF LAB EQUIPMENTS TO BHARAT VIDYALAY, OSMANABAD DT.22.06.2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1656669829.jpg" data-lightbox="roadtrip"><img src="csr/350_1656669829.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF COMPUTER - 2 NOS TO Z.P.PRIMARY SCHOOL, VALHA, DIST. OSMANABAD  DT. 22.06.2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1656669528.jpg" data-lightbox="roadtrip"><img src="csr/350_1656669528.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF 198 BENCHES TO 6 VARIOUS SCHOOLS OF OSMANABAD DISTRICT ON 22 06 2022</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1649156206.jpg" data-lightbox="roadtrip"><img src="csr/350_1649156206.jpg"></a>
                                    </div>
									<h5>DONATED Rs . 10 LAKH TO L. B. P.MAHILA MAHAVIDYALAYA, SOLAPUR FOR CONSTRUCTION OF SEMINAR HALL</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1649156050.jpg" data-lightbox="roadtrip"><img src="csr/350_1649156050.jpg"></a>
                                    </div>
									<h5>DONATED Rs . 8 LAKH TO VIVEKANANDA KENDRA TRAINING INSTITUTE, SOLAPUR FOR CONSTRUCTION OF KITCHEN</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1649156026.jpg" data-lightbox="roadtrip"><img src="csr/350_1649156026.jpg"></a>
                                    </div>
									<h5>DONATED Rs . 10 LAKH TO L. B. P.MAHILA MAHAVIDYALAYA, SOLAPUR FOR  CONSTRUCTION OF SEMINAR HALL</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1648190299.jpg" data-lightbox="roadtrip"><img src="csr/350_1648190299.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF 500 LPH RO SYSTEM, PA SYSTEM, SMART BOARD, COMPUTER – 2, PROJECTOR – 1, SCIENCE LAB & SPORTS EQUIPMENTS TO ZPHS HIGH SCHOOL, MANDAL MIRDODDI, TELANGANA</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1648189813.jpg" data-lightbox="roadtrip"><img src="csr/350_1648189813.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF 250 LPH RO SYSTEM, PA SYSTEM, SMART BOARD, COMPUTER – 2, PROJECTOR – 1, SCIENCE LAB & SPORTS EQUIPMENTS  TO ZPHS HIGH SCHOOL CHEPYAL, SIDDIPET, TELANGANA</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1648189129.jpg" data-lightbox="roadtrip"><img src="csr/350_1648189129.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF 250 LPH RO SYSTEM, PA SYSTEM, SMART TV, SMART BOARD, COMPUTER – 2, PROJECTOR – 1, SCIENCE LAB & SPORTS EQUIPMENTS TO MANDAL PARISHAD PRIMARY SCHOOL, CHEPYAL,SIDDIPET,TELANGANA</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1645506719.jpg" data-lightbox="roadtrip"><img src="csr/350_1645506719.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF LAB EQUIPMENTS TO ASCENT COLLEGE, SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1645505263.jpg" data-lightbox="roadtrip"><img src="csr/350_1645505263.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF LAB EQUIPMENTS TO ASCENT COLLEGE, SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1645505243.jpg" data-lightbox="roadtrip"><img src="csr/350_1645505243.jpg"></a>
                                    </div>
									<h5>CONSTRUCTED TOILET BLOCK AT DAWAL MALIK URDU HIGH SCHOOL, BORAMANI, TAL-SOUTH SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1644057428.jpg" data-lightbox="roadtrip"><img src="csr/350_1644057428.jpg"></a>
                                    </div>
									<h5>INSTALLED 500 LPH RO PLANT AT SHREE DATTA PRASHALA, KOLEGAON, TAL-MOHOL</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1644057408.jpg" data-lightbox="roadtrip"><img src="csr/350_1644057408.jpg"></a>
                                    </div>
									<h5>INSTALLED 500 LPH RO PLANT AT SHREE DATTA PRASHALA, KOLEGAON, TAL-MOHOL</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1644057173.jpg" data-lightbox="roadtrip"><img src="csr/350_1644057173.jpg"></a>
                                    </div>
									<h5>INSTALLED 500 LPH RO PLANT AT SHREE DATTA PRASHALA, KOLEGAON, TAL-MOHOL</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1644056754.jpg" data-lightbox="roadtrip"><img src="csr/350_1644056754.jpg"></a>
                                    </div>
									<h5>Inauguration of Electrical Cremation Unit built by Balaji Amines Ltd by Guardian Minister Mr Dattatray Bharne.</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1644056705.jpg" data-lightbox="roadtrip"><img src="csr/350_1644056705.jpg"></a>
                                    </div>
									<h5>Inauguration of Electrical Cremation Unit built by Balaji Amines Ltd by Guardian Minister Mr Dattatray Bharne</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1644056575.jpg" data-lightbox="roadtrip"><img src="csr/350_1644056575.jpg"></a>
                                    </div>
									<h5>Handing over Electrical Cremation Project built by Balaji Amines Ltd. to Solapur M. Corp. in presence of M.D. Mr. D. Ram Reddy, Guardian Min. Mr. Dattatray Bharne & Mayor Mrs. Srikanchana Yannam</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1644056047.jpg" data-lightbox="roadtrip"><img src="csr/350_1644056047.jpg"></a>
                                    </div>
									<h5>HIGHFLOW O2 THERAPY MACHINE – 2 AND BiPAP  MACHINE  1 TO ESIS HOSPITAL SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1644056010.jpg" data-lightbox="roadtrip"><img src="csr/350_1644056010.jpg"></a>
                                    </div>
									<h5>NEWS OF AKKOLEKATI FUNCTION</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1644055680.jpg" data-lightbox="roadtrip"><img src="csr/350_1644055680.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF SMART BOARD TO ANANDRAO DEVKATE MADYAMIK VA UCCHA MADYAMIK PRASHALA VADAJI ON 14122021</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1644055657.jpg" data-lightbox="roadtrip"><img src="csr/350_1644055657.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF MPSC UPSC COMPETITIVE BOOKS TO  JANSEVA SARVJANIK VACHNALAY DEGAON VA MOHOL</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1644055632.jpg" data-lightbox="roadtrip"><img src="csr/350_1644055632.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF LAB EQUIPMENTS TO 3 SCHOOLS OF SOLPAUR DISTRICT ON 14122021</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1644055605.jpg" data-lightbox="roadtrip"><img src="csr/350_1644055605.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF 55 BENCHES TO 3 VARIOUS SCHOOLS OF SOLAPUR DISTRICT ON 14122021</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1644055582.jpg" data-lightbox="roadtrip"><img src="csr/350_1644055582.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF 5 COMPUTERS TO VARIOUS SCHOOLS OF SOLAPUR DISTRICT ON 14122021</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1644055553.jpg" data-lightbox="roadtrip"><img src="csr/350_1644055553.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF 1 PROJECTOR TO  SIDHARTH MARATHI VIDYALAYA, SOLAPUR ON 14122021</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1644055491.jpg" data-lightbox="roadtrip"><img src="csr/350_1644055491.jpg"></a>
                                    </div>
									<h5>CONSTRUCTED AND HANDED OVER SCIENCE LABORATORY TO SHIVPRABHU MADYAMIK PRASHALA VA KANISHTHA MAHAVIDYALAY AKKOLEKATI TAL NORTH SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1640174213.jpg" data-lightbox="roadtrip"><img src="csr/350_1640174213.jpg"></a>
                                    </div>
									<h5>INSTALLED 500 LPH RO PLANT AT SRI S K BIRAJDAR PRASHALA SHELAGI SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1640174102.jpg" data-lightbox="roadtrip"><img src="csr/350_1640174102.jpg"></a>
                                    </div>
									<h5> DONATED ARTHO DRILL MACHINE – 3 TO SHRI CHATRAPATI SHIVAJI MAHARAJ SARVOPCHAR RUGNALAY ( CIVIL HOSPITAL), SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1640174053.jpg" data-lightbox="roadtrip"><img src="csr/350_1640174053.jpg"></a>
                                    </div>
									<h5>DONATED ARTHO DRILL MACHINE – 3 TO SHRI CHATRAPATI SHIVAJI MAHARAJ SARVOPCHAR RUGNALAY ( CIVIL HOSPITAL), SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1629265963.jpg" data-lightbox="roadtrip"><img src="csr/350_1629265963.jpg"></a>
                                    </div>
									<h5>INSTALLED 500 LPH RO PLANT AT SHRI MALLIKARJUN HIGH SCHOOL, HATTURE NAGAR, MAJAREWADI, SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1629265922.jpg" data-lightbox="roadtrip"><img src="csr/350_1629265922.jpg"></a>
                                    </div>
									<h5>INSTALLED 500 LPH RO PLANT AT SHRI MALLIKARJUN HIGH SCHOOL, HATTURE NAGAR, MAJAREWADI, SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1629265892.jpg" data-lightbox="roadtrip"><img src="csr/350_1629265892.jpg"></a>
                                    </div>
									<h5>CONSTRUCTED LADIES TOILET BLOCK  AT HARSHVARDHAN HIGHSCHOOL HIPPARGE ( TALE) DIST-SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1628943428.jpg" data-lightbox="roadtrip"><img src="csr/350_1628943428.jpg"></a>
                                    </div>
									<h5>Donated Rs One Crore to C M Relief Fund towards Helping For Flood Affected Victims</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1628943361.jpg" data-lightbox="roadtrip"><img src="csr/350_1628943361.jpg"></a>
                                    </div>
									<h5>Donated Rs .One Crore to C.M.Relief Fund towards Helping For Flood Affected Victims</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1620126229.jpg" data-lightbox="roadtrip"><img src="csr/350_1620126229.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1620126166.jpg" data-lightbox="roadtrip"><img src="csr/350_1620126166.jpg"></a>
                                    </div>
									<h5>DONATED HIGHFLOW OXYGEN AND BI PAP MACHINES TO OSMANABAD COLLECTOR OFFICE (2)</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1620125536.jpg" data-lightbox="roadtrip"><img src="csr/350_1620125536.jpg"></a>
                                    </div>
									<h5>DONATED ONE BI PAP MACHINE TO  SOLAPUR OLIVE LIFE LINE HOSPITAL</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1620125464.jpg" data-lightbox="roadtrip"><img src="csr/350_1620125464.jpg"></a>
                                    </div>
									<h5>DONATED ONE BI PAP MACHIN TO MONARCH HOSPITAL SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1620125411.jpg" data-lightbox="roadtrip"><img src="csr/350_1620125411.jpg"></a>
                                    </div>
									<h5>DONATED BI PAP MACHINE TO ASHWINI HOSPITAL SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1620125350.jpg" data-lightbox="roadtrip"><img src="csr/350_1620125350.jpg"></a>
                                    </div>
									<h5>DONATED BI PAP MACHINES TO GANGAMAI HOSPITAL  SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1613737724.jpg" data-lightbox="roadtrip"><img src="csr/350_1613737724.jpg"></a>
                                    </div>
									<h5>Donation of fibre pole to State and National Pole Vault player Ms.Nagamma Baje</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1613737339.jpg" data-lightbox="roadtrip"><img src="csr/350_1613737339.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1607167712.jpg" data-lightbox="roadtrip"><img src="csr/350_1607167712.jpg"></a>
                                    </div>
									<h5>   </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1607167593.jpg" data-lightbox="roadtrip"><img src="csr/350_1607167593.jpg"></a>
                                    </div>
									<h5>Donated third i smart patroling system to osmanabad Police</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1606129269.jpg" data-lightbox="roadtrip"><img src="csr/350_1606129269.jpg"></a>
                                    </div>
									<h5>FUNDS FOR CONSTRUCTION OF RYTHU VEDIKA AT NIZAMPET MANDAL ( MEDAK DISTRICT)</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1606129147.jpg" data-lightbox="roadtrip"><img src="csr/350_1606129147.jpg"></a>
                                    </div>
									<h5>FUNDS FOR CONSTRUCTION OF RYTHU VEDIKA AT MEDAK ( MEDAK DISTRICT)</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1606123815.jpg" data-lightbox="roadtrip"><img src="csr/350_1606123815.jpg"></a>
                                    </div>
									<h5>   </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1606123773.jpg" data-lightbox="roadtrip"><img src="csr/350_1606123773.jpg"></a>
                                    </div>
									<h5>DONATED 4 NOS. SAINTARY NAPKIN VENDING MACHIN AND 4 NOS INCINARATAR TO RAILWAYS SOLAPUR DIVISION</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1606123427.jpg" data-lightbox="roadtrip"><img src="csr/350_1606123427.jpg"></a>
                                    </div>
									<h5>CONSTRUCTED & HANDED OVER SCIENCE LABORATORY TO DHYANDAN VIDYALAY , JAWALA DUMALA DIST OSMANABAD</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1602588517.jpg" data-lightbox="roadtrip"><img src="csr/350_1602588517.jpg"></a>
                                    </div>
									<h5>      </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1602588172.jpg" data-lightbox="roadtrip"><img src="csr/350_1602588172.jpg"></a>
                                    </div>
									<h5>CONSTRUCTED TOILET BLOCK FOR SCHOOL AT VIDYANIKETAN  VIDYALAY  AT  YERMALA   DIST .OSMANABAD</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1602587571.jpg" data-lightbox="roadtrip"><img src="csr/350_1602587571.jpg"></a>
                                    </div>
									<h5>  </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1602583384.jpg" data-lightbox="roadtrip"><img src="csr/350_1602583384.jpg"></a>
                                    </div>
									<h5>DONATED TWO HIGHFLOW OXYGEN MACHINE TO JAGDALE MAMA HOSPITAL BARSHI DIST SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1600945029.jpg" data-lightbox="roadtrip"><img src="csr/350_1600945029.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1600945015.jpg" data-lightbox="roadtrip"><img src="csr/350_1600945015.jpg"></a>
                                    </div>
									<h5>  </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1600944973.jpg" data-lightbox="roadtrip"><img src="csr/350_1600944973.jpg"></a>
                                    </div>
									<h5>   DONATED HIGHFLOW OXYGEN MACHINE TO SUB DISTRICT HOSPITAL TULJAPUR </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1600766727.png" data-lightbox="roadtrip"><img src="csr/350_1600766727.png"></a>
                                    </div>
									<h5>  </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1600684791.jpg" data-lightbox="roadtrip"><img src="csr/350_1600684791.jpg"></a>
                                    </div>
									<h5>DONATED HIGHFLOW OXYGEN MACHINE TO ALUJ COVID  HOSPITAL AKLUJ DIST  SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1597659284.jpg" data-lightbox="roadtrip"><img src="csr/350_1597659284.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1597658819.jpg" data-lightbox="roadtrip"><img src="csr/350_1597658819.jpg"></a>
                                    </div>
									<h5>DONATED 100 LPH RO SYSTEM  - 2 NOS TO PRIMARY HEALTH CENTRE,KANDALGAON & HOTGI, SOUTH SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1597658390.jpg" data-lightbox="roadtrip"><img src="csr/350_1597658390.jpg"></a>
                                    </div>
									<h5>DONATED HIGHFLOW OXYGEN MACHINE  TO CENTRAL RAILWAY HOSPITAL SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1597658172.jpg" data-lightbox="roadtrip"><img src="csr/350_1597658172.jpg"></a>
                                    </div>
									<h5>DONATED HIGHFLOW OXYGEN MACHINE  TO DHANRAJGIRJI RUGNALAY VISHVAST SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1597657654.jpg" data-lightbox="roadtrip"><img src="csr/350_1597657654.jpg"></a>
                                    </div>
									<h5>DONATED PPE KIT – 25 NOS & MASK – 500 NOS TO ASSISTANT LABOUR COMMISSIONER OFFICE, SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1596284787.jpg" data-lightbox="roadtrip"><img src="csr/350_1596284787.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1596284747.jpg" data-lightbox="roadtrip"><img src="csr/350_1596284747.jpg"></a>
                                    </div>
									<h5>Donated Three High Flow oxigen Machine to Shri Markandey Rugnalaya</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1596284723.jpg" data-lightbox="roadtrip"><img src="csr/350_1596284723.jpg"></a>
                                    </div>
									<h5>Donated Five High Flow oxigen Machine to Solapur Civil Hospital</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1596284517.jpg" data-lightbox="roadtrip"><img src="csr/350_1596284517.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1596284481.jpg" data-lightbox="roadtrip"><img src="csr/350_1596284481.jpg"></a>
                                    </div>
									<h5>Donated two High Flow oxigen Machine to Yashodhara Super Speciality Hospital</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1596284338.jpg" data-lightbox="roadtrip"><img src="csr/350_1596284338.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1596284291.jpg" data-lightbox="roadtrip"><img src="csr/350_1596284291.jpg"></a>
                                    </div>
									<h5>Donated two High Flow oxigen Machine to Osmanabad Zilla civil Hospital</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1596284096.jpg" data-lightbox="roadtrip"><img src="csr/350_1596284096.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1596284071.jpg" data-lightbox="roadtrip"><img src="csr/350_1596284071.jpg"></a>
                                    </div>
									<h5>HIGH FLOW OXIGEN MACHIN TWO UNITS DONATED TO GANGAMAI HOSPITAL SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1596283765.jpg" data-lightbox="roadtrip"><img src="csr/350_1596283765.jpg"></a>
                                    </div>
									<h5>DONATED 10 COTS TO RAJYA RAKHIV POLUCE GAT NO 10 SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1596283310.jpg" data-lightbox="roadtrip"><img src="csr/350_1596283310.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1596283153.jpg" data-lightbox="roadtrip"><img src="csr/350_1596283153.jpg"></a>
                                    </div>
									<h5> X-RAR MACHINE (SKAN RAY) AND RADIOGRAPHY SYSTEM TO SOLAPUR MUNCIPAL CORPORATION (HEALTH DEPARTMENT), SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1596283077.jpg" data-lightbox="roadtrip"><img src="csr/350_1596283077.jpg"></a>
                                    </div>
									<h5> X-RAR MACHINE (SKAN RAY) AND RADIOGRAPHY SYSTEM TO SOLAPUR MUNCIPAL CORPORATION (HEALTH DEPARTMENT), SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1596282905.jpg" data-lightbox="roadtrip"><img src="csr/350_1596282905.jpg"></a>
                                    </div>
									<h5>MASK –  SANITIZER –  , SODIUM HYPO CHLORITE –AND FACE SHEILD –  NOS FOR PRIMARY SUB-HEALTHCARE CENTER, NANNAJ</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1591698747.jpg" data-lightbox="roadtrip"><img src="csr/350_1591698747.jpg"></a>
                                    </div>
									<h5>DONATED T-SHIRTS 200 NOS TO CORONO WARRIORS AT POLICE STATION TAMALWADI 2</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1591698680.jpg" data-lightbox="roadtrip"><img src="csr/350_1591698680.jpg"></a>
                                    </div>
									<h5>DONATED T-SHIRTS  200 NOS TO CORONO WARRIORS AT POLICE STATION TAMALWADI 1</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1591696230.jpg" data-lightbox="roadtrip"><img src="csr/350_1591696230.jpg"></a>
                                    </div>
									<h5>At the time of Distribution of RNA Covid 19 Testing Machine to Dr  Babasaheb Ambedkar University Osmanabad</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1591696132.jpg" data-lightbox="roadtrip"><img src="csr/350_1591696132.jpg"></a>
                                    </div>
									<h5>At the time of Distribution of RNA Covid 19 Testing Machine to  Dr  Babasaheb Ambedkar University  Osmanabad Dist </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1591695707.jpg" data-lightbox="roadtrip"><img src="csr/350_1591695707.jpg"></a>
                                    </div>
									<h5>Distributed 50 Cotts to Covid -19 Care Centre, South Solapur Tahasil</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1591695658.jpg" data-lightbox="roadtrip"><img src="csr/350_1591695658.jpg"></a>
                                    </div>
									<h5>Distributed 50 Cotts to Covid -19 Care Centre, South Solapur </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1591695511.jpg" data-lightbox="roadtrip"><img src="csr/350_1591695511.jpg"></a>
                                    </div>
									<h5>Distributed Food Packets to migrants returning their home by Shramik Special Train at solapur</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1591684024.jpg" data-lightbox="roadtrip"><img src="csr/350_1591684024.jpg"></a>
                                    </div>
									<h5>Distributed Food Packets to migrants returning their home by Shramik Special Train</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1591683942.jpg" data-lightbox="roadtrip"><img src="csr/350_1591683942.jpg"></a>
                                    </div>
									<h5>DONATED 150 NOS RATION KITS AT PANCHAYAT SAMITI, MOHOL</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1591683864.jpg" data-lightbox="roadtrip"><img src="csr/350_1591683864.jpg"></a>
                                    </div>
									<h5>DONATED 100 NOS RATION KITS AT GRAMPANCHAYAT, AKKOLEKATI</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1591683764.jpg" data-lightbox="roadtrip"><img src="csr/350_1591683764.jpg"></a>
                                    </div>
									<h5>DONATED SODIUM HYPO CHLORITE  - 13 DRUMS TO SOLAPUR MUNCIPAL CORPORATION, SOLAPUR ( HEALTH DEPARTMENT)</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1586502600.jpg" data-lightbox="roadtrip"><img src="csr/350_1586502600.jpg"></a>
                                    </div>
									<h5>Donated 500 Nos  Ration Kits to ZP Solapur</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1586501879.jpg" data-lightbox="roadtrip"><img src="csr/350_1586501879.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1586501801.jpg" data-lightbox="roadtrip"><img src="csr/350_1586501801.jpg"></a>
                                    </div>
									<h5>Donated Ventillators, PPE Kits, N95 Masks & Sanitiser to Solapur Civil Hospital</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1586501457.jpg" data-lightbox="roadtrip"><img src="csr/350_1586501457.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1586501415.jpg" data-lightbox="roadtrip"><img src="csr/350_1586501415.jpg"></a>
                                    </div>
									<h5>Donated Ventillator, PPE Kits, N95 Masks, Sanitiser & Disinfectant to Civil Hospital Osmanabad</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1586501313.jpg" data-lightbox="roadtrip"><img src="csr/350_1586501313.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1586501258.jpg" data-lightbox="roadtrip"><img src="csr/350_1586501258.jpg"></a>
                                    </div>
									<h5>Contributed Rs. 85  Lakhs to the nation towards fight against COVID 19</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1586500613.jpg" data-lightbox="roadtrip"><img src="csr/350_1586500613.jpg"></a>
                                    </div>
									<h5>Distributed Sanitiser, Disinfectant & Masks to Solapur Municipal Corporation</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1586500538.jpg" data-lightbox="roadtrip"><img src="csr/350_1586500538.jpg"></a>
                                    </div>
									<h5>Donated Sanitiser, disinfectant & masks to Subdivisional Police Office, Tuljapur</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1586500424.jpg" data-lightbox="roadtrip"><img src="csr/350_1586500424.jpg"></a>
                                    </div>
									<h5>Donated Sanitiser & Disinfectant to Health Department, Solapur Municipal corporation</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1583836902.jpg" data-lightbox="roadtrip"><img src="csr/350_1583836902.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1583836873.jpg" data-lightbox="roadtrip"><img src="csr/350_1583836873.jpg"></a>
                                    </div>
									<h5>CONSTRUCTED TOILET BLOCK FOR SCHOOL AT Z.P.PRIMARY SCHOOL, WANGI SOUTH SOLAPUR </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1583836791.jpg" data-lightbox="roadtrip"><img src="csr/350_1583836791.jpg"></a>
                                    </div>
									<h5>CONSTRUCTED TOILET BLOCK FOR SCHOOL AT GANGAI SAPATE PRASHALA KANISHTHA MAHAVIDYALAY, TARAPUR NALA, SURLI GAONTHAN</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1582959130.jpg" data-lightbox="roadtrip"><img src="csr/350_1582959130.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1582959116.jpg" data-lightbox="roadtrip"><img src="csr/350_1582959116.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1582959105.jpg" data-lightbox="roadtrip"><img src="csr/350_1582959105.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1582957886.jpg" data-lightbox="roadtrip"><img src="csr/350_1582957886.jpg"></a>
                                    </div>
									<h5>CONSTRUCTED TOILET BLOCK AT SRI CHATRAPATI SHIVAJI VIDYALAY, PIMPLA (KHURD)</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1582957850.jpg" data-lightbox="roadtrip"><img src="csr/350_1582957850.jpg"></a>
                                    </div>
									<h5>CONSTRUCTED TOILET BLOCK AT DATTU PATIL (AANA) MADYAMIC VIDYALAY, CHIVARI</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1582957828.jpg" data-lightbox="roadtrip"><img src="csr/350_1582957828.jpg"></a>
                                    </div>
									<h5>CONSTRUCTED 2 CLASSROOMS AT SRI RAM MADHYAMIC VIDHYALAY, DHOTRI</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1582957800.jpg" data-lightbox="roadtrip"><img src="csr/350_1582957800.jpg"></a>
                                    </div>
									<h5>CONSTRUCTED 2 CLASSROOMS AT SRI RAM MADHYAMIC VIDHYALAY, DHOTRI...</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1582957776.jpg" data-lightbox="roadtrip"><img src="csr/350_1582957776.jpg"></a>
                                    </div>
									<h5>AT THE TIME OF INNAUGARATING ROAD CONSTRUCTION WORK AT GRAMPANCHAYAT KARYALAY, TAMALWADI</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1582957711.jpg" data-lightbox="roadtrip"><img src="csr/350_1582957711.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF SMART BOARD TO LOKSEVA VIDYALAY, AAGALGAON, BARSHI, SOLAPUR ON 25.02.2020</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1582957688.jpg" data-lightbox="roadtrip"><img src="csr/350_1582957688.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF 192  BENCHES TO 8 VARIOUS  SCHOOLS OF SOLAPUR DISTRICT ON 25.02.2020</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1582957657.jpg" data-lightbox="roadtrip"><img src="csr/350_1582957657.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF 13 COMPUTERS TO VARIOUS SCHOOLS OF SOLAPUR DISTRICT ON 25.02.2020</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1582957631.jpg" data-lightbox="roadtrip"><img src="csr/350_1582957631.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF 10 PROJECTORS TO VARIOUS SCHOOLS OF SOLAPUR DISTRICT ON 25.02.2020</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1582957583.jpg" data-lightbox="roadtrip"><img src="csr/350_1582957583.jpg"></a>
                                    </div>
									<h5> DISTRIBUTED INVERETR TO SRI SOMESHWAR HIGH SCHOOL, HATTUR, SOLAPUR ON 25.02.2020</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1582957486.jpg" data-lightbox="roadtrip"><img src="csr/350_1582957486.jpg"></a>
                                    </div>
									<h5>AT THE TIME OF DISTRIBUTION OF LAB EQUIPMENTS TO 3 SCHOOLS OF SOLPAUR DISTRICT ON 25.02.2020</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1579865506.jpg" data-lightbox="roadtrip"><img src="csr/350_1579865506.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1579865157.jpg" data-lightbox="roadtrip"><img src="csr/350_1579865157.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF PROJECTORS TO 5 VARIOUS RURAL SCHOOLS OF OSMANABAD DISTRICT ON 22.01.2020</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1579865121.jpg" data-lightbox="roadtrip"><img src="csr/350_1579865121.jpg"></a>
                                    </div>
									<h5>AT THE TIME OF DISTRIBUTION OF LAB EQUIPMENTS TO SCHOOLS OF OSMANABAD DISTRICT ON 22.01.2020</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1579865076.jpg" data-lightbox="roadtrip"><img src="csr/350_1579865076.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF SCHOOL BENCHES TO 5 VARIOUS RURAL SCHOOLS OF OSMANABAD DISTRICT ON 22.01.2020</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1579865031.jpg" data-lightbox="roadtrip"><img src="csr/350_1579865031.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF COMPUTERS TO 7 VARIOUS RURAL SCHOOLS OF OSMANABAD DISTRICT ON 22.01.2020</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1579864919.jpg" data-lightbox="roadtrip"><img src="csr/350_1579864919.jpg"></a>
                                    </div>
									<h5>INAUGURATION OF ATAL TINKERING SCIENCE LAB AT NARENDRA ARYA VIDYALAY, AAPSINGA, DIST-OSMANABAD, CONSTRUCTED BY BALAJI AMINES LIMITED.</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1579864604.jpg" data-lightbox="roadtrip"><img src="csr/350_1579864604.jpg"></a>
                                    </div>
									<h5>INAUGURATION OF ATAL TINKERING SCIENCE LAB AT NARENDRA ARYA VIDYALAY, AAPSINGA, DIST-OSMANABAD, CONSTRUCTED BY BALAJI AMINES LIMITED</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1577529229.jpg" data-lightbox="roadtrip"><img src="csr/350_1577529229.jpg"></a>
                                    </div>
									<h5>HANDOVER CEREMONY OF SYNTHETIC BASKET BALL GROUND AT PUNYASHLOK AHILYADEVI HOLKAR SOLAPUR UNIVERSITY, SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1577529144.jpg" data-lightbox="roadtrip"><img src="csr/350_1577529144.jpg"></a>
                                    </div>
									<h5>CONSTRUCTED SYNTHETIC BASKET BALL GROUND AT PUNYASHLOK AHILYADEVI HOLKAR SOLAPUR UNIVERSITY, SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1577529052.jpg" data-lightbox="roadtrip"><img src="csr/350_1577529052.jpg"></a>
                                    </div>
									<h5>CONSTRUCTED TOILET BLOCK AT RITESH VIDYALAY, THOBADE VASTI, DEGAON ROAD, SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1576239572.jpg" data-lightbox="roadtrip"><img src="csr/350_1576239572.jpg"></a>
                                    </div>
									<h5>DONATED CRICKET BOWLING MACHINE TO SOLAPUR SOCIAL & SPORTS INSTITUTE, SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1576239541.jpg" data-lightbox="roadtrip"><img src="csr/350_1576239541.jpg"></a>
                                    </div>
									<h5>CONSTRUCTED TOILET BLOCK AT HABIBA SHIKSHAN PRASARAK PRATISHTHAN, SOREGAON, SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1576239469.jpg" data-lightbox="roadtrip"><img src="csr/350_1576239469.jpg"></a>
                                    </div>
									<h5> CONSTRUCTED TOILET BLOCK AT STATE RESERVE POLICE FORCE , SOREGAON, SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1576239437.jpg" data-lightbox="roadtrip"><img src="csr/350_1576239437.jpg"></a>
                                    </div>
									<h5>INSTALLED RO PLANT AT  K.A.GOSAVI SCHOOL, MAJREWADI, SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1576239402.jpg" data-lightbox="roadtrip"><img src="csr/350_1576239402.jpg"></a>
                                    </div>
									<h5>DONATED AUTOBOOK  SCANNER & READER TO RAJIV GANDHI MEMORIAL SCHOOL FOR THE BLIND, SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1576239393.jpg" data-lightbox="roadtrip"><img src="csr/350_1576239393.jpg"></a>
                                    </div>
									<h5>DONATED AUTOBOOK  SCANNER & READER TO RAJIV GANDHI MEMORIAL SCHOOL FOR THE BLIND, SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1576239350.jpg" data-lightbox="roadtrip"><img src="csr/350_1576239350.jpg"></a>
                                    </div>
									<h5>CONSTRUCTED & HANDED OVER SCIENCE LABORATORY TO CHATRAPATI SHAHU MAHARAJ MADYA. VIDYALAY, MASALA (KHURD)</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1576239341.jpg" data-lightbox="roadtrip"><img src="csr/350_1576239341.jpg"></a>
                                    </div>
									<h5>CONSTRUCTED & HANDED OVER SCIENCE LABORATORY TO CHATRAPATI SHAHU MAHARAJ MADYA. VIDYALAY, MASALA (KHURD)</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1576239305.jpg" data-lightbox="roadtrip"><img src="csr/350_1576239305.jpg"></a>
                                    </div>
									<h5>HAND OVER CEREMONY OF POLICE STATION CONSTRUCTED BY BALAJI AMINES LIMITED</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1576239292.jpg" data-lightbox="roadtrip"><img src="csr/350_1576239292.jpg"></a>
                                    </div>
									<h5>HAND OVER CEREMONY OF POLICE STATION CONSTRUCTED BY BALAJI AMINES LIMITED</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1576239253.jpg" data-lightbox="roadtrip"><img src="csr/350_1576239253.jpg"></a>
                                    </div>
									<h5>DISTRIBUTION OF WHEEL CHAIRS TO DRM OFFICE INDIAN RAILWAYS, SOLAPUR</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1576239196.jpg" data-lightbox="roadtrip"><img src="csr/350_1576239196.jpg"></a>
                                    </div>
									<h5> WATER SAVING & CONSERVATION AT GRAMPANCHAYAT, RANMASALE</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1576239138.jpg" data-lightbox="roadtrip"><img src="csr/350_1576239138.jpg"></a>
                                    </div>
									<h5> WATER SAVING & CONSERVATION AT GRAMPANCHAYAT, RANMASALE</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1576239066.jpg" data-lightbox="roadtrip"><img src="csr/350_1576239066.jpg"></a>
                                    </div>
									<h5>WATER SAVING & CONSERVATION AT GRAMPANCHAYAT KARYALAY, ARANGAON</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1576239052.jpg" data-lightbox="roadtrip"><img src="csr/350_1576239052.jpg"></a>
                                    </div>
									<h5>WATER SAVING & CONSERVATION AT GRAMPANCHAYAT KARYALAY, ARANGAON</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1560143696.jpg" data-lightbox="roadtrip"><img src="csr/350_1560143696.jpg"></a>
                                    </div>
									<h5>Distribution of Smart Boards to Schools</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1560143660.jpg" data-lightbox="roadtrip"><img src="csr/350_1560143660.jpg"></a>
                                    </div>
									<h5>Distribution of Study Desks to Schools</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1560143297.jpg" data-lightbox="roadtrip"><img src="csr/350_1560143297.jpg"></a>
                                    </div>
									<h5>Distribution of Study Desks to Schools</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1551846495.jpg" data-lightbox="roadtrip"><img src="csr/350_1551846495.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1543473058.jpg" data-lightbox="roadtrip"><img src="csr/350_1543473058.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1543472758.jpg" data-lightbox="roadtrip"><img src="csr/350_1543472758.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1543472719.jpg" data-lightbox="roadtrip"><img src="csr/350_1543472719.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1543472560.jpg" data-lightbox="roadtrip"><img src="csr/350_1543472560.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1543472514.jpg" data-lightbox="roadtrip"><img src="csr/350_1543472514.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1543472433.jpg" data-lightbox="roadtrip"><img src="csr/350_1543472433.jpg"></a>
                                    </div>
									<h5> </h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1543299047.jpg" data-lightbox="roadtrip"><img src="csr/350_1543299047.jpg"></a>
                                    </div>
									<h5>Distribution of Computer Systems to ZP School, Ganjewadi</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1543298741.jpg" data-lightbox="roadtrip"><img src="csr/350_1543298741.jpg"></a>
                                    </div>
									<h5>Mini School Bust distributed to Aapal Ghar, Naladurg</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1543298015.jpg" data-lightbox="roadtrip"><img src="csr/350_1543298015.jpg"></a>
                                    </div>
									<h5>At the time of inauguration of Surveillance camera's installed at Aasara Chowk, Solapur by BAL</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1543297706.jpg" data-lightbox="roadtrip"><img src="csr/350_1543297706.jpg"></a>
                                    </div>
									<h5>E-Learning Kit installed at school L. T. Dasari Prashala by BAL</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1543297480.jpg" data-lightbox="roadtrip"><img src="csr/350_1543297480.jpg"></a>
                                    </div>
									<h5>Toilet Blocks constructed at Devkurli by BAL</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1543297307.jpg" data-lightbox="roadtrip"><img src="csr/350_1543297307.jpg"></a>
                                    </div>
									<h5>Distribution of benches to School Indira Kale Prashala, Jalkotwadi</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1543296985.jpg" data-lightbox="roadtrip"><img src="csr/350_1543296985.jpg"></a>
                                    </div>
									<h5>Toilet Blocks constructed at Pimpla BK by BAL</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1543296578.jpg" data-lightbox="roadtrip"><img src="csr/350_1543296578.jpg"></a>
                                    </div>
									<h5>Distribution of school stationary to Students</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1543296250.jpg" data-lightbox="roadtrip"><img src="csr/350_1543296250.jpg"></a>
                                    </div>
									<h5>At the time of inauguration of Solapur Gramin Police Driver's Rest Room renovated by BAL</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1542133116.jpg" data-lightbox="roadtrip"><img src="csr/350_1542133116.jpg"></a>
                                    </div>
									<h5>COMMUNITY SERVICE</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1542133035.jpg" data-lightbox="roadtrip"><img src="csr/350_1542133035.jpg"></a>
                                    </div>
									<h5>COMMUNITY SERVICE</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1542133016.jpg" data-lightbox="roadtrip"><img src="csr/350_1542133016.jpg"></a>
                                    </div>
									<h5>HEALTHCARE</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1542132998.jpg" data-lightbox="roadtrip"><img src="csr/350_1542132998.jpg"></a>
                                    </div>
									<h5>Education</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1542132980.jpg" data-lightbox="roadtrip"><img src="csr/350_1542132980.jpg"></a>
                                    </div>
									<h5>RURAL DEVELOPMENT</h5>
                                </div>
	                             <div class="col-sm-4 company-image">
								
                                    <div class="thumbnail">
                                        <a class="btn btn-success" href="csr/1542132961.jpg" data-lightbox="roadtrip"><img src="csr/350_1542132961.jpg"></a>
                                    </div>
									<h5>RURAL DEVELOPMENT</h5>
                                </div>
	                            </div>
                    </div>
                
            </div>
        </div>
 <footer class="full-bg " id="footer">

            <div class="container">
                <div class="row">

                    <div class="col-sm-4  widget-cell" id="footer-widget-1">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">ABOUT</h3>
                            <div class="menu-overview-footer-container">
                                <ul id="menu-overview-footer" class="menu">
                                    <li id="menu-item-412" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-412"><a href="company-profile.php">Company Profile</a></li>
                                    <li id="menu-item-415" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-415"><a href="mission-values.php">Mission &#038; Values</a></li>
                                    <li id="menu-item-414" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-414"><a href="certificate-awards.php">Certificate &#038; Awards</a></li>
                                    <li id="menu-item-413" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-413"><a href="balaji-management-team.php">Management Team</a></li>
                                    <li id="menu-item-479" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-479"><a href="balaji-amines-history.php">History</a></li>
                                    <li id="menu-item-709" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-709"><a href="bal-presence.php">BAL&#8217;s Presence</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4  widget-cell">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">PRODUCTS</h3>
                            <div class="menu-overview-footer-1-container">
                                <ul id="menu-overview-footer-1" class="menu">
                                    <li id="menu-item-417" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-417"><a href="amines.php">Amines</a></li>
                                    <li id="menu-item-416" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-416"><a href="derivatives.php">Derivatives</a></li>
                                    <li id="menu-item-418" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-418"><a href="speciality-chemicals.php">Speciality Chemicals</a></li>
                                    <li id="menu-item-679" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-679"><a href="excipients.php">Pharma Excipients</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4  widget-cell">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">OTHERS</h3>
                            <div class="menu-footer3-container">
                                <ul id="menu-footer3" class="menu">
                                    <li id="menu-item-655" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-655"><a href="investor-relations.php">Investor Relations</a></li>
                                    <li id="menu-item-420" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-286 current_page_item menu-item-420 active"><a href="careers.php">Careers</a></li>
                                    <li id="menu-item-421" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-421"><a href="corporate-social-responsibility.php">Corporate Social Responsibility</a></li>
                                    <li id="menu-item-713" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-713"><a href="e-brochures.php">E-Brochure</a></li>
                                    <li id="menu-item-423" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-423"><a href="balaji-media.php">Media</a></li>
                                    <li id="menu-item-422" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-422"><a href="contact-us.php">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-1  widget-cell col-sm-offset-1">
                        <div class="widget widget_text">
                            <div class="textwidget"></div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="row">
                            <div class="col-sm-12" id="social-media-icons"></div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 col-sm-offset-6"></div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
		<div class="container-fluid">
            <div class="ddl-full-width-row row">
                <div class="col-sm-12 copyright-footer">
                    <p>copyright © balaji Amines 2025 Developed By <a href="http://katareinfo.com/">Katrare Informatics</a></p>
                </div>
            </div>
        </div>
    </div>
    <!--</div>-->
    <!-- .container & canvas-->
    <script type="text/html" id="tmpl-wp-playlist-current-item">
        <# if ( data.image ) { #>
            <img src="{{ data.thumb.src }}" alt="" />
            <# } #>
                <div class="wp-playlist-caption">
                    <span class="wp-playlist-item-meta wp-playlist-item-title">&#8220;{{ data.title }}&#8221;</span>
                    <# if ( data.meta.album ) { #><span class="wp-playlist-item-meta wp-playlist-item-album">{{ data.meta.album }}</span>
                        <# } #>
                            <# if ( data.meta.artist ) { #><span class="wp-playlist-item-meta wp-playlist-item-artist">{{ data.meta.artist }}</span>
                                <# } #>
                </div>
    </script>
    <script type="text/html" id="tmpl-wp-playlist-item">
        <div class="wp-playlist-item">
            <a class="wp-playlist-caption" href="{{ data.src }}">
			{{ data.index ? ( data.index + '. ' ) : '' }}
			<# if ( data.caption ) { #>
				{{ data.caption }}
			<# } else { #>
				<span class="wp-playlist-item-title">&#8220;{{{ data.title }}}&#8221;</span>
				<# if ( data.artists && data.meta.artist ) { #>
				<span class="wp-playlist-item-artist"> &mdash; {{ data.meta.artist }}</span>
				<# } #>
			<# } #>
		</a>
            <# if ( data.meta.length_formatted ) { #>
                <div class="wp-playlist-item-length">{{ data.meta.length_formatted }}</div>
                <# } #>
        </div>
    </script>
    <script type='text/javascript' src='wp-content/themes/toolset-bootstrap/bootstrap3/js/bootstrap.min.js?ver=3.3.4'></script>
    <script type='text/javascript' src='wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
    <script type='text/javascript' src='wp-includes/js/jquery/ui/datepicker.min.js?ver=1.11.4'></script>
    <script type='text/javascript'>
        jQuery(document).ready(function(jQuery) {
            jQuery.datepicker.setDefaults({
                "closeText": "Close",
                "currentText": "Today",
                "monthNames": ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                "monthNamesShort": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                "nextText": "Next",
                "prevText": "Previous",
                "dayNames": ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                "dayNamesShort": ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                "dayNamesMin": ["S", "M", "T", "W", "T", "F", "S"],
                "dateFormat": "MM d, yy",
                "firstDay": 1,
                "isRTL": false
            });
        });
    </script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var mejsL10n = {
            "language": "en-US",
            "strings": {
                "Close": "Close",
                "Fullscreen": "Fullscreen",
                "Turn off Fullscreen": "Turn off Fullscreen",
                "Go Fullscreen": "Go Fullscreen",
                "Download File": "Download File",
                "Download Video": "Download Video",
                "Play": "Play",
                "Pause": "Pause",
                "Captions\/Subtitles": "Captions\/Subtitles",
                "None": "None",
                "Time Slider": "Time Slider",
                "Skip back %1 seconds": "Skip back %1 seconds",
                "Video Player": "Video Player",
                "Audio Player": "Audio Player",
                "Volume Slider": "Volume Slider",
                "Mute Toggle": "Mute Toggle",
                "Unmute": "Unmute",
                "Mute": "Mute",
                "Use Up\/Down Arrow keys to increase or decrease volume.": "Use Up\/Down Arrow keys to increase or decrease volume.",
                "Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.": "Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds."
            }
        };
        var _wpmejsSettings = {
            "pluginPath": "\/wp-includes\/js\/mediaelement\/"
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='wp-includes/js/mediaelement/mediaelement-and-player.min.js?ver=2.22.0'></script>
    <script type='text/javascript' src='wp-includes/js/mediaelement/wp-mediaelement.min.js?ver=4.7.3'></script>
    <script type='text/javascript' src='wp-includes/js/underscore.min.js?ver=1.8.3'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var _wpUtilSettings = {
            "ajax": {
                "url": "\/wp-admin\/admin-ajax.php"
            }
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='wp-includes/js/wp-util.min.js?ver=4.7.3'></script>
    <script type='text/javascript' src='wp-includes/js/backbone.min.js?ver=1.2.3'></script>
    <script type='text/javascript' src='wp-includes/js/mediaelement/wp-playlist.min.js?ver=4.7.3'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var wpv_pagination_local = {
            "front_ajaxurl": "http:\/\/www.balajiamines.in\/wp-admin\/admin-ajax.php",
            "ajax_pagination_url": "http:\/\/www.balajiamines.in\/wpv-ajax-pagination\/",
            "calendar_image": "http:\/\/www.balajiamines.in\/wp-content\/plugins\/wp-views\/embedded\/res\/img\/calendar.gif",
            "calendar_text": "Select date",
            "datepicker_min_date": null,
            "datepicker_max_date": null
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='wp-content/plugins/wp-views/embedded/res/js/wpv-pagination-embedded.js?ver=1.10'></script>
    <script type='text/javascript' src='wp-includes/js/wp-embed.min.js?ver=4.7.3'></script>
    <script>
        jQuery(window).scroll(function() {
            if (jQuery(document).scrollTop() > 50) {
                jQuery('header').addClass('shrink');
            } else {
                jQuery('header').removeClass('shrink');
            }
        });

        /*Youtube video*/
        jQuery('.js-lazyYT').lazyYT();

        /** Stop playing youtube video when page scrolls */

        jQuery(document).on('scroll', function() {
            var scrollTop = jQuery(window).scrollTop();
            if (scrollTop > pos.top + 315) {
                player.stopVideo();
            }
        })
    </script>
    <script>
        /* moving object */
        jQuery('.marquee').marquee({
            //speed in milliseconds of the marquee
            duration: 6000,
            //gap in pixels between the tickers
            gap: 1500,
            //time in milliseconds before the marquee will start animating
            delayBeforeStart: 0,
            //'left' or 'right'
            direction: 'right',
            //true or false - should the marquee be duplicated to show an effect of continues flow
            duplicated: true
        });
    </script>
    <script>
        jQuery(document).ready(function() {

            /* Apply fancybox to multiple items */

            jQuery("a.balaji-products").fancybox({
                'transitionIn': 'elastic',
                'transitionOut': 'elastic',
                'speedIn': 600,
                'speedOut': 200,
                'overlayShow': false
            });

            jQuery('.member-mug-shot').on('click', function() {
                jQuery('.collapse').collapse('hide');
            })

        });
    </script>
    <script>
        (function(jQuery) {
            jQuery(document).ready(function() {
                jQuery(".video-button").click(function() {
                    jQuery(".video-embed").css({
                        "opacity": "1",
                        "display": "block"
                    });
                    jQuery(".video-embed")[0].src += "&autoplay=1";
                    jQuery(this).unbind("click");
                });
            });
        })(jQuery)
    </script>
    <script>
        jQuery(document).ready(function() {

            jQuery('.fancybox').fancybox({
                beforeShow: function() {
                    this.title = jQuery(this.element).data("caption");
                }
            });

            jQuery("a#single_image-popup").fancybox();

        });
    </script>
    <script>
        jQuery(window).load(function() {
            jQuery('#single_image-popup').fancybox({
                beforeLoad: function() {
                    this.title = jQuery(this.element).find('img').attr('alt');
                }

            });

            jQuery('#single_image-popup').fancybox({
                'titleFromAlt': true,
                'titlePosition': 'inside'

            });

            jQuery("a#single_image-popup").trigger('click');
        });
    </script>
    <script>
        function myFunction() {
            window.print();
        }
    </script>
</body>

</html>