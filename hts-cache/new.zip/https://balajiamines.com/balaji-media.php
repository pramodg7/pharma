<!DOCTYPE html>
<html lang="en-US" class="no-js">

<head>
    <meta charset="UTF-8" />
		<meta name="author" content="Balaji Amines" />
	<meta name="keywords" content=" balaji , balaji amines, balaji amines solapur, Chemical Manufacturers in India, Chemical Manufacturers India, Industrial Chemicals Manufacturers, Industrial Chemicals Manufacturers in India Chemical manufacturing company in india, Chemical manufacturing company in Solapur, Chemical manufacturing company, methyl, Chemical Manufacturer,hydrochloride derivatives, industrial chemicals manufacturers, industrial chemicals suppliers, industrial chemicals india, industrial chemicals exporters, industrial chemicals manufacturer, industrial chemicals supplier, industrial chemicals exporter, industrial chemicals from india, industrial chemicals wholesale, industrial chemicals in india">
	<meta name="description"  content="Manufacturer of methyl and ethyl amines and their amide and hydrochloride derivatives, located in India.  Chemical manufacturing company in india">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>Balaji &ndash; Media</title>
    <style type="text/css">
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 .07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
    <link rel='stylesheet' id='formidable-css' href='wp-content/uploads/formidable/css/formidablepro.css?ver=2.03.03' type='text/css' media='all' />
    <link rel='stylesheet' id='wp_ddl_layout_fe_css-css' href='wp-content/uploads/ddl-layouts-tmp/d41d8cd98f00b204e9800998ecf8427e.css?ver=1.3.2' type='text/css' media='screen' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3/css/bootstrap.min.css?ver=3.3.4' type='text/css' media='all' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_theme_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3/css/bootstrap-theme.min.css' type='text/css' media='all' />
    <link rel='stylesheet' id='toolset-bootstrap-theme-style-css' href='wp-content/themes/toolset-bootstrap/style.css?ver=1.8' type='text/css' media='all' />
    <link rel='stylesheet' id='wpbootstrap_bootstrap_main_three_adjustment_css-css' href='wp-content/themes/toolset-bootstrap/bootstrap3_adjustment.css' type='text/css' media='all' />
    <link rel='stylesheet' id='menu-cells-front-end-css' href='wp-content/plugins/layouts/resources/css/cell-menu-css.css?ver=4.7.3' type='text/css' media='screen' />
    <link rel='stylesheet' id='ddl-front-end-css' href='wp-content/plugins/layouts/resources/css/ddl-front-end.css?ver=4.7.3' type='text/css' media='screen' />
    <link rel='stylesheet' id='toolset-common-css' href='wp-content/plugins/layouts/toolset/toolset-common/res/css/toolset-common.css?ver=4.7.3' type='text/css' media='screen' />
    <link rel='stylesheet' id='wptoolset-field-datepicker-css' href='wp-content/plugins/wp-views/embedded/common/toolset-forms/css/wpt-jquery-ui/datepicker.css?ver=1.10' type='text/css' media='all' />
    <link rel='stylesheet' id='mediaelement-css' href='wp-includes/js/mediaelement/mediaelementplayer.min.css?ver=2.22.0' type='text/css' media='all' />
    <link rel='stylesheet' id='wp-mediaelement-css' href='wp-includes/js/mediaelement/wp-mediaelement.min.css?ver=4.7.3' type='text/css' media='all' />
    <link rel='stylesheet' id='views-pagination-style-css' href='wp-content/plugins/wp-views/embedded/res/css/wpv-pagination.css?ver=1.10' type='text/css' media='all' />
    <script type='text/javascript' src='wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
    <script type='text/javascript' src='wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
    <script type='text/javascript'>
        /* <![CDATA[ */
        var DDLayout_fe_settings = {
            "DDL_JS": {
                "css_framework": "bootstrap-3",
                "DEBUG": false
            }
        };
        /* ]]> */
    </script>
    <script type='text/javascript' src='wp-content/plugins/layouts/resources/js/ddl-layouts-frontend.js?ver=1.3.2'></script>
    <link rel='https://api.w.org/' href='wp-json/' />
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="xmlrpc.php?rsd" />
    <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="wp-includes/wlwmanifest.xml" />
    <meta name="generator" content="WordPress 4.7.3" />
    <link rel="canonical" href="media/" />
    <link rel='shortlink' href='?p=82' />
    <link rel="alternate" type="application/json+oembed" href="wp-json/oembed/1.0/embed?url=http%3A%2F%2Fwww.balajiamines.in%2Fmedia%2F" />
    <link rel="alternate" type="text/xml+oembed" href="wp-json/oembed/1.0/embed?url=http%3A%2F%2Fwww.balajiamines.in%2Fmedia%2F&#038;format=xml" />
    <style type="text/css">
        .recentcomments a {
            display: inline !important;
            padding: 0 !important;
            margin: 0 !important;
        }
    </style>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/owl.carousel.css">
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/owl.theme.css">
    <script src="wp-content/themes/toolset-bootstrap/js/owl.carousel.js"></script>
    <script type="text/javascript" src="wp-content/themes/toolset-bootstrap/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/fancybox/jquery.fancybox-1.3.4.css" type="text/css" media="screen" />
    <link href='https://fonts.googleapis.com/css?family=Khand:400,300,500,600,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,100italic,100,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
    <link rel='stylesheet' href="wp-content/themes/toolset-bootstrap/css/mediatree.css">
    <link rel='stylesheet' media="print" href="wp-content/themes/toolset-bootstrap/css/custom-print.css">
    <link rel='stylesheet' href="wp-content/themes/toolset-bootstrap/css/zara.css">
    <link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>
    <link href="wp-content/themes/toolset-bootstrap/css/jasny-bootstrap.min.css" rel="stylesheet" media="screen">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.matchHeight.js"></script>
    <script src="wp-content/themes/toolset-bootstrap/js/jasny-bootstrap.min.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/css/flexslider.css" type="text/css">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.flexslider.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <script src="wp-content/themes/toolset-bootstrap/js/jquery.matchHeight-min.js" type="text/javascript"></script>
    <script type="text/javascript" src="wp-content/themes/toolset-bootstrap/lazyyt/lazyYT.js"></script>
    <link rel="stylesheet" href="wp-content/themes/toolset-bootstrap/lazyyt/lazyYT.css">
    <script type='text/javascript' src='//cdn.jsdelivr.net/jquery.marquee/1.3.1/jquery.marquee.min.js'></script>
</head>

<body class="page-template page-template-page-layouts page-template-page-layouts-php page page-id-82">
    <!-- Off Canvas Menu Starts -->
        <div class="navmenu navmenu-default navmenu-fixed-right">
        <ul id="menu-menu-1" class="nav navmenu-nav">
            <li id="menu-item-20" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-2 current_page_item menu-item-20 active"><a href="index.php">Homepage</a></li>
            <li id="menu-item-656" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-656"><a href="#">About us</a>
                <ul class="sub-menu">
                    <li id="menu-item-267" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-267"><a href="company-profile.php">Company Profile</a></li>
                    <li id="menu-item-261" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-261"><a href="mission-values.php">Mission &#038; Values</a></li>
                    <li id="menu-item-280" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-280"><a href="certificate-awards.php">Certificate &#038; Awards</a></li>
                    <li id="menu-item-348" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-348"><a href="balaji-management-team.php">Management Team</a></li>
                    <li id="menu-item-339" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-339"><a href="balaji-amines-history.php">History</a></li>
                    <li id="menu-item-710" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-710"><a href="bal-presence.php">BAL&#8217;s Presence</a></li>
                </ul>
            </li>
            <li id="menu-item-400" class="menu-item menu-item-type-post_type_archive menu-item-object-product menu-item-has-children menu-item-400"><a href="category.php">Products</a>
                <ul class="sub-menu">
                    <li id="menu-item-658" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-658"><a href="amines.php">Amines</a></li>
                    <li id="menu-item-657" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-657"><a href="derivatives.php">Derivatives</a></li>
                    <li id="menu-item-659" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-659"><a href="speciality-chemicals.php">Speciality Chemicals</a></li>
                    <li id="menu-item-678" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-678"><a href="excipients.php">Pharma Excipients</a></li>
                </ul>
            </li>
            <li id="menu-item-534" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-534"><a href="investor-relations.php">Investor Relations</a></li>
            <li id="menu-item-290" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-290"><a href="careers.php">Careers</a></li>
            <li id="menu-item-299" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-299"><a href="corporate-social-responsibility.php">Corporate Social Responsibility</a></li>
            <li id="menu-item-282" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-282"><a href="contact-us.php">Contact Us</a></li>
            <li id="menu-item-307" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-307"><a href="balaji-media.php">Media</a></li>
            <li id="menu-item-711" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-711"><a href="e-brochures.php">E-Brochure</a></li>
        </ul>
    </div>        <!-- Off Canvas Menu Ends -->
        <div class="canvas">
            <header class="full-bg black-bg" id="homepage-header">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-1" id="off-canvas-button">
                            <div class="navbar navbar-default">
                                <button type="button" class="navbar-toggle" data-toggle="offcanvas" data-recalc="false" data-target=".navmenu" data-canvas=".canvas">
                                    <br />
                                    <span class="icon-bar"></span>
                                    <br />
                                    <span class="icon-bar"></span>
                                    <br />
                                    <span class="icon-bar"></span>
                                    <br />
                                </button>
                            </div>
                        </div>
                        <div class="col-sm-4 col-sm-offset-3" id="homepage-logo">
                            <p></p>
                            <p>
                                <a href=""><img src="wp-content/uploads/2015/10/balaji_logo.png" alt="Balaji Almines" class="aligncenter size-full img-responsive"></a>
                            </p>
                        </div>
                    </div>
                </div>
            </header>
            <div class="container-fluid">
                <div class="ddl-full-width-row row">
                    <div class="col-sm-12 featured-thumbnail">
                        <div class="thumbnail">
                            <img src="wp-content/uploads/2015/10/media_banner.jpg">
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">

                    <div class="col-sm-4 page-title-div text-center col-sm-offset-4">
                        <h1>MEDIA</h1>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">

                    <div class="col-sm-4 heading-color col-sm-offset-4" id="media">
                        <h2 style="text-align: center;">VIDEOS</h2>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">

                    <div class="col-sm-12">
                        <div id="envira-gallery-wrap-312" class="envira-gallery-wrap envira-gallery-theme-base envira-lightbox-theme-base">
                            <div id="envira-gallery-312" class="envira-gallery-public envira-gallery-4-columns envira-clear enviratope envira-gallery-css-animations" data-envira-columns="4">
														
                                <div id="envira-gallery-item-1" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/BYmB916PYzM?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1506078337.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-1" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1506078337.jpg" data-envira-src="medias/480_1506078337.jpg" data-envira-item-id="1" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-2" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/eWN6MX_9gGE?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1506078387.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-2" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1506078387.jpg" data-envira-src="medias/480_1506078387.jpg" data-envira-item-id="2" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-3" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/cMVst28qiNE?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1506078412.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-3" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1506078412.jpg" data-envira-src="medias/480_1506078412.jpg" data-envira-item-id="3" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-4" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/IHfq7YqnEmQ?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1506078459.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-4" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1506078459.jpg" data-envira-src="medias/480_1506078459.jpg" data-envira-item-id="4" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-5" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/IHfq7YqnEmQ?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1506078491.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-5" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1506078491.jpg" data-envira-src="medias/480_1506078491.jpg" data-envira-item-id="5" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-6" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/bTGjwjA1LjI?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1506078555.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-6" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1506078555.jpg" data-envira-src="medias/480_1506078555.jpg" data-envira-item-id="6" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-7" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/Xh9fWD824kc?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1506078576.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-7" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1506078576.jpg" data-envira-src="medias/480_1506078576.jpg" data-envira-item-id="7" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-8" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/BYmB916PYzM?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1506078659.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-8" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1506078659.jpg" data-envira-src="medias/480_1506078659.jpg" data-envira-item-id="8" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-9" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/eWN6MX_9gGE?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1506078695.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-9" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1506078695.jpg" data-envira-src="medias/480_1506078695.jpg" data-envira-item-id="9" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-10" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/cMVst28qiNE?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1506078747.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-10" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1506078747.jpg" data-envira-src="medias/480_1506078747.jpg" data-envira-item-id="10" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-11" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/Sr27GYpVIr4?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1506078789.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-11" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1506078789.jpg" data-envira-src="medias/480_1506078789.jpg" data-envira-item-id="11" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-12" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/SathZz35rlg?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1506078832.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-12" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1506078832.jpg" data-envira-src="medias/480_1506078832.jpg" data-envira-item-id="12" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-13" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/dU9TEwkE4uc?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1506078867.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-13" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1506078867.jpg" data-envira-src="medias/480_1506078867.jpg" data-envira-item-id="13" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-14" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/a3usEcoek2k?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1506080709.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-14" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1506080709.jpg" data-envira-src="medias/480_1506080709.jpg" data-envira-item-id="14" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-15" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/B_pcairRNJ4?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1506080742.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-15" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1506080742.jpg" data-envira-src="medias/480_1506080742.jpg" data-envira-item-id="15" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-16" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/ytpd5Ekg2Q4?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1506080776.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-16" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1506080776.jpg" data-envira-src="medias/480_1506080776.jpg" data-envira-item-id="16" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-17" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/NJa3_UI7Yes?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1507486504.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-17" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1507486504.jpg" data-envira-src="medias/480_1507486504.jpg" data-envira-item-id="17" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-18" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/YNOS9ozPM_8?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1507486533.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-18" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1507486533.jpg" data-envira-src="medias/480_1507486533.jpg" data-envira-item-id="18" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-19" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/o0gmYIgLDi0?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1507486555.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-19" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1507486555.jpg" data-envira-src="medias/480_1507486555.jpg" data-envira-item-id="19" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-21" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/9EOjWu_FthE?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1509445258.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-21" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1509445258.jpg" data-envira-src="medias/480_1509445258.jpg" data-envira-item-id="21" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-24" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/B4n5FS7FEKo?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1509526696.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-24" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1509526696.jpg" data-envira-src="medias/480_1509526696.jpg" data-envira-item-id="24" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-25" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/jD2VKYE4ei4?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1512475512.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-25" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1512475512.jpg" data-envira-src="medias/480_1512475512.jpg" data-envira-item-id="25" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-26" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/8HLM1-yvJu8?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1512554139.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-26" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1512554139.jpg" data-envira-src="medias/480_1512554139.jpg" data-envira-item-id="26" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-28" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/JOjJ24K36aQ?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1517373059.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-28" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1517373059.jpg" data-envira-src="medias/480_1517373059.jpg" data-envira-item-id="28" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-29" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/6rkf2wnwwOU?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1519373059.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-29" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1519373059.jpg" data-envira-src="medias/480_1519373059.jpg" data-envira-item-id="29" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-30" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/QyroZpkNxKw?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1521625512.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-30" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1521625512.jpg" data-envira-src="medias/480_1521625512.jpg" data-envira-item-id="30" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-31" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/dBSKw-IMqC4?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1521632903.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-31" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1521632903.jpg" data-envira-src="medias/480_1521632903.jpg" data-envira-item-id="31" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-35" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/KJFoOOPtfg0?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1533102531.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-35" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1533102531.jpg" data-envira-src="medias/480_1533102531.jpg" data-envira-item-id="35" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-36" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/aeLOqXDZ6ns?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1542882410.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-36" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1542882410.jpg" data-envira-src="medias/480_1542882410.jpg" data-envira-item-id="36" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-37" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/upOw34O6c_Q?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1548743390.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-37" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1548743390.jpg" data-envira-src="medias/480_1548743390.jpg" data-envira-item-id="37" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-40" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/-dpuO-3jR_Y?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1548762019.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-40" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1548762019.jpg" data-envira-src="medias/480_1548762019.jpg" data-envira-item-id="40" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-42" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/zKo3gvPco_I?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1553923341.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-42" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1553923341.jpg" data-envira-src="medias/480_1553923341.jpg" data-envira-item-id="42" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-43" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/UyNuOtvcc84?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1564465788.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-43" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1564465788.jpg" data-envira-src="medias/480_1564465788.jpg" data-envira-item-id="43" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-46" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/Z0TEzyLyk0Y?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1574324964.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-46" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1574324964.jpg" data-envira-src="medias/480_1574324964.jpg" data-envira-item-id="46" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-47" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/3oHofCXFOvM?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1575091360.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-47" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1575091360.jpg" data-envira-src="medias/480_1575091360.jpg" data-envira-item-id="47" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-48" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/YYZBIriNkIo?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1596881464.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-48" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1596881464.jpg" data-envira-src="medias/480_1596881464.jpg" data-envira-item-id="48" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-49" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/YTarukZzYH4?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1597736664.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-49" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1597736664.jpg" data-envira-src="medias/480_1597736664.jpg" data-envira-item-id="49" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-50" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/7ASup9inUbc?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1603958427.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-50" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1603958427.jpg" data-envira-src="medias/480_1603958427.jpg" data-envira-item-id="50" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-52" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/PwNFngCm08U?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1612855841.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-52" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1612855841.jpg" data-envira-src="medias/480_1612855841.jpg" data-envira-item-id="52" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-53" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/bRKHVBtWtEQ?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1612856114.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-53" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1612856114.jpg" data-envira-src="medias/480_1612856114.jpg" data-envira-item-id="53" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-55" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/JutG3Ua3QMA?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1622011316.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-55" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1622011316.jpg" data-envira-src="medias/480_1622011316.jpg" data-envira-item-id="55" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-56" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/Yd_wrzrQWKg?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1622011666.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-56" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1622011666.jpg" data-envira-src="medias/480_1622011666.jpg" data-envira-item-id="56" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-57" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/UGKxP_WxFks?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1622700077.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-57" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1622700077.jpg" data-envira-src="medias/480_1622700077.jpg" data-envira-item-id="57" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-58" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/X2ga4chCP3Q?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1628770736.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-58" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1628770736.jpg" data-envira-src="medias/480_1628770736.jpg" data-envira-item-id="58" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-59" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/tAWqlXcACmg?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1630151434.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-59" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1630151434.jpg" data-envira-src="medias/480_1630151434.jpg" data-envira-item-id="59" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-60" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/aKLCxNWiaBc?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1635409634.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-60" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1635409634.jpg" data-envira-src="medias/480_1635409634.jpg" data-envira-item-id="60" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-61" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/zbUZhXaJwSQ?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1643872689.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-61" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1643872689.jpg" data-envira-src="medias/480_1643872689.jpg" data-envira-item-id="61" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-62" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/jz1hducaMig?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1643873260.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-62" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1643873260.jpg" data-envira-src="medias/480_1643873260.jpg" data-envira-item-id="62" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-63" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/iWooLmwsifs?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1652369064.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-63" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1652369064.jpg" data-envira-src="medias/480_1652369064.jpg" data-envira-item-id="63" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-64" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/pvZ654w4qXc?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1652689027.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-64" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1652689027.jpg" data-envira-src="medias/480_1652689027.jpg" data-envira-item-id="64" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-65" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/a9BvKFDPoGM?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1652689967.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-65" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1652689967.jpg" data-envira-src="medias/480_1652689967.jpg" data-envira-item-id="65" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-66" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/5bcdCubv0rk?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1656915847.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-66" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1656915847.jpg" data-envira-src="medias/480_1656915847.jpg" data-envira-item-id="66" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-67" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/xYGICTQPEdQ?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1660299871.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-67" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1660299871.jpg" data-envira-src="medias/480_1660299871.jpg" data-envira-item-id="67" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-68" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/QsFeZEgvTx0?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1664280166.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-68" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1664280166.jpg" data-envira-src="medias/480_1664280166.jpg" data-envira-item-id="68" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-69" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/dZRQXsVfvpc?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1668485600.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-69" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1668485600.jpg" data-envira-src="medias/480_1668485600.jpg" data-envira-item-id="69" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-70" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/kEiyX9jJldY?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1672400695.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-70" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1672400695.jpg" data-envira-src="medias/480_1672400695.jpg" data-envira-item-id="70" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-71" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/UEWHzeyB088?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1679979719.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-71" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1679979719.jpg" data-envira-src="medias/480_1679979719.jpg" data-envira-item-id="71" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-72" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/DJmlY4CT7T0?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1684768946.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-72" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1684768946.jpg" data-envira-src="medias/480_1684768946.jpg" data-envira-item-id="72" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-73" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/L47BFAYf-m8?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1689053626.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-73" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1689053626.jpg" data-envira-src="medias/480_1689053626.jpg" data-envira-item-id="73" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-74" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/uZRtoy-OSLo?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1693629342.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-74" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1693629342.jpg" data-envira-src="medias/480_1693629342.jpg" data-envira-item-id="74" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-75" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/jXI-0TvdIiA?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1694185859.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-75" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1694185859.jpg" data-envira-src="medias/480_1694185859.jpg" data-envira-item-id="75" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-76" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/odV3ZEyqjo8?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1699628998.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-76" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1699628998.jpg" data-envira-src="medias/480_1699628998.jpg" data-envira-item-id="76" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-77" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/V1jL01M4Y5U?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1715348475.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-77" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1715348475.jpg" data-envira-src="medias/480_1715348475.jpg" data-envira-item-id="77" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-79" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/-68qwMyTzLg?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1720934673.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-79" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1720934673.jpg" data-envira-src="medias/480_1720934673.jpg" data-envira-item-id="79" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-80" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/YkPkpCls6Qw?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1723116262.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-80" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1723116262.jpg" data-envira-src="medias/480_1723116262.jpg" data-envira-item-id="80" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-81" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/8LUOYRUiO_Y?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1731929624.png" data-envirabox-type="iframe"><img id="envira-gallery-image-81" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1731929624.png" data-envira-src="medias/480_1731929624.png" data-envira-item-id="81" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-82" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/Eqi9mmxffw8?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1732038429.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-82" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1732038429.jpg" data-envira-src="medias/480_1732038429.jpg" data-envira-item-id="82" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-83" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/PoJ19nZZ_BA?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1732798763.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-83" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1732798763.jpg" data-envira-src="medias/480_1732798763.jpg" data-envira-item-id="83" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-84" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/0bbAoOVbNIs?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1750338394.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-84" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1750338394.jpg" data-envira-src="medias/480_1750338394.jpg" data-envira-item-id="84" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-85" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/2V51PVGHd68?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1755587307.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-85" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1755587307.jpg" data-envira-src="medias/480_1755587307.jpg" data-envira-item-id="85" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
								
                                <div id="envira-gallery-item-86" class="envira-gallery-item enviratope-item envira-gallery-item-1" style="padding-left: 5px; padding-bottom: 10px; padding-right: 5px;">
                                    <div class="envira-gallery-item-inner">
                                        <a href="//youtube.com/embed/1lyGCwAbfNA?autoplay=1&#038;controls=1&#038;enablejsapi=1&#038;modestbranding=1&#038;origin=&#038;rel=0&#038;showinfo=0&#038;version=3&#038;wmode=transparent" class="envira-gallery-312 envira-gallery-link" rel="enviragallery312" title="" data-envira-caption="" data-thumbnail="medias/480_1762945180.jpg" data-envirabox-type="iframe"><img id="envira-gallery-image-86" class="envira-gallery-image envira-gallery-image-1" data-envira-index="1" src="medias/480_1762945180.jpg" data-envira-src="medias/480_1762945180.jpg" data-envira-item-id="86" alt="See revenue at Rs 450cr in FY12 Balaji Amines" title="" /></a>
                                    </div>
                                </div>
	     
                            </div>
                        </div>
                        <!-- <noscript><img src="wp-content/uploads/2015/10/04.jpg" alt="See revenue at Rs 450cr in FY12 Balaji Amines" /><img src="wp-content/uploads/2015/10/05.jpg" alt="Balaji Amines to set up 100 room hotel with invst of Rs 40cr" /><img src="wp-content/uploads/2015/10/06.jpg" alt="Balaji Amines Ltd." /><img src="wp-content/uploads/2015/10/07.jpg" alt="Balaji Amines eyes Rs 450 500cr revenue in FY12" /><img src="wp-content/uploads/2015/10/08.jpg" alt="CNBC Aawaz" /><img src="wp-content/uploads/2015/10/09.jpg" alt="25_11_11.flv" /><img src="wp-content/uploads/2015/10/010.jpg" alt="CNBC08052014" /></noscript> -->
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">

                    <div class="col-sm-4 heading-color col-sm-offset-4">
                        <h2 style="text-align: center;">PDF</h2>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">

                    <div class="col-sm-2 col-sm-offset-2">
                        <p>
                            <!--</p>

<div class="media-download"><img class="aligncenter img-responsive" src="wp-content/uploads/2015/10/usa.jpg" alt="press"  ><br />
-->
                            <br />
                            <!--<a href="wp-content/uploads/2015/10/USA.pdf" target="_blank" onclick="return false">Download</a>--></p>
                    </div>
                    <div class="col-sm-2 col-sm-offset-1">
                        <div class="media-download"><img class="aligncenter img-responsive" src="wp-content/uploads/2015/10/press.jpg" alt="press">
                            <br />
                            <!--<a href="wp-content/uploads/2015/10/PRESS.pdf" target="_blank" onclick="return false">Download</a>--></div>
                    </div>
                    <div class="col-sm-2 hidden col-sm-offset-1">
                        <div class="media-download"><img class="aligncenter img-responsive" src="wp-content/uploads/2015/10/letter.jpg" alt="press">
                            <br />
                        </div>
                    </div>
                </div>
            </div>
 <footer class="full-bg " id="footer">

            <div class="container">
                <div class="row">

                    <div class="col-sm-4  widget-cell" id="footer-widget-1">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">ABOUT</h3>
                            <div class="menu-overview-footer-container">
                                <ul id="menu-overview-footer" class="menu">
                                    <li id="menu-item-412" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-412"><a href="company-profile.php">Company Profile</a></li>
                                    <li id="menu-item-415" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-415"><a href="mission-values.php">Mission &#038; Values</a></li>
                                    <li id="menu-item-414" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-414"><a href="certificate-awards.php">Certificate &#038; Awards</a></li>
                                    <li id="menu-item-413" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-413"><a href="balaji-management-team.php">Management Team</a></li>
                                    <li id="menu-item-479" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-479"><a href="balaji-amines-history.php">History</a></li>
                                    <li id="menu-item-709" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-709"><a href="bal-presence.php">BAL&#8217;s Presence</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4  widget-cell">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">PRODUCTS</h3>
                            <div class="menu-overview-footer-1-container">
                                <ul id="menu-overview-footer-1" class="menu">
                                    <li id="menu-item-417" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-417"><a href="amines.php">Amines</a></li>
                                    <li id="menu-item-416" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-416"><a href="derivatives.php">Derivatives</a></li>
                                    <li id="menu-item-418" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-418"><a href="speciality-chemicals.php">Speciality Chemicals</a></li>
                                    <li id="menu-item-679" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-679"><a href="excipients.php">Pharma Excipients</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4  widget-cell">
                        <div class="widget widget_nav_menu">
                            <h3 class="widgettitle">OTHERS</h3>
                            <div class="menu-footer3-container">
                                <ul id="menu-footer3" class="menu">
                                    <li id="menu-item-655" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-655"><a href="investor-relations.php">Investor Relations</a></li>
                                    <li id="menu-item-420" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-286 current_page_item menu-item-420 active"><a href="careers.php">Careers</a></li>
                                    <li id="menu-item-421" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-421"><a href="corporate-social-responsibility.php">Corporate Social Responsibility</a></li>
                                    <li id="menu-item-713" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-713"><a href="e-brochures.php">E-Brochure</a></li>
                                    <li id="menu-item-423" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-423"><a href="balaji-media.php">Media</a></li>
                                    <li id="menu-item-422" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-422"><a href="contact-us.php">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-1  widget-cell col-sm-offset-1">
                        <div class="widget widget_text">
                            <div class="textwidget"></div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="row">
                            <div class="col-sm-12" id="social-media-icons"></div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 col-sm-offset-6"></div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
		<div class="container-fluid">
            <div class="ddl-full-width-row row">
                <div class="col-sm-12 copyright-footer">
                    <p>copyright © balaji Amines 2025 Developed By <a href="http://katareinfo.com/">Katrare Informatics</a></p>
                </div>
            </div>
        </div>        </div>
        <link rel='stylesheet' id='envira-gallery-style-css' href='wp-content/plugins/envira-gallery/assets/css/envira.css?ver=1.3.7.1' type='text/css' media='all' />
        <link rel='stylesheet' id='envira-videos-style-css' href='wp-content/plugins/envira-videos/assets/css/envira-videos.css?ver=1.0.3' type='text/css' media='all' />
        <script type='text/javascript' src='wp-content/themes/toolset-bootstrap/bootstrap3/js/bootstrap.min.js?ver=3.3.4'></script>
        <script type='text/javascript' src='wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
        <script type='text/javascript' src='wp-includes/js/jquery/ui/datepicker.min.js?ver=1.11.4'></script>
        <script type='text/javascript'>
            jQuery(document).ready(function(jQuery) {
                jQuery.datepicker.setDefaults({
                    "closeText": "Close",
                    "currentText": "Today",
                    "monthNames": ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                    "monthNamesShort": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                    "nextText": "Next",
                    "prevText": "Previous",
                    "dayNames": ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                    "dayNamesShort": ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                    "dayNamesMin": ["S", "M", "T", "W", "T", "F", "S"],
                    "dateFormat": "MM d, yy",
                    "firstDay": 1,
                    "isRTL": false
                });
            });
        </script>
        <script type='text/javascript'>
            /* <![CDATA[ */
            var mejsL10n = {
                "language": "en-US",
                "strings": {
                    "Close": "Close",
                    "Fullscreen": "Fullscreen",
                    "Turn off Fullscreen": "Turn off Fullscreen",
                    "Go Fullscreen": "Go Fullscreen",
                    "Download File": "Download File",
                    "Download Video": "Download Video",
                    "Play": "Play",
                    "Pause": "Pause",
                    "Captions\/Subtitles": "Captions\/Subtitles",
                    "None": "None",
                    "Time Slider": "Time Slider",
                    "Skip back %1 seconds": "Skip back %1 seconds",
                    "Video Player": "Video Player",
                    "Audio Player": "Audio Player",
                    "Volume Slider": "Volume Slider",
                    "Mute Toggle": "Mute Toggle",
                    "Unmute": "Unmute",
                    "Mute": "Mute",
                    "Use Up\/Down Arrow keys to increase or decrease volume.": "Use Up\/Down Arrow keys to increase or decrease volume.",
                    "Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.": "Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds."
                }
            };
            var _wpmejsSettings = {
                "pluginPath": "\/wp-includes\/js\/mediaelement\/"
            };
            /* ]]> */
        </script>
        <script type='text/javascript' src='wp-includes/js/mediaelement/mediaelement-and-player.min.js?ver=2.22.0'></script>
        <script type='text/javascript' src='wp-includes/js/mediaelement/wp-mediaelement.min.js?ver=4.7.3'></script>
        <script type='text/javascript' src='wp-includes/js/underscore.min.js?ver=1.8.3'></script>
        <script type='text/javascript'>
            /* <![CDATA[ */
            var _wpUtilSettings = {
                "ajax": {
                    "url": "\/wp-admin\/admin-ajax.php"
                }
            };
            /* ]]> */
        </script>
        <script type='text/javascript' src='wp-includes/js/wp-util.min.js?ver=4.7.3'></script>
        <script type='text/javascript' src='wp-includes/js/backbone.min.js?ver=1.2.3'></script>
        <script type='text/javascript' src='wp-includes/js/mediaelement/wp-playlist.min.js?ver=4.7.3'></script>
        <script type='text/javascript'>
            /* <![CDATA[ */
            var wpv_pagination_local = {
                "front_ajaxurl": "http:\/\/www.balajiamines.in\/wp-admin\/admin-ajax.php",
                "ajax_pagination_url": "http:\/\/www.balajiamines.in\/wpv-ajax-pagination\/",
                "calendar_image": "http:\/\/www.balajiamines.in\/wp-content\/plugins\/wp-views\/embedded\/res\/img\/calendar.gif",
                "calendar_text": "Select date",
                "datepicker_min_date": null,
                "datepicker_max_date": null
            };
            /* ]]> */
        </script>
        <script type='text/javascript' src='wp-content/plugins/wp-views/embedded/res/js/wpv-pagination-embedded.js?ver=1.10'></script>
        <script type='text/javascript' src='wp-includes/js/wp-embed.min.js?ver=4.7.3'></script>
        <script type='text/javascript' src='wp-content/plugins/envira-gallery/assets/js/min/envira-min.js?ver=1.3.7.1'></script>
        <script type='text/javascript' src='https://www.youtube.com/iframe_api?ver=1.0.3'></script>
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                var envira_container_312 = '';
                envira_container_312 = $('#envira-gallery-312').enviratope({
                    itemSelector: '.envira-gallery-item',
                    masonry: {
                        columnWidth: '.envira-gallery-item'
                    }
                });
                envira_container_312.imagesLoaded(function() {
                    envira_container_312.enviratope('layout');
                });
                envira_container_312 = $('#envira-gallery-312').imagesLoaded(function() {
                    $('.envira-gallery-item img').fadeTo('slow', 1);
                });
                $('.envira-gallery-312').envirabox({
                    arrows: 1,
                    aspectRatio: 1,
                    loop: 1,
                    mouseWheel: 1,
                    preload: 1,
                    nextEffect: 'fade',
                    prevEffect: 'fade',
                    tpl: {
                        wrap: '<div class="envirabox-wrap" tabIndex="-1"><div class="envirabox-skin envirabox-theme-base"><div class="envirabox-outer"><div class="envirabox-inner"></div></div></div></div>',
                        image: '<img class="envirabox-image" src="{href}" alt="" data-envira-title="" data-envira-caption="" data-envira-index="" data-envira-data="" />',
                        iframe: '<iframe id="envirabox-frame{rnd}" name="envirabox-frame{rnd}" class="envirabox-iframe" frameborder="0" vspace="0" hspace="0" allowtransparency="true"\></iframe>',
                        error: '<p class="envirabox-error">The requested content cannot be loaded.<br/>Please try again later.</p>',
                        closeBtn: '<a title="Close" class="envirabox-item envirabox-close" href="javascript:;"></a>',
                        next: '<a title="Next" class="envirabox-nav envirabox-next envirabox-arrows-inside" href="javascript:;"><span></span></a>',
                        prev: '<a title="Previous" class="envirabox-nav envirabox-prev envirabox-arrows-inside" href="javascript:;"><span></span></a>'
                    },
                    helpers: {
                        video: {
                            autoplay: 1,
                            playpause: 1,
                            progress: 1,
                            current: 1,
                            duration: 1,
                            volume: 1
                        },
                        title: {
                            type: 'float'
                        },
                        thumbs: {
                            width: 250,
                            height: 175,
                            source: function(current) {
                                return $(current.element).data('thumbnail');
                            },
                            position: 'bottom'
                        },
                        buttons: {
                            tpl: '<div id="envirabox-buttons"><ul><li><a class="btnPrev" title="Previous" href="javascript:;"></a></li><li><a class="btnNext" title="Next" href="javascript:;"></a></li><li><a class="btnClose" title="Close" href="javascript:;"></a></li></ul></div>',
                            position: 'top',
                            padding: ''
                        },
                    },
                    beforeLoad: function() {
                        this.title = $(this.element).data('envira-caption');
                    },
                    afterLoad: function() {},
                    beforeShow: function() {
                        $(window).on({
                            'resize.envirabox': function() {
                                $.envirabox.update();
                            }
                        });
                        var id = this.element.find('img').data('envira-item-id');
                        var alt = this.element.find('img').attr('alt');
                        var title = this.element.find('img').parent().attr('title');
                        var caption = this.element.find('img').parent().data('envira-caption');
                        var index = this.element.find('img').data('envira-index');
                        this.inner.find('img').attr('alt', alt).attr('data-envira-item-id', id).attr('data-envira-title', title).attr('data-envira-caption', caption).attr('data-envira-index', index);
                    },
                    afterShow: function() {
                        $('.envirabox-wrap').swipe({
                            swipe: function(event, direction, distance, duration, fingerCount, fingerData) {
                                if (direction === 'left') {
                                    $.envirabox.next(direction);
                                } else if (direction === 'right') {
                                    $.envirabox.prev(direction);
                                } else if (direction === 'up') {}
                            }
                        });
                    },
                    beforeClose: function() {},
                    afterClose: function() {
                        $(window).off('resize.envirabox');
                    },
                    onUpdate: function() {
                        var envira_buttons_312 = $('#envirabox-buttons li').map(function() {
                                return $(this).width();
                            }).get(),
                            envira_buttons_total_312 = 0;
                        $.each(envira_buttons_312, function(i, val) {
                            envira_buttons_total_312 += parseInt(val, 10);
                        });
                        $('#envirabox-buttons ul').width(envira_buttons_total_312);
                        $('#envirabox-buttons').width(envira_buttons_total_312).css('left', ($(window).width() - envira_buttons_total_312) / 2);
                    },
                    onCancel: function() {},
                    onPlayStart: function() {},
                    onPlayEnd: function() {}
                });
            });
        </script>

        <script>
            jQuery(window).scroll(function() {
                if (jQuery(document).scrollTop() > 50) {
                    jQuery('header').addClass('shrink');
                } else {
                    jQuery('header').removeClass('shrink');
                }
            });
            /*Youtube video*/

            jQuery('.js-lazyYT').lazyYT();

            /** Stop playing youtube video when page scrolls */

            jQuery(document).on('scroll', function() {
                var scrollTop = jQuery(window).scrollTop();
                if (scrollTop > pos.top + 315) {
                    player.stopVideo();
                }
            })
        </script>
        <script>
            /* moving object */
            jQuery('.marquee').marquee({
                //speed in milliseconds of the marquee
                duration: 6000,
                //gap in pixels between the tickers
                gap: 1500,
                //time in milliseconds before the marquee will start animating
                delayBeforeStart: 0,
                //'left' or 'right'
                direction: 'right',
                //true or false - should the marquee be duplicated to show an effect of continues flow
                duplicated: true
            });
        </script>
        <script>
            jQuery(document).ready(function() {

                /* Apply fancybox to multiple items */

                jQuery("a.balaji-products").fancybox({
                    'transitionIn': 'elastic',
                    'transitionOut': 'elastic',
                    'speedIn': 600,
                    'speedOut': 200,
                    'overlayShow': false
                });

                jQuery('.member-mug-shot').on('click', function() {
                    jQuery('.collapse').collapse('hide');
                })

            });
        </script>
        <script>
            (function(jQuery) {
                jQuery(document).ready(function() {
                    jQuery(".video-button").click(function() {
                        jQuery(".video-embed").css({
                            "opacity": "1",
                            "display": "block"
                        });
                        jQuery(".video-embed")[0].src += "&autoplay=1";
                        jQuery(this).unbind("click");
                    });
                });
            })(jQuery)
        </script>
        <!--<script>
        jQuery(document).ready(function() {
            jQuery.fancybox("a#single_image-popup");
        });
    </script>-->
        <script>
            jQuery(document).ready(function() {
                jQuery('.fancybox').fancybox({
                    beforeShow: function() {
                        this.title = jQuery(this.element).data("caption");
                    }
                });

                jQuery("a#single_image-popup").fancybox();

            });
        </script>
        <script>
            jQuery(window).load(function() {
                jQuery('#single_image-popup').fancybox({
                    beforeLoad: function() {
                        this.title = jQuery(this.element).find('img').attr('alt');
                    }

                });
                jQuery('#single_image-popup').fancybox({
                    'titleFromAlt': true,
                    'titlePosition': 'inside'

                });
                jQuery("a#single_image-popup").trigger('click');
            });
        </script>
        <script>
            function myFunction() {
                window.print();
            }
        </script>
</body>

</html>